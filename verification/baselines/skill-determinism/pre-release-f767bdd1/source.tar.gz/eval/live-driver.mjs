// FAFF-135 — live driver for the FAFF-93 skill-run harness: drive faff-tidy's judgement against a
// fixture with a REAL model, recording the model's classifications as DecisionRecord buckets.
//
// The harness (test/helpers/skill-harness.mjs) header named "a live driver (FAFF-122 spike)" as a
// future occupant of the SkillDriver interface ({ kind, drive(ctx) }) producing the SAME record
// shape as scriptedDriver. This is that occupant — the "frontier live-driver" lane ADR-0003 left open.
//
// Faithful, not black-box: instead of spawning `claude -p` over a self-contained eval prompt
// (eval/cli-driver.mjs), the driver reads the fixture through the harness tracker port, prompts a
// model with faff-tidy's REAL rubric, and records the resulting judgement at the harness seams —
// so the eval can assert structured decisions (decision-assert) the same way scripted runs do.
//
// The `model` is INJECTABLE: CI tests pass a deterministic mock (zero real calls). makeLiveModel
// returns the real one (spawns `claude -p` via eval/cli-driver buildInvocation, inheriting
// --plugin-dir/--bare/env). eval/ is excluded from `node --test`, and importing this module spawns
// nothing — only calling a real model fn does.
//
// Zero-dependency: node builtins + repo siblings only.

import { spawnSync } from "node:child_process";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, dirname } from "node:path";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
import {
  buildInvocation,
  loadJudgementCriteria,
  loadReconciliationProse,
  loadRoutingVerdictProse,
  loadReviewVerdictProse,
  loadReviewFindingProse,
  loadShapingProse,
  loadDecompositionProse,
  EVAL_MODE_INSTRUCTION,
  ROUTING_MODE_INSTRUCTION,
  VERDICT_BUILD_INSTRUCTION,
  FINDING_IDENTITY_INSTRUCTION,
  FINDING_IDENTITY_CARRY_INSTRUCTION,
  SHAPING_MODE_INSTRUCTION,
  DECOMPOSITION_MODE_INSTRUCTION,
  DEFAULT_PLUGIN_DIR,
  forwardCredentials,
} from "./cli-driver.mjs";
import { parseJudgementEnvelope } from "./envelope.mjs";
import { CLOSED_SET_KINDS } from "./grader.mjs";

// The shipped identity helper (CommonJS, governance region): the eval measures this exact code over
// model-chosen titles and locations.
const requireCjs = createRequire(import.meta.url);
const faffLib = (name) => requireCjs(join(dirname(fileURLToPath(import.meta.url)), "..", "plugin", "skills", "faff", "bin", "lib", name));
const findingIdModule = () => faffLib("finding-id.js");
// The production prior-findings shape and its framed prompt block (FAFF-1276).
const reviewPriorModule = () => faffLib("review-prior.js");

// Build the faff-tidy judgement prompt from faff's real criteria (classification + synthesis gloss,
// FAFF-140) + the issues read from the fixture + the shared envelope instruction. pluginDir null → no
// criteria (the improvise baseline / control).
//
// FAFF-146 — this is now ONE prompt builder among several: liveDriver takes a `promptBuilder` so the
// faff-tidy string is no longer the only option. buildReconciliationPrompt is the prep counterpart.
export function buildJudgementPrompt(issues, { pluginDir = DEFAULT_PLUGIN_DIR, caseId = "live", question } = {}) {
  const rubric = pluginDir
    ? `Apply faff's judgement + synthesis criteria below — these are the skills' own rules, verbatim:\n\n${loadJudgementCriteria(pluginDir)}\n\n---\n\n`
    : "";
  const ask = question ?? "classify the backlog (dupes / vague / stale / superseded) and order the ready issues";
  return (
    `${rubric}Run faff-tidy's judgement pass on the following backlog and answer: ${ask}\n\n` +
    `Backlog (FAFF-89 tracker shape):\n${JSON.stringify(issues, null, 2)}\n\n` +
    `${EVAL_MODE_INSTRUCTION.replace("<ID>", caseId)}`
  );
}

// FAFF-146 — the prep RECONCILIATION prompt builder (the execution-entangled surface). It folds in
// prep's verbatim Step-2a rubric (Challenge / Resolution / Context / Noise) and renders the issue +
// the spec comment (the anchor) + the thread, instructing the model to classify each comment posted
// AFTER the spec comment. The envelope carries a reconciliation field the grader reads as per-comment
// `id:label` pairs (mirrors the marker encoding):
//   { "case_id": "<ID>", "reconciliation": { "<comment-id>": "challenge|resolution|context|noise", ... } }
//
// DESIGN NOTE (FAFF-146 Chosen slice-split): this builder is specified here so the reconciliation
// design is captured and the live-driver is no longer faff-tidy-hardcoded, but the live reconciliation
// RUN — the thread fixtures, the human-authored Challenge/Resolution/Context/Noise oracle, and the
// runSkill({ skill: "faff-prep" }) measurement — is the carved follow-up child under FAFF-145. The
// builder is unit-wired (it composes a prompt) but not yet exercised end-to-end against a model here.
const RECONCILIATION_INSTRUCTION =
  "Classify each comment posted AFTER the spec comment by the Step-2a rubric above, then OUTPUT ONLY " +
  "one fenced code block tagged exactly `faff-eval:judgement` (that tag, NOT ```json) containing JSON " +
  'of the shape { "case_id": "<ID>", "reconciliation": { "<comment-id>": "challenge|resolution|context|noise", ... } } ' +
  "— one entry per post-spec comment, using the comment ids from the fixture. Output NOTHING except that " +
  "single block: no reasoning, no preamble, no prose, nothing before or after it.";

export function buildReconciliationPrompt(fixture, { pluginDir = DEFAULT_PLUGIN_DIR, caseId = "live" } = {}) {
  const rubric = pluginDir
    ? `Apply faff-prep's post-spec comment-reconciliation rubric below — these are the skill's own rules, verbatim:\n\n${loadReconciliationProse(pluginDir)}\n\n---\n\n`
    : "";
  const { issue, spec_comment, thread } = fixture;
  return (
    `${rubric}Run faff-prep's live-thread reconciliation pass. The spec comment is the anchor; classify ` +
    `every comment posted AFTER it.\n\n` +
    `Issue:\n${JSON.stringify(issue, null, 2)}\n\n` +
    `Spec comment (the anchor):\n${JSON.stringify(spec_comment, null, 2)}\n\n` +
    `Thread (chronological, all after the spec comment):\n${JSON.stringify(thread, null, 2)}\n\n` +
    `${RECONCILIATION_INSTRUCTION.replace("<ID>", caseId)}`
  );
}

// FAFF-158 — the routing VERDICT-ASSIGN prompt builder (the execution-entangled surface). It folds in
// faff's verbatim automation-routing assignment conditions (gateway + adaptor, via loadRoutingVerdictProse)
// and renders the assembled fixture-of-findings (issue + spec confidence/markers + diagnostics + conflict
// + park_history — the same shape as eval/cases/routing-*.json), then asks for EXACTLY ONE of the closed
// six verdicts via ROUTING_MODE_INSTRUCTION. The envelope carries a single `verdict` field the grader
// reads unchanged (the confidence analogue — one level → one verdict):
//   { "case_id": "<ID>", "verdict": "<one of the six>" }
//
// This is the THIRD prompt builder (after buildJudgementPrompt + buildReconciliationPrompt). pluginDir
// null → no rubric (the improvise baseline / control), exactly as the two siblings do.
export function buildRoutingPrompt(fixture, { pluginDir = DEFAULT_PLUGIN_DIR, caseId = "live" } = {}) {
  const rubric = pluginDir
    ? `Apply faff's automation-routing assignment conditions below — these are the gateway + adaptor rules, verbatim:\n\n${loadRoutingVerdictProse(pluginDir)}\n\n---\n\n`
    : "";
  const { issue, spec, diagnostics, conflict, park_history } = fixture;
  return (
    `${rubric}Run faff's automation-routing assignment pass. Assign the single verdict the assembled ` +
    `fixture-of-findings below implies.\n\n` +
    `Issue:\n${JSON.stringify(issue, null, 2)}\n\n` +
    `Spec (confidence + decision markers):\n${JSON.stringify(spec, null, 2)}\n\n` +
    `Backlog diagnostics finding:\n${JSON.stringify(diagnostics ?? null, null, 2)}\n\n` +
    `Conflict-analysis independence:\n${JSON.stringify(conflict ?? null, null, 2)}\n\n` +
    `Park history:\n${JSON.stringify(park_history ?? [], null, 2)}\n\n` +
    `${ROUTING_MODE_INSTRUCTION.replace("<ID>", caseId)}`
  );
}

// FAFF-155 — the verdict-build (whole-change review verdict) prompt builder (the execution-entangled
// surface, mirroring buildRoutingPrompt). It folds in the review-verdict rubric verbatim (the SAME
// loadReviewVerdictProse FAFF-148 already added — REUSED, not re-cut), renders the BuildFixture's
// change material (change_summary + spec + diff + test_results), then asks for EXACTLY ONE of
// pass / fail / needs-human by the revert test via VERDICT_BUILD_INSTRUCTION. The envelope carries a
// single `verdict` field the grader reads unchanged (the routing analogue — one verdict → one set):
//   { "case_id": "<ID>", "verdict": "pass|fail|needs-human" }
// pluginDir null → no rubric (the improvise baseline / control), exactly as the three siblings do.
export function buildVerdictBuildPrompt(fixture, { pluginDir = DEFAULT_PLUGIN_DIR, caseId = "live" } = {}) {
  const rubric = pluginDir
    ? `Apply faff's review-verdict rubric below — these are the review producer's + gateway's fixed rules, verbatim:\n\n${loadReviewVerdictProse(pluginDir)}\n\n---\n\n`
    : "";
  const { change_summary, spec, diff, test_results } = fixture;
  return (
    `${rubric}Run faff-graft's Step-9 review pass over the whole change below and assign the single ` +
    `verdict it implies.\n\n` +
    `Change summary:\n${change_summary ?? "(none)"}\n\n` +
    `Spec (the change is reviewed against this):\n${spec ?? "(none)"}\n\n` +
    `Diff (unified):\n${diff ?? "(none)"}\n\n` +
    `Test results:\n${test_results ?? "(none)"}\n\n` +
    `${VERDICT_BUILD_INSTRUCTION.replace("<ID>", caseId)}`
  );
}

// FAFF-161 — the jot/plot SHAPING prompt builder (a generative surface). It folds in jot's verbatim
// ticket-shaping rubric (loadShapingProse) + the rendered discovery brief + the SHAPING envelope
// instruction (the model emits a `shaping` array of one-line ticket glosses the grader scores by
// must_include/must_avoid synonym-set coverage). pluginDir null → no rubric (the improvise baseline /
// control), exactly as the siblings do. The fixture carries a `brief` (the rendered discovery brief);
// fall back to the whole fixture if absent.
export function buildShapingPrompt(fixture, { pluginDir = DEFAULT_PLUGIN_DIR, caseId = "live" } = {}) {
  const rubric = pluginDir
    ? `Apply jot/plot's ticket-shaping rubric below — these are the skill's own rules, verbatim:\n\n${loadShapingProse(pluginDir)}\n\n---\n\n`
    : "";
  const brief = fixture && fixture.brief != null ? fixture.brief : JSON.stringify(fixture, null, 2);
  return (
    `${rubric}Run jot/plot's ticket-shaping pass. Shape the discovery brief below into a sensible set ` +
    `of tickets.\n\n` +
    `Discovery brief:\n${brief}\n\n` +
    `${SHAPING_MODE_INSTRUCTION.replace("<ID>", caseId)}`
  );
}

// FAFF-161 — the plot DECOMPOSITION prompt builder (a generative surface). It folds in plot's verbatim
// top-down decomposition rule (loadDecompositionProse, incl. the stop rule) + the rendered discovery
// brief + the DECOMPOSITION envelope instruction (the model emits a `decomposition` tree the grader
// scores by coverage AND the three structural assertions). pluginDir null → no rubric (control).
export function buildDecompositionPrompt(fixture, { pluginDir = DEFAULT_PLUGIN_DIR, caseId = "live" } = {}) {
  const rubric = pluginDir
    ? `Apply plot's top-down decomposition rule below — these are the skill's own rules, verbatim:\n\n${loadDecompositionProse(pluginDir)}\n\n---\n\n`
    : "";
  const brief = fixture && fixture.brief != null ? fixture.brief : JSON.stringify(fixture, null, 2);
  return (
    `${rubric}Run plot's top-down decomposition pass (initiatives → projects → first-slice epics). ` +
    `Decompose the discovery brief below.\n\n` +
    `Discovery brief:\n${brief}\n\n` +
    `${DECOMPOSITION_MODE_INSTRUCTION.replace("<ID>", caseId)}`
  );
}

// A real model: spawn `claude -p` with the prompt. Reuses buildInvocation so it inherits the
// frontier/local preset opts (bin, model, env redirect, --bare, --plugin-dir). Returns raw stdout.
export function makeLiveModel(opts = {}) {
  return function liveModel(prompt) {
    const cfgDir = mkdtempSync(join(tmpdir(), "faff-live-"));
    try {
      forwardCredentials(cfgDir, opts); // FAFF-138: frontier auth survives the isolation; local skips
      const inv = buildInvocation(opts, prompt, cfgDir);
      const res = spawnSync(inv.bin, inv.args, { env: inv.env, cwd: cfgDir, encoding: "utf8", maxBuffer: 32 * 1024 * 1024 });
      if (res.error) throw new Error(`live model (${inv.bin}): ${res.error.message}`);
      return res.stdout ?? "";
    } finally {
      try { rmSync(cfgDir, { recursive: true, force: true }); } catch { /* FAFF-139: best-effort cleanup */ }
    }
  };
}

/**
 * FAFF-158 — the GENERIC live-driver core (the shared per-skill parameterisation seam). All three
 * live-driver occupants — liveDriver (tidy, multi-bucket), reconciliationLiveDriver (prep), and
 * routingLiveDriver (routing) — are thin configurations of this one core. The body is identical in
 * shape for all three: read through the tracker seam, build the per-skill prompt, call the injected
 * model, parse the envelope, reduce it to {name, items} bucket pairs, record each at the harness seam.
 *
 * This is the seam FAFF-154 (prep-reconciliation) and FAFF-155 (verdict-build) EXTEND rather than
 * re-cut: 154 re-points its reconciliationLiveDriver onto this core (already done here); 155 adds a
 * verdictBuildLiveDriver as another wrapper. The anti-pattern this exists to prevent is a third bespoke
 * driver copy-pasting the listIssues→buildPrompt→parseEnvelope→recordBucket body.
 *
 * `readEnvelope(env) -> Array<{name, items}>` is the per-skill reducer; returning a LIST of pairs is
 * what lets the multi-bucket tidy driver (one pair per populated CLOSED_SET_KIND + ordering) and the
 * single-bucket routing/reconciliation drivers (one pair) share the one core. A pair may omit `name`
 * to fall back to `bucketName`.
 *
 * @param {{ model: Function, skill?: string, buildPrompt: Function, readEnvelope: Function,
 *           bucketName?: string, pluginDir?: string|null, caseId?: string }} cfg
 * @returns {{ kind: "live", drive: (ctx) => Promise<void> }}
 */
export function makeLiveDriver({ model, skill, buildPrompt, readEnvelope, bucketName, pluginDir = DEFAULT_PLUGIN_DIR, caseId = "live" } = {}) {
  if (typeof model !== "function") {
    throw new Error("makeLiveDriver requires a model(prompt) function (inject a mock in CI; makeLiveModel for real)");
  }
  if (typeof buildPrompt !== "function") {
    throw new Error("makeLiveDriver requires a buildPrompt(ctx, opts) function");
  }
  if (typeof readEnvelope !== "function") {
    throw new Error("makeLiveDriver requires a readEnvelope(env) -> [{name, items}, …] reducer");
  }
  return {
    kind: "live",
    skill, // provenance tag (opaque to the harness; runSkill's own `skill` arg drives record.skill)
    async drive(ctx) {
      const issues = ctx.tracker.listIssues({}); // records the single trackerRead seam (seam-faithful)
      const prompt = buildPrompt(ctx, { pluginDir, caseId, issues });
      const raw = await model(prompt);
      const env = parseJudgementEnvelope(raw, { expectedCaseId: caseId }); // FAFF-137: classify fallback recovers a mis-tagged block
      for (const pair of readEnvelope(env)) {
        if (!pair || !Array.isArray(pair.items)) continue;
        ctx.record.recordBucket(pair.name ?? bucketName, pair.items);
      }
    },
  };
}

/**
 * A live SkillDriver for runSkill (FAFF-93). Reads the fixture, prompts the model with faff-tidy's
 * real rubric, parses the judgement envelope, and records each classification as a DecisionRecord
 * bucket (plus `ordering` when present). `model(prompt) -> rawText` is required and injectable.
 *
 * FAFF-158 — re-expressed as a wrapper over makeLiveDriver (the shared core) with NO behaviour change:
 * the tidy reducer returns one {name, items} pair per populated CLOSED_SET_KIND, plus an `ordering`
 * pair when present (the multi-bucket case the pairs shape exists to absorb).
 *
 * @param {{ model: Function, pluginDir?: string|null, caseId?: string }} cfg
 * @returns {{ kind: "live", drive: (ctx) => Promise<void> }}
 */
export function liveDriver({ model, pluginDir = DEFAULT_PLUGIN_DIR, caseId = "live" } = {}) {
  if (typeof model !== "function") {
    throw new Error("liveDriver requires a model(prompt) function (inject a mock in CI; makeLiveModel for real)");
  }
  return makeLiveDriver({
    model,
    skill: "faff-tidy",
    pluginDir,
    caseId,
    buildPrompt: (ctx, { issues, ...opts }) => buildJudgementPrompt(issues, opts),
    readEnvelope(env) {
      const cls = env.classifications ?? {};
      const pairs = [];
      for (const kind of CLOSED_SET_KINDS) {
        if (Array.isArray(cls[kind])) pairs.push({ name: kind, items: cls[kind] });
      }
      if (Array.isArray(env.ordering)) pairs.push({ name: "ordering", items: env.ordering });
      return pairs;
    },
  });
}

/**
 * FAFF-146 — a live SkillDriver for faff-prep's RECONCILIATION surface. Reads the issue + spec
 * comment + thread through the harness tracker seam, prompts the model with prep's verbatim Step-2a
 * rubric (buildReconciliationPrompt), parses the reconciliation envelope, and records each post-spec
 * comment label as a `reconciliation` DecisionRecord bucket of `id:label` pairs — the same shape the
 * grader's closed-set path scores. The bucket name is arbitrary (skill-harness recordBucket is
 * name-agnostic), so no harness redesign is needed (spec Assumption, verified).
 *
 * The test path is runSkill({ skill: "faff-prep", tracker, repo, driver }) — the seam-faithful lane.
 * DESIGN NOTE: shipped as the reconciliation DESIGN (the live-driver is parameterised + a prep driver
 * exists); the end-to-end RUN (thread fixtures + human oracle + the measured frontier baseline) is the
 * carved FAFF-145 follow-up child. `fixture` is read from ctx (the harness exposes it; falls back to a
 * tracker read) so this composes once the follow-up wires a ThreadFixture through the harness.
 *
 * @param {{ model: Function, fixture: object, pluginDir?: string|null, caseId?: string }} cfg
 * @returns {{ kind: "live", drive: (ctx) => Promise<void> }}
 */
export function reconciliationLiveDriver({ model, fixture, pluginDir = DEFAULT_PLUGIN_DIR, caseId = "live" } = {}) {
  if (typeof model !== "function") {
    throw new Error("reconciliationLiveDriver requires a model(prompt) function (inject a mock in CI; makeLiveModel for real)");
  }
  if (!fixture || !fixture.spec_comment || !Array.isArray(fixture.thread)) {
    throw new Error("reconciliationLiveDriver requires a ThreadFixture { issue, spec_comment, thread }");
  }
  // FAFF-158 — re-expressed as a wrapper over makeLiveDriver (the shared core) with NO behaviour change:
  // the prep reducer returns one { name: "reconciliation", items: [id:label, …] } pair.
  return makeLiveDriver({
    model,
    skill: "faff-prep",
    pluginDir,
    caseId,
    buildPrompt: (ctx, opts) => buildReconciliationPrompt(fixture, opts),
    readEnvelope(env) {
      const labels = env.reconciliation && typeof env.reconciliation === "object" ? env.reconciliation : {};
      return [{ name: "reconciliation", items: Object.entries(labels).map(([id, label]) => `${id}:${label}`) }];
    },
  });
}

/**
 * FAFF-154 — the reconciliation live-fixture RUNNER (the harness-wiring half AC 3 asks for). Given a
 * loaded reconciliation EvalCase (a `cases-live/reconciliation-*.json` ThreadFixture + per-comment
 * `id:label` oracle) and an injected model, it binds the case's `fixture` into reconciliationLiveDriver
 * (the inherited FAFF-158 makeLiveDriver wrapper — no driver re-cut) and drives it through the REAL
 * FAFF-93 harness via `runSkill({ skill: "faff-prep" })`, returning the recorded `reconciliation`
 * bucket so the caller can grade it through the existing `reconciliation` grade path.
 *
 * `runSkill`, `tracker`, and `repo` are injected (not imported) so eval/ stays free of test-helper
 * deps and the runner is the single place the cases reach the live-driver seam — never loadCases()'s
 * black-box CLI sweep (which has no reconciliation branch). The driver still issues the listIssues
 * seam-read, so the run is seam-faithful at the harness boundary, exactly like its two siblings.
 *
 * @param {object} evalCase a loaded reconciliation case ({ id, kind:"reconciliation", fixture, oracle })
 * @param {{ runSkill: Function, tracker: object, repo: object, model: Function,
 *           pluginDir?: string|null }} cfg
 * @returns {Promise<{ record: object, bucket: string[] }>} the DecisionRecord + the reconciliation bucket
 */
export async function driveReconciliationCase(evalCase, { runSkill, tracker, repo, model, pluginDir = DEFAULT_PLUGIN_DIR } = {}) {
  if (!evalCase || evalCase.kind !== "reconciliation" || !evalCase.fixture) {
    throw new Error("driveReconciliationCase requires a reconciliation EvalCase with a `fixture`");
  }
  if (typeof runSkill !== "function") {
    throw new Error("driveReconciliationCase requires the FAFF-93 runSkill (injected, not imported)");
  }
  const driver = reconciliationLiveDriver({ model, fixture: evalCase.fixture, pluginDir, caseId: evalCase.id });
  const record = await runSkill({ skill: "faff-prep", tracker, repo, driver });
  return { record, bucket: record.buckets.reconciliation ?? [] };
}

/**
 * FAFF-158 — a live SkillDriver for faff's ROUTING (automation-routing verdict-assignment) surface,
 * completing the execution-entangled half of the routing judgement-eval FAFF-149 carved. Reads the
 * assembled fixture-of-findings through the harness tracker seam, prompts the model with faff's
 * verbatim routing rubric (buildRoutingPrompt) + the rendered findings, parses the single assigned
 * verdict, and records it as a single-element `routing` DecisionRecord bucket — the SAME `env.verdict`
 * field the existing FAFF-149 grade path scores by single-element set-equality (no grader change).
 *
 * The third wrapper over makeLiveDriver, symmetric with reconciliationLiveDriver: `fixture` is passed
 * as a config field (the harness exposes no routing-fixture port) and the core still issues a
 * listIssues seam-read so the run is seam-faithful. A missing model / a malformed routing fixture
 * (no `issue` or `spec`) throws, mirroring validateCase's routing FIXTURE_SHAPE ["issue", "spec"].
 *
 * DESIGN NOTE: shipped as the routing live-driver DESIGN + the model-free dry-smoke (mock model →
 * driver → recorded bucket → the routing grade). The measured frontier baseline (real claude -p reps)
 * is the carved human-supervised follow-up (FAFF-131/156 pattern), recorded out-of-band, never faked.
 *
 * @param {{ model: Function, fixture: object, pluginDir?: string|null, caseId?: string }} cfg
 * @returns {{ kind: "live", drive: (ctx) => Promise<void> }}
 */
export function routingLiveDriver({ model, fixture, pluginDir = DEFAULT_PLUGIN_DIR, caseId = "live" } = {}) {
  if (typeof model !== "function") {
    throw new Error("routingLiveDriver requires a model(prompt) function (inject a mock in CI; makeLiveModel for real)");
  }
  if (!fixture || !fixture.issue || !fixture.spec) {
    throw new Error("routingLiveDriver requires a routing fixture { issue, spec, … }");
  }
  // FAFF-158 — a wrapper over makeLiveDriver: the routing reducer returns one
  // { name: "routing", items: [verdict] } pair. A missing/out-of-enum verdict yields items:[] (a
  // missing verdict) or the verbatim token (out-of-enum) → a clean grader FAIL, never a throw.
  return makeLiveDriver({
    model,
    skill: "faff-tidy",
    pluginDir,
    caseId,
    buildPrompt: (ctx, opts) => buildRoutingPrompt(fixture, opts),
    readEnvelope: (env) => [{ name: "routing", items: env.verdict == null ? [] : [String(env.verdict)] }],
  });
}

/**
 * FAFF-160 — the routing live-fixture RUNNER, the verbatim symmetric twin of driveReconciliationCase
 * (FAFF-154). Given a loaded routing EvalCase (a `cases/routing-*.json` assembled fixture-of-findings +
 * single-verdict `oracle.closed_set`) and an injected model, it binds the case's `fixture` into
 * routingLiveDriver (the inherited FAFF-158 makeLiveDriver wrapper — no driver re-cut) and drives it
 * through the REAL FAFF-93 harness via `runSkill({ skill: "faff-tidy" })`, returning the recorded
 * `routing` bucket's single assigned verdict so the caller can grade it through the existing FAFF-149
 * `routing` grade path (single-element set-equality, no grader change).
 *
 * `runSkill`, `tracker`, and `repo` are injected (not imported) so eval/ stays free of test-helper deps
 * and the runner is the single place a routing case reaches the live-driver seam. The driver still
 * issues the listIssues seam-read, so the run is seam-faithful at the harness boundary, exactly like
 * driveReconciliationCase. Unlike reconciliation (cases-live/), routing cases are read straight from
 * `cases/routing-*.json` (FAFF-160 spec Decision: the assembled fixtures already live there — the
 * black-box lane and the live lane share the one oracle, never duplicated into cases-live/).
 *
 * A missing / out-of-enum verdict surfaces as `verdict: null` (or the verbatim token), which the
 * LIVE_KINDS routing adapter forwards into `{ env: { verdict } }` → a clean grader FAIL, never a throw.
 *
 * @param {object} evalCase a loaded routing case ({ id, kind:"routing", fixture, oracle })
 * @param {{ runSkill: Function, tracker: object, repo: object, model: Function,
 *           pluginDir?: string|null }} cfg
 * @returns {Promise<{ record: object, verdict: string|null }>} the DecisionRecord + the assigned verdict
 */
export async function driveRoutingCase(evalCase, { runSkill, tracker, repo, model, pluginDir = DEFAULT_PLUGIN_DIR } = {}) {
  if (!evalCase || evalCase.kind !== "routing" || !evalCase.fixture) {
    throw new Error("driveRoutingCase requires a routing EvalCase with a `fixture`");
  }
  if (typeof runSkill !== "function") {
    throw new Error("driveRoutingCase requires the FAFF-93 runSkill (injected, not imported)");
  }
  const driver = routingLiveDriver({ model, fixture: evalCase.fixture, pluginDir, caseId: evalCase.id });
  const record = await runSkill({ skill: "faff-tidy", tracker, repo, driver });
  return { record, verdict: record.buckets.routing?.[0] ?? null };
}

/**
 * FAFF-155 — a live SkillDriver for faff-graft's REVIEW (whole-change verdict-build) surface — the
 * execution-entangled half FAFF-148 carved. The FOURTH thin wrapper over makeLiveDriver, symmetric with
 * routingLiveDriver: reads the assembled BuildFixture through the harness tracker seam, prompts the model
 * with faff's verbatim review-verdict rubric (buildVerdictBuildPrompt) + the rendered change material,
 * parses the single assigned verdict, and records it as a single-element `verdict-build` DecisionRecord
 * bucket — the SAME `env.verdict` field routing uses, which predictedSet's verdict-build arm scores by
 * single-element set-equality (no grader change beyond joining that arm).
 *
 * `fixture` is passed as a config field (the harness exposes no review-fixture port) and the core still
 * issues a listIssues seam-read so the run is seam-faithful. A missing model / a malformed fixture (no
 * `spec` or `diff`) throws. A missing/out-of-enum verdict yields items:[] (missing) or the verbatim token
 * (out-of-enum) → a clean grader FAIL, never a throw — the routing/confidence fail-safe stance.
 *
 * DESIGN NOTE: shipped as the verdict-build live-driver DESIGN + the model-free dry-smoke (mock model →
 * driver → recorded bucket → the verdict-build grade). The measured frontier baseline (real claude -p
 * reps) is the carved human-supervised follow-up (FAFF-131/156 pattern), recorded out-of-band, never faked.
 *
 * @param {{ model: Function, fixture: object, pluginDir?: string|null, caseId?: string }} cfg
 * @returns {{ kind: "live", drive: (ctx) => Promise<void> }}
 */
export function verdictBuildLiveDriver({ model, fixture, pluginDir = DEFAULT_PLUGIN_DIR, caseId = "live" } = {}) {
  if (typeof model !== "function") {
    throw new Error("verdictBuildLiveDriver requires a model(prompt) function (inject a mock in CI; makeLiveModel for real)");
  }
  if (!fixture || fixture.spec == null || fixture.diff == null) {
    throw new Error("verdictBuildLiveDriver requires a BuildFixture { spec, diff, … }");
  }
  // FAFF-155 — a wrapper over makeLiveDriver (NOT a re-cut): the verdict-build reducer returns one
  // { name: "verdict-build", items: [verdict] } pair. A missing/out-of-enum verdict yields items:[] (a
  // missing verdict) or the verbatim token (out-of-enum) → a clean grader FAIL, never a throw.
  return makeLiveDriver({
    model,
    skill: "faff-graft",
    pluginDir,
    caseId,
    buildPrompt: (ctx, opts) => buildVerdictBuildPrompt(fixture, opts),
    readEnvelope: (env) => [{ name: "verdict-build", items: env.verdict == null ? [] : [String(env.verdict)] }],
  });
}

/**
 * FAFF-155 — the verdict-build live-fixture RUNNER, the verbatim symmetric twin of driveReconciliationCase
 * (FAFF-154) and driveRoutingCase (FAFF-160). Given a loaded verdict-build EvalCase (a
 * `cases-live/verdict-build-*.json` BuildFixture + single-verdict `oracle.closed_set`) and an injected
 * model, it binds the case's `fixture` into verdictBuildLiveDriver (the inherited makeLiveDriver wrapper —
 * no driver re-cut) and drives it through the REAL FAFF-93 harness via `runSkill({ skill: "faff-graft" })`,
 * returning the recorded `verdict-build` bucket so the caller can grade it through the existing
 * single-element set-equality path (no grader change beyond predictedSet's verdict-build arm).
 *
 * `runSkill`, `tracker`, and `repo` are injected (not imported) so eval/ stays free of test-helper deps
 * and the runner is the single place a verdict-build case reaches the live-driver seam. The driver still
 * issues the listIssues seam-read, so the run is seam-faithful at the harness boundary, exactly like its
 * two siblings. Unlike routing (cases/), verdict-build cases live in `cases-live/` (the BuildFixture has a
 * non-backlog shape the black-box CLI driver has no render branch for — the reconciliation lane pattern).
 *
 * @param {object} evalCase a loaded verdict-build case ({ id, kind:"verdict-build", fixture, oracle })
 * @param {{ runSkill: Function, tracker: object, repo: object, model: Function,
 *           pluginDir?: string|null }} cfg
 * @returns {Promise<{ record: object, bucket: string[] }>} the DecisionRecord + the verdict-build bucket
 */
export async function driveVerdictBuildCase(evalCase, { runSkill, tracker, repo, model, pluginDir = DEFAULT_PLUGIN_DIR } = {}) {
  if (!evalCase || evalCase.kind !== "verdict-build" || !evalCase.fixture) {
    throw new Error("driveVerdictBuildCase requires a verdict-build EvalCase with a `fixture`");
  }
  if (typeof runSkill !== "function") {
    throw new Error("driveVerdictBuildCase requires the FAFF-93 runSkill (injected, not imported)");
  }
  const driver = verdictBuildLiveDriver({ model, fixture: evalCase.fixture, pluginDir, caseId: evalCase.id });
  const record = await runSkill({ skill: "faff-graft", tracker, repo, driver });
  return { record, bucket: record.buckets["verdict-build"] ?? [] };
}

/**
 * FAFF-161 — a live SkillDriver for faff's jot/plot SHAPING (generative ticket-shaping) surface, the
 * fourth thin wrapper over makeLiveDriver (after liveDriver / reconciliationLiveDriver / routingLiveDriver).
 * Reads through the harness tracker seam, prompts the model with jot's verbatim shaping rubric
 * (buildShapingPrompt) + the rendered discovery brief, parses the emitted ticket-boundary set, and
 * records it as a single `shaping` DecisionRecord bucket — the SAME `env.shaping` collection the
 * gradeShaping path scores by must_include/must_avoid coverage (no grader change beyond the new fn).
 *
 * The shared core is EXTENDED, not re-cut (the FAFF-158 anti-pattern): `fixture` is a config field (the
 * harness exposes no shaping-fixture port) and the core still issues a listIssues seam-read so the run is
 * seam-faithful. A missing/garbage `shaping` field yields an empty bucket → coverage 0 → a clean low
 * grade, never a throw. DESIGN NOTE: shipped as the driver + the model-free dry-smoke; the measured
 * frontier baseline (real claude -p reps) is the carved human-supervised follow-up, recorded out-of-band.
 *
 * @param {{ model: Function, fixture: object, pluginDir?: string|null, caseId?: string }} cfg
 * @returns {{ kind: "live", drive: (ctx) => Promise<void> }}
 */
export function shapingLiveDriver({ model, fixture, pluginDir = DEFAULT_PLUGIN_DIR, caseId = "live" } = {}) {
  if (typeof model !== "function") {
    throw new Error("shapingLiveDriver requires a model(prompt) function (inject a mock in CI; makeLiveModel for real)");
  }
  if (!fixture) {
    throw new Error("shapingLiveDriver requires a shaping fixture { brief, … }");
  }
  return makeLiveDriver({
    model,
    skill: "faff-jot",
    pluginDir,
    caseId,
    buildPrompt: (ctx, opts) => buildShapingPrompt(fixture, opts),
    // the shaping bucket is the emitted ticket-boundary set (an array of one-line glosses); an absent
    // field → [] → coverage 0, a clean low grade.
    readEnvelope: (env) => [{ name: "shaping", items: Array.isArray(env.shaping) ? env.shaping : [] }],
  });
}

/**
 * FAFF-161 — a live SkillDriver for faff's plot DECOMPOSITION (generative tree) surface, the fifth thin
 * wrapper over makeLiveDriver. Reads through the harness tracker seam, prompts the model with plot's
 * verbatim decomposition rubric (buildDecompositionPrompt) + the rendered discovery brief, parses the
 * emitted tree, and records it as a single `decomposition` DecisionRecord bucket carrying the WHOLE tree
 * object (so the gradeDecomposition path can run both the coverage rubric over the tree's titles AND the
 * three structural assertions over its structure). The bucket items are `[tree]` — a one-element array
 * wrapping the tree object — so the bucket shape (an array) is preserved while the tree survives intact.
 *
 * The shared core is EXTENDED, not re-cut. A missing/garbage `decomposition` field yields an empty tree
 * → coverage 0 + structural checks fail defensively → a clean low grade, never a throw. DESIGN NOTE: as
 * shapingLiveDriver — driver + dry-smoke ship here; the measured frontier baseline is the carved follow-up.
 *
 * @param {{ model: Function, fixture: object, pluginDir?: string|null, caseId?: string }} cfg
 * @returns {{ kind: "live", drive: (ctx) => Promise<void> }}
 */
export function decompositionLiveDriver({ model, fixture, pluginDir = DEFAULT_PLUGIN_DIR, caseId = "live" } = {}) {
  if (typeof model !== "function") {
    throw new Error("decompositionLiveDriver requires a model(prompt) function (inject a mock in CI; makeLiveModel for real)");
  }
  if (!fixture) {
    throw new Error("decompositionLiveDriver requires a decomposition fixture { brief, … }");
  }
  return makeLiveDriver({
    model,
    skill: "faff-plot",
    pluginDir,
    caseId,
    buildPrompt: (ctx, opts) => buildDecompositionPrompt(fixture, opts),
    // the decomposition bucket wraps the WHOLE emitted tree in a one-element array (the recordBucket
    // items must be an array); the grader reads env.decomposition, so the caller unwraps items[0].
    readEnvelope: (env) => [{ name: "decomposition", items: [env.decomposition ?? {}] }],
  });
}

/**
 * FAFF-1266 — the finding-identity prompt builder: the review rubric with the contract's finding fields
 * (loadReviewFindingProse), the rendered change material, then the output-only instruction. A pure
 * function of (fixture, diff, prior, pluginDir, caseId). `diff` overrides `fixture.diff` (the second
 * pass may review `diff_b`). FAFF-1276: a non-empty `prior` (pass A's findings as `priorFindingsList`
 * shapes them) is rendered with the production block between the rubric and the change material, and
 * the prompt ends with the carry instruction.
 */
export function buildFindingIdentityPrompt(fixture, { diff, prior = null, pluginDir = DEFAULT_PLUGIN_DIR, caseId = "live" } = {}) {
  const rubric = pluginDir
    ? `Apply faff's review rubric and contract below — these are the review producer's + gateway's rules, verbatim:\n\n${loadReviewFindingProse(pluginDir)}\n\n---\n\n`
    : "";
  const carrying = Array.isArray(prior);
  const priorBlock = carrying && prior.length ? `${reviewPriorModule().renderPriorFindingsBlock(prior)}\n---\n\n` : "";
  const instruction = carrying ? FINDING_IDENTITY_CARRY_INSTRUCTION : FINDING_IDENTITY_INSTRUCTION;
  const { change_summary, spec, test_results } = fixture;
  return (
    `${rubric}${priorBlock}Run faff-graft's Step-9 review passes over the whole change below and report your findings.\n\n` +
    `Change summary:\n${change_summary ?? "(none)"}\n\n` +
    `Spec (the change is reviewed against this):\n${spec ?? "(none)"}\n\n` +
    `Diff (unified):\n${diff ?? fixture.diff ?? "(none)"}\n\n` +
    `Test results:\n${test_results ?? "(none)"}\n\n` +
    `${instruction.replace("<ID>", caseId)}`
  );
}

/**
 * FAFF-1266 — one independent review pass as a live SkillDriver: a thin wrapper over makeLiveDriver that
 * records the pass's findings as a `finding-identity-findings` bucket and its signal as
 * `finding-identity-signal`. `findings` is never given an id by the model; a missing or non-array
 * `findings` reads as none.
 */
export function findingIdentityLiveDriver({ model, fixture, diff, prior = null, pluginDir = DEFAULT_PLUGIN_DIR, caseId = "live" } = {}) {
  if (typeof model !== "function") {
    throw new Error("findingIdentityLiveDriver requires a model(prompt) function (inject a mock in CI; makeLiveModel for real)");
  }
  if (!fixture || fixture.spec == null || fixture.diff == null) {
    throw new Error("findingIdentityLiveDriver requires a BuildFixture { spec, diff, … }");
  }
  return makeLiveDriver({
    model,
    skill: "faff-graft",
    pluginDir,
    caseId,
    buildPrompt: (ctx, opts) => buildFindingIdentityPrompt(fixture, { ...opts, diff: diff ?? fixture.diff, prior }),
    readEnvelope: (env) => [
      { name: "finding-identity-findings", items: Array.isArray(env.findings) ? env.findings.filter((f) => f && typeof f === "object") : [] },
      { name: "finding-identity-signal", items: env.signal == null ? [] : [String(env.signal)] },
    ],
  });
}

const SEVERITY_RANK = { critical: 4, major: 3, minor: 2, observation: 1 };

function locationLine(location) {
  const m = typeof location === "string" ? /:(\d+)/.exec(location.trim().split(/\s/)[0]) : null;
  return m ? Number(m[1]) : null;
}

// inSecondDefect(finding, defectFile, lines) -> is this finding located inside the fixture's
// second_defect_b line range in the defect file?
function inSecondDefect(finding, defectFile, lines) {
  if (!Array.isArray(lines)) return false;
  const line = locationLine(finding.location);
  return findingIdModule().normaliseFindingPath(finding.location) === defectFile && line !== null && line >= lines[0] && line <= lines[1];
}

// The pass's defect finding: among findings whose normalised path equals defect_file (and, in pass B,
// not inside the second defect), the highest severity (a missing severity ranks last), ties to the
// first emitted. `entries` are the pass's resolveRoundChain entries. Returns { finding, index, entry } | null.
function defectFindingOf(findings, entries, defectFile, excludeLines = null) {
  const { normaliseFindingPath } = findingIdModule();
  let best = null;
  findings.forEach((f, i) => {
    if (normaliseFindingPath(f.location) !== defectFile) return;
    if (inSecondDefect(f, defectFile, excludeLines)) return;
    const rank = SEVERITY_RANK[f.severity] ?? 0;
    if (best === null || rank > best.rank) best = { finding: f, index: i, entry: entries[i], rank };
  });
  return best;
}

/**
 * FAFF-1266 / FAFF-1276 — drive one finding-identity rep: pass A reviews the change as round 1; pass B
 * (its own runSkill and model invocation) reviews `diff_b` with pass A's findings as the production
 * prior-findings block, and may carry a handle. Ids come from resolveRoundChain over both passes.
 * Returns the rep-loop's `{ env, tokens, detail }`; `env["finding-identity"]` is "stable" | "drifted" |
 * "merged" | "undetected". A pass whose output does not parse throws (the runner records an errored rep).
 */
export async function driveFindingIdentityCase(evalCase, { runSkill, tracker, repo, model, pluginDir = DEFAULT_PLUGIN_DIR } = {}) {
  if (!evalCase || evalCase.kind !== "finding-identity" || !evalCase.fixture) {
    throw new Error("driveFindingIdentityCase requires a finding-identity EvalCase with a `fixture`");
  }
  if (typeof runSkill !== "function") {
    throw new Error("driveFindingIdentityCase requires the FAFF-93 runSkill (injected, not imported)");
  }
  const { fixture } = evalCase;
  const { findingId, resolveRoundChain } = findingIdModule();
  const runPass = async (diff, prior) => {
    const driver = findingIdentityLiveDriver({ model, fixture, diff, prior, pluginDir, caseId: evalCase.id });
    const record = await runSkill({ skill: "faff-graft", tracker, repo, driver });
    return record.buckets["finding-identity-findings"] ?? [];
  };
  const findingsA = await runPass(fixture.diff, null);
  const findingsB = await runPass(fixture.diff_b ?? fixture.diff, reviewPriorModule().priorFindingsList(findingsA));
  const [entriesA, entriesB] = resolveRoundChain([{ round: 1, findings: findingsA }, { round: 2, findings: findingsB }]);
  const secondLines = fixture.second_defect_b ? fixture.second_defect_b.lines : null;
  const a = defectFindingOf(findingsA, entriesA, fixture.defect_file);
  const b = defectFindingOf(findingsB, entriesB, fixture.defect_file, secondLines);
  const handleA = a ? `P${a.index + 1}` : null;
  const merged = handleA !== null && findingsB.some((f) =>
    inSecondDefect(f, fixture.defect_file, secondLines) && typeof f.carried_id === "string" && f.carried_id.trim() === handleA);
  const outcome = merged ? "merged" : !a || !b ? "undetected" : a.entry.id === b.entry.id ? "stable" : "drifted";
  return {
    env: { "finding-identity": outcome },
    tokens: 0,
    detail: {
      outcome,
      merged,
      id_a: a ? a.entry.id : null,
      id_b: b ? b.entry.id : null,
      title_a: a ? a.finding.title ?? null : null,
      title_b: b ? b.finding.title ?? null : null,
      carried_b: !!b && b.entry.carry === "accepted",
      title_stable: !!a && !!b && findingId(b.finding, 2, b.index) === a.entry.id,
      refused_carries: entriesB.filter((e) => e.carry === "refused").length,
    },
  };
}
