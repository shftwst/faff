---
name: faff-jot
description: "Start something new. Kick off an empty project, or capture a new feature, bug, or idea — and turn it into a sensible set of tickets. Use for 'new project', 'I've got an idea', 'add a feature', 'file a bug', 'scope this', 'kick off'. Or point it at an existing ticket (`/faff-jot ISSUE-XX`) to load and inspect it — its shaping verbs are deferred, so it displays the ticket and mutates nothing."
judgement_seam: shaping
---

# faff-jot

The front door for new work — and the human's entry point to shape or gate a ticket that already exists. `/faff-jot` is how tickets come to exist in the first place; pointed at an existing ticket (`/faff-jot ISSUE-XX`) it's also where you decide that ticket's shape and whether it enters the pipeline. For new work it takes a loose starting point (a whole new project, or a single feature/bug/idea) and turns it into a sensible, well-shaped set of tracker tickets the rest of the pipeline can pick up.

One skill, three entry points — **not** separate commands per item type:

- **Kick off an empty project** — greenfield. No tracker project yet, or an empty repo. Produces an initial structure: workstreams/containers and the first tickets to reach a usable v0.
- **Capture a new feature, bug, or ticket** — single-item. An existing project. Produces one well-formed ticket (or a small set, if it genuinely splits), landed wherever the `methodology` slot's `ticket-shaping` places it — a workstream/project home, or (the agile-lens default) project-less in Backlog.
- **Inspect an existing ticket** — `/faff-jot ISSUE-XX`. *Not* new work: loads and displays a ticket for inspection. Its shaping verbs (re-scope, re-home, split/merge) are **deferred** (see **Existing-ticket interactor** below); it never specs, grooms, or builds.

## Configuration

**Load the kernel first.** If `faff/references/kernel.md` isn't in context this turn, Read it now — it holds the shared rules + fixed contracts faff applies. Do **not** Read `faff/SKILL.md` (the bare-`/faff` routing gateway — a specific-skill entry never needs it). Then Read the lane references jot consumes: `faff/references/tracker.md`, `faff/references/autonomous.md`, `faff/references/methodology.md`, `faff/references/create.md`. jot leans on **Agent Lanes** and the `intake` / `methodology` slot contracts it delegates to.

## Rendering

All human-facing output this skill emits — new-work tracker **descriptions** (the create step) and the existing-ticket interactor's reason comments, plus any terminal summaries — passes through the configured `rendering_adaptor` normalise pass **before it is printed or written** (gateway → **Rendering**, Universal-routing rule). In particular, enumerable sets render as lists, never `·`/comma run-on paragraphs (the prose-skimmability rule), so descriptions and comments are as skimmable as terminal output. Carve-outs (skill source files, `.faff/` logs) are exempt.

## Lane

`/faff-jot` runs in the **orchestrator lane** (see gateway → Agent Lanes): it talks to the human, runs discovery, reads the tracker, and creates tickets. It does **not** write code and does **not** produce specs — speccing is `/faff-prep`'s job, per ticket, later. The division is deliberate: ideation and ticket-shaping are orchestration; the spec is the build contract.

## What it does (the flow)

```
no arg → new work:           discover (intake) → shape (methodology) → create → chain to /faff-prep
ISSUE-XX → existing ticket:  load → display summary → log
```

### 0. Dispatch on argument

**Check for an issue-id argument first** — its presence is the unambiguous switch, so no "new or existing?" gate is needed:

- **Issue-id argument present** (`/faff-jot ISSUE-XX`) → the **existing-ticket interactor** (see **Existing-ticket interactor** below). Skip discovery, shaping, and creation — those are for new work only.
- **No argument** (`/faff-jot`) → new-work intake: continue to mode detection below, unchanged.

### 1. Detect the mode (new work only)

- **greenfield** when: no tracker project/container exists for this work, or the user says "new project / starting from scratch / empty repo / kick off X".
- **single-item** when: a tracker project already exists and the user is describing one feature, bug, or change.

When it's genuinely ambiguous (existing project, but the user is describing something big and cross-cutting), ask once: "Is this a new workstream/project, or one ticket in [existing project]?" Don't guess on a fork this consequential.

### 2. Discover — delegate to the `intake` slot

**Dispatch the configured `intake` skill** (override with `superpowers:brainstorming`, `gstack:office-hours`, or any ideation skill) **as a producer subagent** (resolve the slot value + transport per gateway → **Sibling-skill invocation → Producer dispatch**, resolving the `intake` dispatch lane: a bundled default is a canonical name, an explicitly-namespaced override is used verbatim; an `engine:<name>` value forks the dispatch to `faff engine call` per that same gateway rule — a named non-zero exit surfaces loudly, never a session-model fallback). Pass it: the detected mode, the human's starting description, and — for single-item — the live workstream/container list + naming conventions + current-priority signal so it can place the item.

The intake skill runs the discovery conversation and returns a **discovery brief** (the `intake`-slot output contract — see `faffter-noon-intake`). **Whatever intake skill ran, its output comes back into this orchestrator lane** — `/faff-jot` owns everything from here. A third-party intake skill only has to emit the discovery-brief shape; it never touches the tracker.

If the configured intake skill returns something that isn't a conformant discovery brief (missing required sections), normalise what you can and fill gaps from the conversation — don't bounce it back to the human. A missing `intake` override is never a blocker: `faff config get slots.intake` always resolves (the registry supplies the default); run the resolved skill inline.

### 3. Shape into tickets — apply the `methodology` slot

**Methodology transport.** jot's `methodology` calls — `ticket-shaping` for the brief and `prdr-author` for a new project — are **producer dispatches** (gateway → **Sibling-skill invocation → Producer dispatch**), resolving the `methodology` dispatch lane. Per gateway → **The `methodology` slot → Transport**, `ticket-shaping` is a **single dispatch per pass** and `prdr-author` dispatches **per project**; jot running inside a subagent falls back **in-context** (single-level nesting).

Hand the discovery brief to the configured `methodology` skill's **`ticket-shaping`** output (resolve `faff config get slots.methodology`). The methodology decides the structure — workstreams/containers, ticket boundaries, sequencing, dependency links — from the brief plus the live tracker graph. This is where "a sensible set of tickets" is actually formed, and it follows whatever methodology the project has configured: the thematic default shapes purely from the brief + graph; an opinionated methodology (`faffter-dark-methodology-agile-delivery`) additionally right-sizes, outcome-names workstreams, and sequences by value × risk.

`/faff-jot` does not invent its own ticket structure — it asks the methodology for one. That's what keeps shaping consistent with how the same project's backlog is groomed and sequenced everywhere else.

### 4. Confirm and create

**Fork first — is this application-scale?** Before creating anything, check whether the brief is bigger than a flat set of first-slice tickets: it spans **multiple capabilities that themselves decompose** into projects/sub-work (the same multi-capability signal that makes the methodology propose a top-level container). If so, offer the top-down route instead of creating flat:

> "This looks application-scale — decompose into a full roadmap (initiatives → projects → first-slice epics) via `/faff-plot` first? (y/n)"

On confirm, hand the **discovery brief** to the `faff-plot` skill via the Skill tool and stop here — do **not** also create the flat set (plot writes the skeleton, including the first-slice epics). On deny, or for a single-item / small greenfield brief, proceed with the flat create below exactly as before. The fork is a one-time offer at the shape boundary, not a new mode.

**Default landing — act on the shaped container, never the methodology name.** Whether new work gets a project/container home is the `methodology` slot's call, returned by `ticket-shaping` (gateway → **The `methodology` slot**, Default landing): when it proposes a container, confirm and create it as below; when it proposes none, create the tickets **project-less in Backlog** and **skip the `prdr-author` proposal** (no container ⇒ no container DoD — the existing flat-set carve-out). Under the agile lens the no-container default is the norm, so the "under new project '<name>'" path is the **deliberate, opt-in branch** (the human picks it, or `/faff-plot` supplies it), never the capture-time default; greenfield kickoff is exempt — it is itself an explicit project creation. jot reads the shape it was handed; it never inspects which methodology is configured.

Show the proposed structure (containers + tickets + relationships) and gate before writing:

- **Interactive (default):** present the shaped tickets as a short tree and ask "Create these N tickets [under new project '<name>']? (yes / edit / no)". On `edit`, take the human's adjustments and re-shape or tweak directly. On `yes`, create them in the tracker via the configured MCP. On `no`, stop — the brief is logged so nothing is lost.
- **Fill each ticket's description from its type template** (gateway → **Ticket templates**) before writing it: determine the type (honouring any per-ticket `type` the methodology's `ticket-shaping` supplied, else inferring from the title + description), resolve the template, and fill its fields from the brief — placeholdering unknown fields with `_To be determined during prep._`, never fabricating content. This runs after shaping (Step 3) and before the `rendering_adaptor` pass, so issues are **born structured**. Seed-not-constrain: a thin brief still creates a thin-but-structured ticket — creation is **never** blocked for an under-filled template. Resolving the template may now perform a create-time tracker `get_template` read when a native-template mapping exists (gateway → **Ticket templates**, tier 1); a miss falls through silently and never blocks.
- **Resolve the create-target team.** After type determination (the bullet above) and before `save_issue`, resolve which team each ticket lands in: `faff config get --json tracking.team_routing` keyed on the ticket's determined type token — a match wins; no match (including a routing key that isn't in the type taxonomy, which simply never fires) falls through to `faff config get tracking.default_team`. On a legacy single-team / zero-config repo (`tracking.teams` unset), this degrades to the one resolved team unconditionally — no routing table, no branch, byte-identical to today. `/faff-plot` reuses this exact procedure by reference (see below) rather than re-deriving it.
- Create containers first (initiative/project), then tickets — each into its resolved create-target team — then the blocker/blocked-by links the methodology proposed. (Each ticket's open questions land in its template's `Open questions` field.)
- **Idempotent create + link authoring** — apply the create/relink discipline in **Idempotent create + link authoring (the MCP-write seam)** below: re-query before retrying an ambiguous create, and author sibling references as markdown links, never raw-UUID embeds.
- **Record genuine intake provenance** — for each created ticket, run `faff intake-record <issue> --via jot --initiated interactive` (resolve the binary per gateway → **Resolving the `faff` executable**). This writes the CLI-owned `.faff/provenance/<issue>.json` marker that faff-graft's intake precondition reads — the *unspoofable* signal that the work entered through the front door. `--initiated interactive` stamps the audit field: jot is a human-present path, so it sets `interactive` unconditionally and runs **no containment check** — the human is the sanction (contrast the autonomous chokepoints, which stamp `autonomous` and gate on `faff contain`). The marker is the side effect of *running jot*; without it a `block`-mode graft would refuse the ticket.
- **Propose a project DoD (`prdr-author`, L3 propose-for-approval)** — when this create makes a **project** container (the "under new project '<name>'" case, not a flat ticket set), ask the configured `methodology` skill's **`prdr-author`** output for a target-scaled project DoD and **surface it for human approval** — jot runs at L3, so it **proposes**, the human **ratifies**. Request with the project's `{outcome, child_specs, target}` (`target` resolves `explicit > inherited > methodology-default`); the methodology writes the `AuthoredPrdr` via `faff prdr new --provenance loop --status Proposed`. Present the proposed `## Definition of done` + decision and gate — "Proposed project DoD for <project> (target: <t>). Approve / edit / skip?". On **approve**, have the human ratify by running **`faff prdr accept <n>`** — the sole writer of `Status: Accepted`, which commits the record to a `prdr/…` landing branch for a small PR (jot never self-Accepts, and never a hand-edit); then push the printed branch and open the PR. On **edit**, the human's DoD edit wins (human-set > methodology-default); on **skip**, leave it `Proposed`. A pre-existing human-set DoD is **never clobbered** — `prdr-author` re-reads and fills only unset parts (gateway → **Manual changes are authoritative (`prdr-author`)**). Unanswered / `--no-prdr` ⇒ no proposal; the human authors the DoD directly. (Flat ticket sets with no new project skip this — there is no container DoD to author.)

### 5. Chain to prep

After creating, offer the next step via the standard chaining gate: "Tickets created. Prep the first one for build now? (`/faff-prep <first-ticket>`) (y/n)". On confirm, invoke the `faff-prep` skill via the Skill tool on the highest-sequenced ticket. On deny, stop cleanly. (For greenfield, the "first one" is the first ticket of the first-slice workstream.)

## Idempotent create + link authoring (the MCP-write seam)

`/faff-jot` and `/faff-plot` are the two skills that **create** tracker issues via the Linear MCP `save_issue`. This is the single home for the three create/relink hazards at that seam; `/faff-plot` refers back here rather than restating them:

- **Re-query before retry, never retry blind.** A `save_issue` create whose result is ambiguous (timeout, 5xx, `upstream_unavailable`) may have written anyway. Before retrying, `list_issues` filtered by the resolved team-set (every team in `tracking.teams`, or the one legacy `tracking.team_key` team) + title-match against the intended title: a match → treat it as the already-created ticket, do **not** create again (if it is a confirmed unwanted duplicate, dedupe via `save_issue(id: <surplus>, duplicateOf: <kept>)` **without** also setting `state: "Duplicate"` in the same call — the combined write is rejected, "Missing duplicate relation"); no match → the prior attempt genuinely didn't land, proceed to create. A first attempt (no prior ambiguous result) creates directly — no re-query overhead.
- **Search before create, on every `/faff-plot` re-slice.** Before a node-scoped re-slice creates a node's children, list the issues already parented under that node and match each proposed child against them by title; skip a match, create only the gap. Never issue a `removeBlocks` in the same pass without re-confirming the live edge was drawn by *this* pass — don't strip an edge on unchecked provenance.
- **Link by identifier, not by opaque id.** A sibling reference authored into a ticket's own description prose is a `[FAFF-N](url)` markdown link — never a hand-typed `<issue id="UUID">` embed (a wrong UUID mis-links silently; a broken markdown link fails visibly). This governs prose the skills author; it does not touch `save_issue`'s structured `blockedBy`/`blocks`/`relatedTo`/`duplicateOf` fields, which already resolve by identifier.

Title-matching is imperfect (Linear search isn't exact-string) — scope it to title **and** team to keep it tight, and route a confirmed duplicate through `duplicateOf` rather than a silent skip, so an imperfect match still leaves an audit trail rather than a silent drop.

## Existing-ticket interactor (`/faff-jot ISSUE-XX`)

When invoked with an issue-id argument, `/faff-jot` is **not** doing new-work intake — it's the human's conversational entry point to **inspect an existing ticket**. It is **interactive-only** (never autonomous). In v1 the shaping verbs (re-scope, re-home, split/merge) are **deferred**, so today it loads and displays the ticket for inspection and mutates nothing.

**Remit — inspection now; shaping deferred.** Load and display the ticket. Re-scope, re-home (re-parent), and split/merge *intent* are the named future direction but **deferred** (see **Out of scope**). It deliberately does **not** absorb operations that already have homes:

- speccing → `/faff-prep`
- grooming / diagnostics → `/faff-tidy`
- building → `/faff-graft`

Framed narrowly it extends jot's intake identity (jot already owns the human↔pipeline-entry boundary); framed loosely it would duplicate three skills. Keep it narrow.

### The flow

1. **Load the ticket** — title, description, labels, status, spec comments. If the issue doesn't exist → error and stop. If it's **cancelled or archived** → refuse (shared **Ignore cancelled and archived** rule). This is a **load**, not a re-run of discovery — never re-interview the human about a ticket that already exists.
2. **Display a short summary** — title, status, and whether a spec is attached. No prompt, no mutation: the shaping verbs are deferred, so there is nothing to decide here yet.
3. **Log** per the gateway `.faff/logging` rule. No prompt, no write, no spec, no build, no re-discovery.

### Out of scope (v1)

- **Re-scope / re-home (re-parent) / split-merge intent** are the named direction but **deferred** — each later reuses the `methodology` slot's `ticket-shaping` output.
- No in-place edit of title / description / status.
- The interactor is **interactive-only** — no autonomous invocation (consistent with new-work intake being human-gated).

## Tracker-less (git-only) mode

When no tracker connector resolves — concluded **per gateway → Tracker availability resolution** (honour a `tracking.tracker` pin, discover before concluding absence; never from an immediately-invisible tool list) — there are no tickets to create. `/faff-jot` still runs discovery and shaping, then writes the shaped set to `.faff/intake/<date>-<slug>.md` as a checklist the human can act on, and notes that ticket creation was skipped (no tracker). The discovery brief and shaped structure are never lost.

**Stable item-keys.** For each shaped-ticket line, mint a gitkey via `faff queue-state new-key` and append it as a trailing marker: `- [ ] <ticket title> <!-- gitkey:K -->`. This is the durable id `faff queue-state derive` diffs against the run-ledger to derive `queue_empty`/`all_parked` in git-only mode (gateway → Spec discovery location 4) — reference the CLI, never restate the key format here.

## Autonomous mode

`/faff-jot` is **primarily interactive** — discovery is a conversation, and inventing new scope is exactly the kind of direction-setting that belongs to the human, not the autonomous pipeline. `/faff-beep-boop` does **not** invoke `/faff-jot`: beep-boop drains the *existing* backlog, it does not conjure new work. (This is why intake sits outside the unattended loop — new work entering the system is a human-gated event.)

If `/faff-jot` is somehow invoked in autonomous mode, it produces the discovery brief and shaped-ticket proposal, writes them to `.faff/intake/…`, and surfaces them for human review rather than creating tickets unattended. It never auto-creates a project or backlog without a human confirming the shape.

The **existing-ticket interactor** (`/faff-jot ISSUE-XX`) is likewise **interactive-only** — inspecting a human-named ticket is a human-present action, so there is no autonomous path to it.

## Appetite

Reads the suite-wide `appetite` dial but is lightly modulated, since creation is human-gated by default:

- `low` / `medium` — always show the full proposed structure and wait for explicit confirmation before creating anything.
- `high` (default) — same confirmation gate for creation, but resolve minor shaping ambiguities itself (recorded in the brief's open questions) rather than asking mid-discovery.
- `full` — may create the shaped tickets directly when the brief is unambiguous and a tracker is configured, posting the shaped structure as the audit trail. Still never creates a top-level **project/initiative container** without confirmation (containers are expensive to undo; the one carve-out is the L4 accepted-root envelope — a loop-authored container contained under the run's admitted root PRD), and the hard floor applies — no cancellation/deletion, ever.

## Logging

Write a log per the gateway `.faff/logging` rule: the detected mode, which intake skill ran, the discovery brief, the methodology's proposed structure, what was created (ids + relationships), and any chain to `/faff-prep`. Enough that a follow-up agent can see how this backlog came to exist. For the **existing-ticket interactor**, log the ticket id and that it was loaded for inspection. This narrative `HHMMSS-jot.md` write is subject to the gateway logging gate (skip the narrative write when `logging: essential`).

## Rules

- One skill for all new-work intake — never spawn per-type variants (`faff-new-bug`, `faff-new-feature`). Mode is a parameter, not a separate command. The existing-ticket interactor follows the same principle: it's selected by the issue-id **argument**, not a separate command.
- The existing-ticket interactor (`/faff-jot ISSUE-XX`) is **inspection-only in v1** (shaping verbs deferred) and **interactive-only**. It never specs (→ `/faff-prep`), grooms (→ `/faff-tidy`), or builds (→ `/faff-graft`), never re-runs discovery on a ticket that already exists, and never edits the ticket's title/description/status in place.
- Discovery is delegated (`intake` slot), shaping is delegated (`methodology` slot). `/faff-jot` orchestrates: detect mode, route the brief, confirm, create, chain. It owns no ideation opinions and no structural opinions of its own.
- Never write a spec here. A created ticket is a `Backlog` item with a seeded description and open questions — `/faff-prep` turns it into a buildable spec. (A description is never a spec — gateway shared rule.)
- Ticket creation is gated on human confirmation except at `full` appetite for non-container tickets. Containers always confirm (except within the L4 accepted-root envelope).
- Chaining uses the standard explicit yes/no gate (gateway → Chaining pattern). No passive "you should run /faff-prep next".
