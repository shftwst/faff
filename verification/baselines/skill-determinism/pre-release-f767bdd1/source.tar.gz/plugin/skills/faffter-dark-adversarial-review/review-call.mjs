#!/usr/bin/env node
// FAFF-183 — robust adversarial-review backend call, originally for ollama.
//
// Replaces the agent-hand-rolled API call (which broke five ways on a real backend: no model
// preflight, empty content from reasoning models, dropped connections on long responses, no token
// budget, and diff-only context that made the reviewer hallucinate "this heading doesn't exist").
// Per deterministic-tools-over-prose, the robust call is a tool, not prose.
//
// FAFF-872: the native ollama transport family (a dedicated /api/tags + /api/chat NDJSON path) was
// folded onto the OpenAI-compatible /v1 path below — ollama and oMLX both serve /v1/chat/completions,
// so neither needs a wire format of its own. Two transport families remain: OpenAI-compatible (the
// shape every non-anthropic backend uses, ollama included) and anthropic native (kept — Claude's
// extended thinking cannot cross to a plain /v1/chat/completions).
//
// The pure functions (buildOpenAiPayload / modelServedOpenAi / accumulateSse / assembleUserMessage)
// carry no I/O and are unit-tested directly; the transport (getFn/streamFn) is injectable so CI makes
// ZERO real calls. Zero-dependency: node:http(s)/node:fs only.

import http from "node:http";
import https from "node:https";
import { readFileSync, writeFileSync, mkdirSync, existsSync } from "node:fs";
import { join as pathJoin, dirname as pathDirname, resolve as pathResolve } from "node:path";
import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";

// Exit codes the skill maps to a verdict: 0 ok · 4 model-not-served (→ needs-human) ·
// 5 provider-unreachable, explicitly-configured host (→ pass+skip) ·
// 6 provider-unreachable, unconfigured localhost default (→ needs-human, FAFF-213) ·
// 7 auth-failed (cloud creds / unset key env, → needs-human, FAFF-209) · 2 usage · 1 other ·
// 9 mandatory-chain-outage — a MANDATORY (L4 --lights-out) review's chain exhausted with no opinion
//   obtained (all UNREACHABLE/5 or DEADLINE/8), which fails CLOSED → needs-human (FAFF-398).
// 10 malformed (FAFF-194/FAFF-465) — a reachable+served backend's OK content is SUBSTANTIVE (non-empty,
//   not a refusal) but not findings-shaped (no recognised `### <severity>:` section) — a genuine
//   reachable-but-degraded model-quality symptom, per-backend, an AVAILABILITY class (a garble-only
//   exhausted chain collapses to UNREACHABLE/5 — never a needs-human terminal exit on its own).
// 11 no-findings-content (FAFF-465) — a reachable+served backend's OK content is EMPTY/whitespace-only,
//   or a closed-grammar provider REFUSAL — an operator-fixable structural inability (same class as a
//   wrong/incapable model), per-backend, member of CHAIN_NEEDS_HUMAN (never masked by an otherwise-
//   available chain — this is the split that makes a full-chain exhaustion's terminal disposition
//   deterministic on a stable response property, not on the incidental run-to-run failure-class mix).
export const EXIT = { OK: 0, OTHER: 1, USAGE: 2, NOT_SERVED: 4, UNREACHABLE: 5, DEFAULT_HOST_UNREACHABLE: 6, AUTH: 7, DEADLINE: 8, MANDATORY_OUTAGE: 9, MALFORMED: 10, NO_FINDINGS_CONTENT: 11, RATE_LIMITED: 12 };
// FAFF-329: DEADLINE(8) — the Phase-2 total wall-clock budget (--deadline) was hit before any backend
// produced findings. Distinct from UNREACHABLE(5) so a deadline-skip is observable, but the caller routes
// it IDENTICALLY: pass + skip the second opinion, logged loudly (a bounded turn beats an unbounded stall;
// the hard merge gate — AC + CI + Phase-1 pass — is untouched). A config fault (needs-human class) seen on
// an earlier backend still DOMINATES (surfaced instead of 8) — the no-silent-weakening invariant.
export const DEFAULT_NUM_PREDICT = 2000;

// FAFF-928: per-body byte cap for retained raw adversarial-review response bodies. A captured body
// larger than this is truncated with an explicit marker (see captureRawResponseBody); the 2000-token
// default num_predict is far under it, so the common case is retained whole.
export const RAW_BODY_MAX_BYTES = 256 * 1024;   // 256 KB

// FAFF-885: the DEFAULT per-attempt first-byte (time-to-first-token) window, in ms. Applied at the CLI
// boundary (main) as the DEFAULT-ON value when neither a per-backend `first_byte_timeout` nor the
// `--first-byte-timeout` flag is set. 60s is generous relative to the 120s inactivity timeout — a healthy
// streaming backend delivers its first token well inside it — while cutting a buffering backend's idle
// hang from ~3x timeout to ~60s. runReview* default firstByteMs to undefined (pass-through), so a direct
// programmatic/test call is byte-for-byte unchanged; only main() opts in the default.
export const DEFAULT_FIRST_BYTE_MS = 60000;

// PURE (FAFF-213): map an unreachable result to its exit code by host provenance. An explicitly-
// configured host that's down → EXIT.UNREACHABLE (5 → pass+skip, the human's call). A host that's
// only the documented localhost default because nothing was configured → EXIT.DEFAULT_HOST_UNREACHABLE
// (6 → needs-human) — an absent provider block must not invisibly disable the review (cf. exit 4).
// review-call can't infer provenance from the host string (localhost is a legit configured host), so
// the caller signals it via --host-source; this is the one place the policy decision lives.
export function unreachableExit({ hostSource } = {}) {
  return hostSource === "default" ? EXIT.DEFAULT_HOST_UNREACHABLE : EXIT.UNREACHABLE;
}

// Transport families (FAFF-872: down from three to two). openai speaks the OpenAI-compatible
// /v1/models + /v1/chat/completions (SSE) shared by OpenAI, vLLM, OpenRouter, NVIDIA NIM
// (integrate.api.nvidia.com/v1), DeepSeek, etc. gemini rides that same family via Google's documented
// OpenAI-compatibility base URL (https://generativelanguage.googleapis.com/v1beta/openai), so it needs
// no adaptor of its own — just the whitelist entry (FAFF-210). ollama is now an ALIAS into this same
// family rather than a native transport: it also serves /v1/chat/completions, and /v1/models is an
// equivalent model-served preflight to the deleted native /api/tags check (parity confirmed — both
// fail loud, "model-not-served", on a mismatch). A bare (non-/v1) ollama host therefore now fails loud
// at preflight instead of silently routing nowhere — the deliberate migration signal; there is no
// auto-rewrite of a bare host to add /v1 (a config edit, not a runtime rewrite). The unset-provider
// default is now "openai" too (there is no longer a native family to default to). anthropic has a
// native wire format (/v1/messages: top-level system, content blocks, x-api-key + anthropic-version
// headers, max_tokens required) and keeps its own family — Claude's extended thinking cannot cross to
// a plain /v1/chat/completions, so it is the one family kept native by design. An unknown provider
// still returns "unsupported-provider".
export function providerFamily(name) {
  const n = String(name || "openai").toLowerCase();
  if (["openai", "vllm", "openrouter", "nvidia", "deepseek", "openai-compatible", "gemini", "ollama"].includes(n)) return "openai";
  if (n === "anthropic") return "anthropic";
  return n; // unknown — runReview returns status "unsupported-provider"
}

// PURE: join an OpenAI-style base URL (host already ends in /v1) with an endpoint path, without
// the new URL("/models", base) trap that would drop the /v1 prefix.
export function joinUrl(base, path) {
  return String(base).replace(/\/+$/, "") + path;
}

// PURE: the user message — context files (every file the diff touches, so the reviewer can verify
// existence/structure claims) fenced ahead of the diff. This is the fix for diff-only hallucination.
export function assembleUserMessage({ contextFiles = [], diff = "" }) {
  let s = "";
  for (const f of contextFiles) s += `<file path="${f.path}">\n${f.text}\n</file>\n\n`;
  s += `DIFF UNDER REVIEW:\n\n${diff}`;
  return s;
}

// FAFF-445: oversized-diff preflight — a conservative default well below the request-body limits
// commonly enforced by LLM API gateways (frequently 10MB+), chosen so a payload this large already
// all but guarantees either an outright 413 or such a degraded/truncated review that flagging it up
// front is strictly better than attempting the dispatch (see the FAFF-445 spec, Decision 1).
export const DEFAULT_MAX_PAYLOAD_BYTES = 5_000_000; // 5MB

// PURE (FAFF-445): does the assembled payload (system + user — the exact two strings every chain
// element's orchestration function places in its wire request) exceed a size threshold? Checked ONCE,
// before the fallback chain is entered, so an oversized diff is flagged deterministically at zero
// network cost rather than discovered only via a provider 413 mid-chain (FAFF-414 hardened the
// *reaction* to that throw; this guards the *precondition* that produces it — the two compose, neither
// supersedes the other). Strict `>` — a payload sitting exactly on the boundary dispatches normally.
export function checkPayloadSize({ system, user, maxBytes = DEFAULT_MAX_PAYLOAD_BYTES } = {}) {
  const bytes = Buffer.byteLength(String(system == null ? "" : system), "utf8")
    + Buffer.byteLength(String(user == null ? "" : user), "utf8");
  return { oversized: bytes > maxBytes, bytes, maxBytes };
}

// --- FAFF-915: diff-relevance context trim -------------------------------------------------------
//
// Reasoning reviewers empty out on large review payloads: the model spends its whole output budget
// reasoning and emits zero findings. The context bundle (whole source files shipped as --context) is
// most of that payload while the diff only touches a few regions, so trimming the context to the
// diff-relevant regions roughly halves the payload and puts a reasoning-ON review back under the
// empty-out knee. This is the targeted context-trim (the lighter fix), NOT a general decomposer.
//
// The trim is a PURE function of (contextFiles, diff): identical inputs give identical output, so the
// trimmed context stays byte-identical across the four spec-review lenses (only --system differs) and
// remains a stable shared-prefix cache (FAFF-903). It is gated by a byte threshold — below the
// threshold the context passes through unchanged, so every existing review and its golden tests are
// byte-for-byte unaffected — and it never drops a line inside a diff-touched range (the conservative
// guarantee). See the FAFF-915 spec.

// The trim's fixed build defaults. Named constants (not magic numbers) so a later review-bench pass
// (FAFF-904) re-tunes them in one place; the trim's shape and contract never depend on the values.
export const DEFAULT_CONTEXT_TRIM_BYTES = 49152;   // 48 KB — below this assembled-context size the trim is a no-op
export const DEFAULT_MIN_FILE_TRIM_BYTES = 2048;   // 2 KB — a no-anchor file below this passes through untrimmed
export const DEFAULT_TRIM_WINDOW = 24;             // lines of context kept either side of each anchor
export const DEFAULT_TRIM_HEAD_LINES = 12;         // leading lines kept when a large no-anchor file is head-reduced
export const DEFAULT_MAX_ANCHOR_LINES = 40;        // a diff token anchoring more lines than this in a file is too common to anchor
export const DEFAULT_RETAINED_CEILING = 0.8;       // if a trimmed file still retains more than this fraction, head-reduce it instead

// --- FAFF-1039: per-backend context-window preflight ---------------------------------------------
//
// The fallback chain is tried strongest-first, but the decision to advance past a backend was made
// REACTIVELY — only once that backend threw an HTTP 400 for an over-window payload. Because the
// payload is sized against nothing but the coarse 5MB byte ceiling above, the strongest backend is
// dispatched into a guaranteed 400 whenever the diff touches a large module, and the review is served
// by a weaker fallback, visible only in one stderr line on an otherwise-green pass. So the strongest
// reviewer is silently unavailable for exactly the diffs most worth reviewing. These constants make
// the advance-decision PROACTIVE and window-aware, and make every primary skip loud.
//
// Opt-in and back-compatible: a backend with no declared context_window behaves exactly as before, so
// no existing review changes a single assembled byte.

export const DEFAULT_BYTES_PER_TOKEN = 3.0;      // conservative divisor: OVER-estimates tokens so the guard trips
                                                 //   early rather than late. Code averages ~3.5-4 utf8 bytes/token;
                                                 //   3.0 biases the estimate high on purpose.
export const DEFAULT_WINDOW_SAFETY = 0.9;        // usable fraction of a declared window (response + estimate-error headroom)
// Fixed token budget reserved for the per-lens --system brief when computing the trim target, so the
// target never depends on the ACTUAL brief length and the trimmed shared prefix stays byte-identical
// across the four spec-review lenses (the FAFF-903 cacheable prefix). MEASURED 2026-10-19 @ 3.0 B/tok,
// after the in-spec-ratification deferral clause was added to the three design lenses:
//   refute-infosec.md 7789 B ~2596 tok  <- binding   refute-architectural.md 7230 B ~2410 tok
//   refute-qa.md      6885 B ~2295 tok             refute-methodology.md   3336 B ~1112 tok
//   code-review "## Review lens" section 2020 B ~673 tok
// 2800 clears the 2596 binding constraint with ~8% headroom.
export const DEFAULT_BRIEF_RESERVE_TOKENS = 2800;
export const MIN_TRIM_TARGET_BYTES = 1024;       // trimTargetBytes never returns <= 0; this is its floor

// The machine-only, line-anchored primary-skip marker, mirroring TRUNCATION_SIGNAL exactly. Emitted on
// its own stderr line whenever the backend that served was not chain[0]. `fan-out.mjs` recognises it by
// line-anchored EQUALITY, never a substring scan, so untrusted diff/context echoed into findings can
// never forge it (the same unforgeability argument TRUNCATION_SIGNAL rests on).
export const PRIMARY_SKIP_SIGNAL = "[faff:primary-skipped]";

// PURE: normalise an operator-declared window to a positive integer, or null when absent/malformed.
// Every chain-assembly form converges on the review-call mapper, but only TWO of the four pass through
// backends.js's normalizeBackend (the `refs:` forms); the native `backends:` array and the legacy
// primary+fallbacks forms reach pickBackendKeys directly and carry the raw authored value. So the
// consumer boundary normalises too, and a malformed knob is inert on every path rather than only on
// the refs path.
export function normaliseContextWindow(v) {
  if (v === null || v === undefined || v === "") return null;
  const n = Number(v);
  return Number.isFinite(n) && n > 0 ? Math.floor(n) : null;
}

// PURE: conservative token estimate. Never returns fewer than utf8Bytes/bytesPerToken (ceil), which is
// the MUST invariant the guard's fail-early bias rests on.
export function estimateTokens(text, bytesPerToken = DEFAULT_BYTES_PER_TOKEN) {
  const bpt = Number(bytesPerToken) > 0 ? Number(bytesPerToken) : DEFAULT_BYTES_PER_TOKEN;
  return Math.ceil(Buffer.byteLength(String(text == null ? "" : text), "utf8") / bpt);
}

// PURE: does an estimated payload fit a declared window? An absent window is unbounded (true) — the
// opt-in guarantee: an un-annotated backend is never guard-skipped.
export function fitsWindow(estimatedTokens, contextWindow, safety = DEFAULT_WINDOW_SAFETY) {
  const w = normaliseContextWindow(contextWindow);
  if (w === null) return true;
  return Number(estimatedTokens) <= Math.floor(w * safety);
}

// --- the window budget trio ---------------------------------------------------------------------
//
// SHARED CONTRACT: the budget is for EVERYTHING IN THE PREFIX EXCEPT THE DIFF. The window has to
// accommodate context + diff + a fixed brief reserve, and the diff is not reducible, so it is
// subtracted out and what remains is what the trim has to work with. Callers therefore compare against
// `prefixBytes - diffBytes`, which is what `tightenToTarget` computes as `contextBytes`: that spelling
// is exact by construction (assembleUserMessage emits the diff verbatim exactly once) and charges the
// per-file `<file path=…>` wrappers and the `DIFF UNDER REVIEW:` header, which a bare sum of `f.text`
// would silently omit — about 25 bytes plus the path per file, which on a 30-file payload is ~2.5KB,
// more than the slack the brief reserve leaves. Comparing against the FULL assembled prefix instead
// would charge the diff twice and undershoot by exactly its size, silently over-trimming every
// diff-heavy review. All three depend only on (contextWindow, diff), never on any lens brief, so the
// prefix they govern stays byte-identical across lenses.
//
// The arithmetic lives in ONE place, `rawTrimBudgetBytes`. The floor and the was-it-floored question
// are derived from it rather than re-spelled, because a second copy is how the note and the target
// silently desynchronise.

// PURE: the budget before the floor is applied. May be negative or null (no declared window).
export function rawTrimBudgetBytes(contextWindow, diff = "") {
  const w = normaliseContextWindow(contextWindow);
  if (w === null) return null;
  return Math.floor(w * DEFAULT_WINDOW_SAFETY * DEFAULT_BYTES_PER_TOKEN)
    - Buffer.byteLength(String(diff == null ? "" : diff), "utf8")
    - Math.floor(DEFAULT_BRIEF_RESERVE_TOKENS * DEFAULT_BYTES_PER_TOKEN);
}

// PURE: the budget the search actually aims at — the raw budget, floored so it is never <= 0.
export function trimTargetBytes(contextWindow, diff = "") {
  const raw = rawTrimBudgetBytes(contextWindow, diff);
  if (raw === null) return null;
  return Math.max(MIN_TRIM_TARGET_BYTES, raw);
}

// PURE: was the budget driven below its floor by a large diff? When it was, `trimTargetBytes` returned
// the floor rather than a window-derived budget, so HITTING that target says nothing about fitting the
// window. The operator-facing note says so rather than implying a fit it cannot vouch for.
export function trimTargetClamped(contextWindow, diff = "") {
  const raw = rawTrimBudgetBytes(contextWindow, diff);
  return raw !== null && raw < MIN_TRIM_TARGET_BYTES;
}

// PURE: does the tightened payload STILL exceed the primary's usable window? This is deliberately NOT
// `tightenToTarget`'s `fitted`. `fitted` means "hit the byte target", and when a large diff drives the
// budget below MIN_TRIM_TARGET_BYTES the target clamps to that floor, so hitting it says nothing about
// fitting the window. Keying the operator-facing note off `fitted` would let it report a fit on a
// payload still well over the window, which is the same dishonesty the note exists to remove.
//
// `fitted` is unsafe in BOTH regimes, which is worth stating because the tempting algebra says
// otherwise: fitted gives contextBytes <= usableBytes - diffBytes - reserveBytes, which looks like it
// implies est + reserve <= usable. It does not, because estimateTokens CEILINGS, so a maximally-fitted
// payload can land a token over (w=65536, empty diff, demonstrated in the tests). And when the target
// is clamped to the floor it bears no relation to the window at all. Hence: key off the window.
export function stillOverWindow(estTokens, reserveTokens, usableTokens) {
  return Number(estTokens) + Number(reserveTokens) > Number(usableTokens);
}

// The descending trim-window ladder the search walks.
//
// WHY A SEARCH, not a threshold. `trimContextFiles`'s `thresholdBytes` is an ON/OFF GATE — below it the
// trim is an identity no-op — NOT a size target: the actual aggressiveness lives in `window` (lines kept
// either side of each anchor) and `headLines`. Any payload large enough to overflow a real context
// window is far above the 48KB default gate, so the default trim has ALREADY fired and re-running it
// with a different threshold reduces nothing. (That gate measures CONTEXT bytes only, so a
// small-context large-diff payload can overflow a window without it ever firing; the conclusion still
// holds in the regime that matters, since a context small enough to slip the gate is not what the trim
// is for, but the reason is narrower than it first reads.) To actually reach a byte target we have to tighten the
// knob that governs how much is kept. Every rung keeps every diff-touched line (trimOneFile's
// conservative guarantee), so the search never degrades to the diff-only view that produced confident
// false criticals.
//
// A SMALLER WINDOW DOES NOT ALWAYS YIELD A SMALLER PREFIX. `trimOneFile`'s retained-ceiling fallback
// head-reduces a file whose kept fraction exceeds `retainedCeiling`; tightening the window can drop that
// fraction BELOW the ceiling, so the file stops being head-reduced and grows instead. Measured on a
// 400-line identifier-anchored file with no touched lines: rungs 24/16/10/6 give 1545 B and rung 3 gives
// 18527 B. So the search must take the MINIMUM across rungs, never merely the last one tried — which is
// what `tightenToTarget` does below, and what the monotonicity test pins.
export const TRIM_WINDOW_LADDER = Object.freeze([DEFAULT_TRIM_WINDOW, 16, 10, 6, 3, 1]);

// --- FAFF-1051 / FAFF-1058: the prose diff kind -------------------------------------------------
//
// The anchored trim above only means anything when `--diff` is a real unified diff. Three callers pass
// a markdown document instead (spec-review's lenses, faff-prep's spec-judge), and `parseDiffTouched`
// recovers no anchors from prose, so any reduction is head truncation, not relevance. A spec plus the
// files it names has no anchors to keep, so a partial spec review is worse than an honest over-window
// skip. FAFF-1058 therefore makes the "prose" kind a true pass-through: `trimContextFiles` returns the
// context unchanged (reason "prose-passthrough") and main() skips the FAFF-1039 window pass for prose,
// so both passes are no-ops at any size. Every silent caller stays on "unified", byte-for-byte unchanged.

// PURE: tighten the context bundle until the assembled prefix fits `targetBytes`, or the ladder is
// exhausted. Returns the first rung that fits (`fitted: true`), else the SMALLEST prefix seen across
// every rung (`fitted: false`) — never merely the last rung tried, because the ladder is not monotonic
// (see the note above: a tighter window can enlarge a head-reduced file). Returning the last rung there
// would let a "window-targeted trim" hand the chain a payload BIGGER than the one it started from,
// which is the exact inverse of the point. A residual overflow is not an error: the per-backend guard
// and the primary-skip surfacing handle it, and a smaller-but-still-over payload beats the un-narrowed
// one. `assembleFn` is injected so the search is testable independently of the module-level assembler.
// This is the anchored search only. main() never calls it for a prose diff (FAFF-1058 skips the whole
// FAFF-1039 window pass under the prose kind), so there is no head-only regime here.
export function tightenToTarget({ contextFiles = [], diff = "", targetBytes, assembleFn = assembleUserMessage } = {}) {
  const diffBytes = Buffer.byteLength(String(diff == null ? "" : diff), "utf8");
  let best = null;
  for (const rung of TRIM_WINDOW_LADDER) {
    const { contextFiles: trimmed } = trimContextFiles({ contextFiles, diff, thresholdBytes: 1, window: rung, diffKind: "unified" });
    const prefix = assembleFn({ contextFiles: trimmed, diff });
    const bytes = Buffer.byteLength(prefix, "utf8");
    // The fit is decided on everything-but-the-diff, because that is what trimTargetBytes budgets (it
    // already subtracted the diff). Derived as prefix minus diff rather than summed from f.text: exact
    // by construction, and it cannot drift if assembleUserMessage's framing ever changes.
    const contextBytes = bytes - diffBytes;
    if (targetBytes == null || contextBytes <= targetBytes) {
      return { contextFiles: trimmed, prefix, bytes, contextBytes, window: rung, headLines: DEFAULT_TRIM_HEAD_LINES, mode: "anchored", fitted: true };
    }
    // The min is tracked on PREFIX bytes, because the prefix is what gets sent.
    if (best === null || bytes < best.bytes) best = { contextFiles: trimmed, prefix, bytes, contextBytes, window: rung, headLines: DEFAULT_TRIM_HEAD_LINES };
  }
  return { ...best, mode: "anchored", fitted: false };
}

// A whole-word identifier token: a run of JS identifier characters. Length >= 3 is applied by the caller.
const IDENT_RE = /[A-Za-z_$][A-Za-z0-9_$]*/g;
// Closed stoplist (no "and similar"): common JS keywords too generic to be a relevance signal.
const IDENT_STOPLIST = new Set([
  "const", "let", "var", "function", "return", "import", "export", "default", "this", "new",
  "typeof", "void", "await", "async", "class", "extends", "super", "yield", "delete", "instanceof",
]);

// PURE (FAFF-915): the fixed elision-marker sentinel written in place of a dropped span. It carries the
// dropped-line count and can never equal a real source line, so a touched line is never mistaken for a
// marker (the survival oracle depends on this).
export function elisionMarker(n) {
  return `... ${n} line(s) elided (FAFF-915 relevance trim) ...`;
}

// PURE (FAFF-915): parse a unified diff into { touchedByPath, identifiers }.
// - touchedByPath: Map<full-path, Array<[startLine, endLine]>> of the new-file (+++) line ranges each
//   hunk touches. Keyed by the FULL path (a/ b/ prefixes stripped) — not the basename — so two context
//   files that share a basename (src/foo.js vs lib/foo.js) never cross-apply each other's ranges;
//   pathsMatch() below resolves a context path to a touched path by exact-or-suffix.
// - identifiers: Set of >=3-char identifier tokens named on the diff's +/- body lines, minus the
//   stoplist — a cheap textual stand-in for the diff's direct callers/callees.
// Fail-safe: an unparseable hunk header contributes no range for that hunk (never a wrong range).
export function parseDiffTouched(diff) {
  const touchedByPath = new Map();
  const identifiers = new Set();
  let hunks = 0;   // NEW (FAFF-1051): count of hunk headers parsed — 0 for a prose document with no
                   // "@@" line, additive, no existing caller deep-equals this return.
  // Strip a trailing CR so a CRLF-terminated diff's blank context lines are recognised (a bare "\r"
  // would otherwise fall through and desync the new-file counter).
  const lines = String(diff == null ? "" : diff).split("\n").map((l) => l.replace(/\r$/, ""));
  let curKey = null;   // full stripped path of the current +++ file
  let newLine = 0;     // running new-file line number inside the current hunk
  let oldRemain = 0;   // old-file body lines still expected in the current hunk (from the @@ header)
  let newRemain = 0;   // new-file body lines still expected in the current hunk
  const inHunk = () => oldRemain > 0 || newRemain > 0;   // a hunk is "open" until its declared counts are consumed
  const addRange = (key, a, b) => {
    if (!key) return;
    if (!touchedByPath.has(key)) touchedByPath.set(key, []);
    touchedByPath.get(key).push([a, b]);
  };
  for (const line of lines) {
    // Structural lines are only recognised BETWEEN hunks (counts exhausted). Inside an open hunk a
    // body line whose content begins with "+++ " / "--- " / "@@" is data, not a header — the declared
    // line counts, not a leading-token guess, decide where the hunk ends, so such content is parsed
    // correctly instead of being misread as the next file header.
    if (!inHunk()) {
      if (line.startsWith("+++ ")) {
        const p = line.slice(4).trim().split("\t")[0];
        curKey = p === "/dev/null" ? null : (p.replace(/^[ab]\//, "") || null);
        continue;
      }
      const m = line.match(/^@@\s+-\d+(?:,(\d+))?\s+\+(\d+)(?:,(\d+))?\s+@@/);
      if (m) {
        hunks += 1;   // NEW (FAFF-1051)
        oldRemain = m[1] === undefined ? 1 : Number(m[1]);   // b defaults to 1 when omitted
        newLine = Number(m[2]);
        newRemain = m[3] === undefined ? 1 : Number(m[3]);   // d defaults to 1 when omitted
        continue;
      }
      continue;   // any other between-hunk line (diff --git, index, --- , context noise) is ignored
    }
    // Inside an open hunk: classify by the leading marker and decrement the declared counts.
    const marker = line.charAt(0);
    if (marker === "+") {
      addRange(curKey, newLine, newLine);
      collectIdents(line.slice(1), identifiers);
      newLine += 1;
      if (newRemain > 0) newRemain -= 1;
    } else if (marker === "-") {
      collectIdents(line.slice(1), identifiers);   // a removed line names identifiers but consumes no new-file line
      if (oldRemain > 0) oldRemain -= 1;
    } else if (marker === "\\") {
      // "\ No newline at end of file" — a marker, not a body line; consumes no count.
    } else {
      // a context line (" " prefix, or a truly-empty blank context line) advances the new-file counter
      newLine += 1;
      if (oldRemain > 0) oldRemain -= 1;
      if (newRemain > 0) newRemain -= 1;
    }
  }
  return { touchedByPath, identifiers, hunks };
}

// PURE (FAFF-915): does a context-file path resolve to a touched diff path? Exact match, or either is
// a path-component suffix of the other (so a bare "review-call.mjs" matches "plugin/.../review-call.mjs",
// but "src/foo.js" never matches "lib/foo.js"). Strips a/ b/ prefixes on both sides. Full-path context
// paths (the normal caller shape) resolve unambiguously; a BARE-basename context path can still suffix-
// match more than one same-basename diff path, but the trim is keep-only (a wrong match over-retains,
// never under-retains a genuinely-relevant line), so the failure mode is safe.
export function pathsMatch(ctxPath, diffPath) {
  const norm = (p) => String(p || "").replace(/^[ab]\//, "");
  const a = norm(ctxPath);
  const b = norm(diffPath);
  if (!a || !b) return false;
  if (a === b) return true;
  return a.endsWith("/" + b) || b.endsWith("/" + a);
}

function collectIdents(text, out) {
  const found = String(text).match(IDENT_RE);
  if (!found) return;
  for (const t of found) {
    if (t.length >= 3 && !IDENT_STOPLIST.has(t)) out.add(t);
  }
}

// PURE (FAFF-915): does `line` contain token `t` as a whole word — delimited by a non-identifier
// character (or line start/end) on both sides, so `parse` does not match inside `parseArgs`?
function lineHasWholeWord(line, t) {
  let from = 0;
  for (;;) {
    const i = line.indexOf(t, from);
    if (i < 0) return false;
    const before = i === 0 ? "" : line[i - 1];
    const after = i + t.length >= line.length ? "" : line[i + t.length];
    const boundary = (c) => c === "" || !/[A-Za-z0-9_$]/.test(c);
    if (boundary(before) && boundary(after)) return true;
    from = i + 1;
  }
}

// PURE (FAFF-915): reduce one file's text to its head (first `headLines` lines) plus one elision
// marker for the dropped body. Used for a large no-anchor file and as the retained-ceiling fallback.
function headReduce(fileLines, headLines) {
  const h = Math.max(0, Math.trunc(headLines) || 0);   // clamp: a negative/NaN headLines never yields a bogus marker count
  if (fileLines.length <= h) return fileLines.join("\n");
  const kept = fileLines.slice(0, h);
  const dropped = fileLines.length - h;
  return kept.concat([elisionMarker(dropped)]).join("\n");
}

// PURE (FAFF-915): trim one file's text to its diff-relevant regions. Returns the trimmed text.
// Retained line set = diff-touched ranges (always) ∪ identifier-anchored lines, each expanded by a
// ±window and merged; a frequency-capped token (anchoring > maxAnchorLines lines) is dropped as too
// common; a file that would still retain > retainedCeiling is head-reduced instead. A no-anchor file
// below minFileBytes is returned unchanged; a larger no-anchor file is head-reduced.
export function trimOneFile(text, touchedRanges, identifiers, opts) {
  const { window, minFileBytes, headLines, maxAnchorLines, retainedCeiling } = opts;
  const fileLines = text.split("\n");
  const n = fileLines.length;
  const anchored = new Array(n).fill(false);   // an anchor line (touched or identifier)
  const touched = new Array(n).fill(false);    // a diff-touched line (never dropped, exempt from caps)

  // 1) diff-touched ranges (1-based, inclusive) — always anchors, and marked touched.
  for (const [a, b] of touchedRanges || []) {
    for (let ln = a; ln <= b; ln++) {
      const idx = ln - 1;
      if (idx >= 0 && idx < n) { anchored[idx] = true; touched[idx] = true; }
    }
  }

  // 2) identifier anchors, frequency-capped per file.
  for (const t of identifiers) {
    const hits = [];
    for (let i = 0; i < n; i++) if (lineHasWholeWord(fileLines[i], t)) hits.push(i);
    if (hits.length === 0 || hits.length > maxAnchorLines) continue;   // absent or too common → no anchors
    for (const i of hits) anchored[i] = true;
  }

  const anyAnchor = anchored.some(Boolean);
  const bytesOf = (s) => Buffer.byteLength(s, "utf8");

  // No anchors at all → protect small files, head-reduce large ones.
  if (!anyAnchor) {
    if (bytesOf(text) < minFileBytes) return text;   // small caller-selected file → untouched
    return headReduce(fileLines, headLines);
  }

  // 3) expand anchors by ±window, merge, emit kept spans + one marker per dropped gap.
  const keep = new Array(n).fill(false);
  for (let i = 0; i < n; i++) {
    if (!anchored[i]) continue;
    const lo = Math.max(0, i - window);
    const hi = Math.min(n - 1, i + window);
    for (let j = lo; j <= hi; j++) keep[j] = true;
  }
  // Touched lines are always kept regardless of any later reduction (the conservative guarantee).
  for (let i = 0; i < n; i++) if (touched[i]) keep[i] = true;

  const keptCount = keep.filter(Boolean).length;
  // 4) retained-ceiling fallback: if we would still keep too much, head-reduce. This is GUARDED by
  //    `!hasTouched` — a file with ANY diff-touched line is exempt from the ceiling entirely and keeps
  //    its full windowed set, so the head-reduce below can never drop a touched line (the conservative
  //    guarantee). The ceiling only ever reshapes a purely identifier-anchored file.
  const hasTouched = touched.some(Boolean);
  if (!hasTouched && keptCount / n > retainedCeiling) {
    return headReduce(fileLines, headLines);
  }

  const out = [];
  let gap = 0;
  for (let i = 0; i < n; i++) {
    if (keep[i]) {
      if (gap > 0) { out.push(elisionMarker(gap)); gap = 0; }
      out.push(fileLines[i]);
    } else {
      gap += 1;
    }
  }
  if (gap > 0) out.push(elisionMarker(gap));
  return out.join("\n");
}

// PURE (FAFF-915): the relevance filter over the whole context bundle. Below the byte threshold it is
// an identity no-op (byte-identical to today). thresholdBytes = 0 disables the trim entirely.
export function trimContextFiles({
  contextFiles = [],
  diff = "",
  thresholdBytes = DEFAULT_CONTEXT_TRIM_BYTES,
  window = DEFAULT_TRIM_WINDOW,
  minFileBytes = DEFAULT_MIN_FILE_TRIM_BYTES,
  headLines = DEFAULT_TRIM_HEAD_LINES,
  maxAnchorLines = DEFAULT_MAX_ANCHOR_LINES,
  retainedCeiling = DEFAULT_RETAINED_CEILING,
  diffKind = "unified",                                  // FAFF-1051: "unified" | "prose"
} = {}) {
  const bytesOf = (s) => Buffer.byteLength(String(s == null ? "" : s), "utf8");
  const bytesBefore = contextFiles.reduce((acc, f) => acc + bytesOf(f.text), 0);
  const filesTotal = contextFiles.length;

  // Gate: disabled (0) means no reduction at all, checked BEFORE the kind so it holds under both.
  if (!(thresholdBytes > 0)) {
    return { contextFiles, report: { trimmed: false, reason: "disabled", kind: diffKind, hunks: 0,
      headLines: null, filesTotal, bytesBefore, bytesAfter: bytesBefore } };
  }

  // FAFF-1058: prose is a true pass-through at any size. A spec plus the files it names has no diff
  // anchors, so any reduction would be head truncation; a partial spec review is worse than an honest
  // over-window skip. This branch returns the input unchanged; main() also skips the FAFF-1039 window
  // pass for prose, so both trim passes are no-ops.
  if (diffKind === "prose") {
    return { contextFiles, report: { trimmed: false, reason: "prose-passthrough", kind: "prose", hunks: 0,
      headLines: null, filesTotal, bytesBefore, bytesAfter: bytesBefore } };
  }

  // kind === "unified" (default) — today's byte gate + anchored reduction, UNCHANGED.
  if (bytesBefore <= thresholdBytes) {
    return { contextFiles, report: { trimmed: false, reason: "under-threshold", kind: "unified", hunks: 0,
      headLines: null, filesTotal, bytesBefore, bytesAfter: bytesBefore } };
  }
  const { touchedByPath, identifiers, hunks } = parseDiffTouched(diff);
  const opts = { window, minFileBytes, headLines, maxAnchorLines, retainedCeiling };
  const out = contextFiles.map((f) => {
    // Resolve this context file's touched ranges by full-path match (exact-or-suffix), so a shared
    // basename never cross-applies another file's ranges. Aggregate across all matching diff paths.
    const ranges = [];
    for (const [diffPath, rs] of touchedByPath) {
      if (pathsMatch(f.path, diffPath)) ranges.push(...rs);
    }
    const trimmedText = trimOneFile(f.text, ranges, identifiers, opts);
    return { path: f.path, text: trimmedText };
  });
  const bytesAfter = out.reduce((acc, f) => acc + bytesOf(f.text), 0);
  return { contextFiles: out, report: { trimmed: true, reason: "trimmed", kind: "unified", hunks,
    headLines: null, filesTotal, bytesBefore, bytesAfter } };
}

// --- FAFF-194: deterministic guards for machine-checkable findings + output-format enforcement ---
//
// The adversarial reviewer's findings are hypotheses from a deliberately fallible LLM; two things the
// harness should settle itself rather than trust to the model: whether a "this is a syntax error" claim
// is true (node --check answers that), and whether the raw output is findings-shaped at ALL (main() used
// to print whatever a backend streamed, even empty, as exit 0). Both move into this pure-function layer
// + one injectable check runner, so the LLM is spent only on judgement a tool can't verify.

// PURE: tolerant split of reviewer output into a preamble (everything before the first `### ` heading —
// e.g. the `## Adversarial findings — provider/model` header line) and an ordered list of finding
// sections. Each section spans from its `### ` heading line to (exclusive) the next one, or EOF. Severity
// is parsed from the heading; a heading with no recognised severity word still yields a section (raw
// findings-shape validation only cares that >=1 section has severity != null). `start`/`end` are the
// section's line-index bounds in `content.split("\n")` — carried so refuteFindings can splice the
// original lines array directly rather than re-stringify (see refuteFindings for why that matters).
// The heading test excludes `####`+ (an h4+ inside a finding body is not a NEW finding boundary).
const HEADING_LINE_RE = /^###\s(?!#)/;
const SEVERITY_HEADING_RE = /^###\s*\[?(critical|major|minor|observation)\]?\s*[:—-]\s*(.*)$/i;

export function splitFindings(content) {
  const text = String(content == null ? "" : content);
  const lines = text.split("\n");
  const headingIdxs = [];
  for (let i = 0; i < lines.length; i++) {
    if (HEADING_LINE_RE.test(lines[i])) headingIdxs.push(i);
  }
  if (headingIdxs.length === 0) return { preamble: text, sections: [] };
  const preamble = lines.slice(0, headingIdxs[0]).join("\n");
  const sections = [];
  for (let i = 0; i < headingIdxs.length; i++) {
    const start = headingIdxs[i];
    const end = i + 1 < headingIdxs.length ? headingIdxs[i + 1] : lines.length;
    const heading = lines[start];
    const body = lines.slice(start + 1, end).join("\n");
    const raw = lines.slice(start, end).join("\n");
    const m = heading.match(SEVERITY_HEADING_RE);
    const severity = m ? m[1].toLowerCase() : null;
    const title = m ? m[2] : heading.replace(/^###\s*/, "");
    sections.push({ heading, severity, title, body, raw, start, end });
  }
  return { preamble, sections };
}

// PURE (FAFF-465): a conservative, closed, anchored, case-insensitive, length-guarded refusal
// signature — the discriminator between an OK-status, non-empty response that is a provider REFUSAL
// (an operator-fixable structural inability, the SAME class as an empty body — EXIT.NO_FINDINGS_CONTENT)
// and genuine substantive garble (a reachable-but-degraded backend, an availability symptom —
// EXIT.MALFORMED). Anchored near the start of the trimmed content (a refusal typically opens with one
// of these) and length-guarded (a response longer than REFUSAL_MAX_LENGTH_CHARS never matches, however
// it opens), so a long rambling essay that merely mentions "I cannot" partway through is never
// misclassified as a refusal — it falls through to "garbled" instead. A fixed, unit-testable table, not
// an open-ended fuzzy match — mirrors the CLEAN_REFUTATIONS closed-grammar style (:196-202 below).
const REFUSAL_MAX_LENGTH_CHARS = 400;
// Adversarial-review finding (Phase 2, real backend call): two of the six patterns had no `^` anchor at
// all — a substring match anywhere in the (already length-guarded) content. A short, adjacent-but-
// legitimate finding using an unrecognised severity word (so it reaches this check at all — see
// validateFindingsShape below) could still contain "content policy" or the assist/help/comply phrase
// well past its opening and get misclassified `refusal` instead of `garbled`, reintroducing exactly the
// incidental-vocabulary non-determinism this split exists to remove. FIX: every pattern is now bounded to
// the first REFUSAL_PREFIX_CHARS of the trimmed content (`^[\s\S]{0,N}`, `[\s\S]` so an early newline
// doesn't defeat the bound) — a genuine refusal is a short, up-front statement, never something a model
// buries mid-response.
const REFUSAL_PREFIX_CHARS = 100;
const REFUSAL_PATTERNS = [
  /^i\s*(cannot|can'?t|won'?t|am\s+unable|'m\s+unable)\b/i,
  /^(sorry|i'?m sorry|i apologi[sz]e)[,.]?\s+(but\s+)?i\s*(cannot|can'?t|am\s+unable)\b/i,
  /^as an ai\b/i,
  /^i\s+(don'?t|do not)\s+(have|possess)\s+(the\s+)?(ability|capability)\s+to\b/i,
  new RegExp(`^[\\s\\S]{0,${REFUSAL_PREFIX_CHARS}}content policy`, "i"),
  new RegExp(`^[\\s\\S]{0,${REFUSAL_PREFIX_CHARS}}(cannot|can'?t|won'?t)\\s+(assist|help|comply)\\s+with\\s+(that|this)\\s+request`, "i"),
];

export function isProviderRefusal(content) {
  const trimmed = String(content == null ? "" : content).trim();
  if (!trimmed || trimmed.length > REFUSAL_MAX_LENGTH_CHARS) return false;
  return REFUSAL_PATTERNS.some((re) => re.test(trimmed));
}

// PURE: is this content findings-shaped? Non-empty AND at least one `### <severity>: ...` section with a
// severity in the closed set. When it is NOT, `kind` discriminates WHY (FAFF-465): "empty" (whitespace-
// only content), "refusal" (non-empty content matching the closed isProviderRefusal grammar — an
// operator-fixable structural inability), or "garbled" (non-empty, non-refusal content with no
// recognised finding section — a genuine reachable-but-degraded symptom). The caller maps empty/refusal
// to EXIT.NO_FINDINGS_CONTENT(11, needs-human) and garbled to EXIT.MALFORMED(10, availability) — see the
// call site in runReviewChain below.
export function validateFindingsShape(content) {
  const trimmed = String(content == null ? "" : content).trim();
  if (!trimmed) return { ok: false, reason: "empty content", kind: "empty" };
  const { sections } = splitFindings(content);
  if (!sections.some((s) => s.severity != null)) {
    if (isProviderRefusal(trimmed)) {
      return { ok: false, reason: "provider refusal", kind: "refusal" };
    }
    return { ok: false, reason: "no recognised finding section (### <severity>: ...)", kind: "garbled" };
  }
  return { ok: true };
}

// PURE (FAFF-746): the spec-refuter prompts define four exact no-objection responses. Accept only
// that closed grammar and mechanically translate it to the existing findings-shaped no-findings
// token. Matching is provider-neutral and deliberately strict: line endings, outer whitespace, and
// blank separator lines are formatting; every substantive byte remains case- and punctuation-sensitive.
export const CANONICAL_NO_FINDINGS = "### observation: no findings";
// FAFF-990: the exported truncation marker — a dedicated machine string emitted on its OWN stderr line
// (never a substring of the human "[note] response truncated…" sentence) when a served exit-0 response
// hit its token budget (`res.truncated`). `fan-out.mjs` imports THIS constant and sets
// `LensResult.truncated = true` iff a trimmed stderr line equals it exactly, so the truncation fact
// crosses to the spec-review classifier as a structured, unforgeable, single-sourced signal. The shared
// import is the single source of truth — a rename on either side breaks CI (the fan-out drift test),
// never production. Consumed structurally, never re-derived or prose-matched.
export const TRUNCATION_SIGNAL = "[faff:truncated]";
// FAFF-942: a lens may carry an optional `signal` — a lens-specific no-signal diagnostic line the
// refuter emits alongside its no-objection sentence. Only methodology has one (the no-critique case).
// It extends the closed grammar by exactly one recognised three-line `heading` + `signal` + `sentence`
// form; every substantive byte stays exact. Guard-clean prose AFTER the affirmation is tolerated
// (FAFF-1154), but a genuine finding, or a `## Refutation —` heading after it or for another lens before it,
// still rejects, indented or not.
export const CLEAN_REFUTATIONS = Object.freeze([
  Object.freeze({ lens: "architectural", heading: "## Refutation — architectural", sentence: "No architectural objection." }),
  Object.freeze({ lens: "infosec", heading: "## Refutation — infosec", sentence: "No infosec objection." }),
  Object.freeze({ lens: "methodology", heading: "## Refutation — methodology", sentence: "No methodology objection.", signal: "no methodology signal available." }),
  Object.freeze({ lens: "QA", heading: "## Refutation — QA", sentence: "No QA objection." }),
]);

// FAFF-927: a decorative header is any single ATX heading line that is NEITHER a severity-worded
// heading (that would make the content genuinely findings-shaped — swallowing it as clean would hide a
// real finding) NOR inside the reserved `## Refutation — <lens>` namespace (whose lens-consistency is
// already enforced by the `headed` arm below — a mismatched pair like `## Refutation — architectural` +
// `No QA objection.` must stay rejected). Every other decorative wrapper a model realistically emits
// (`# Code review`, `## Second opinion`, `### Assessment`) is accepted.
//
// FAFF-927 self-review fix: SEVERITY_HEADING_RE only matches the CANONICAL 3-hash `### <severity>:`
// form splitFindings itself parses. A backend can still state a real finding inside a severity-worded
// heading at a DIFFERENT ATX level — `## Critical: null check removed in parseDiff` followed by
// `No QA objection.` — which SEVERITY_HEADING_RE does not match, so it would have been accepted as
// decorative and the stated finding silently swallowed. SEVERITY_LIKE_HEADING_RE is level-agnostic
// (any of 1-6 hashes) so a severity-worded heading is excluded regardless of level, closing that gap
// without touching SEVERITY_HEADING_RE's own (unrelated) job of parsing genuine finding sections.
//
// FAFF-927 self-review fix: REFUTATION_NAMESPACE_RE originally matched only the exact 2-hash,
// em-dash-only, exact-case canonical spelling. A near-miss spelling — `### Refutation — architectural`
// (3 hashes), `## Refutation - architectural` (plain hyphen), or `## refutation — architectural`
// (lower-case) — fell outside the namespace and was accepted as decorative, letting a lens-mismatched
// clean sentence (e.g. paired with `No QA objection.`) through as `header-wrapped` instead of staying
// rejected like the exact-spelling FAFF-746 fixtures. Widened to any heading level, either dash form,
// and case-insensitive matching so the namespace exclusion holds under punctuation/case/heading-level
// drift, not just the one canonical spelling.
const ATX_HEADING_RE = /^#{1,6}\s+\S/;
const SEVERITY_LIKE_HEADING_RE = /^#{1,6}\s*\[?(critical|major|minor|observation)\]?\s*[:—-]/i;
const REFUTATION_NAMESPACE_RE = /^#{1,6}\s+Refutation\s+[—-]/i;
const MID_LINE_SEVERITY_RE = /#{1,6}\s*\[?(critical|major|minor|observation)\]?\s*[:—-]/i;
const MID_LINE_NAMESPACE_RE = /#{1,6}\s+Refutation\s+[—-]/i;
// FAFF-1223: a triple/anchor bullet. A LOCAL COPY of parse-refutation.mjs's BULLET_RE (this skill
// imports nothing from faffter-dark-spec-review); test/adversarial-call.test.mjs pins the two to the
// same grammar.
export const FINDING_BULLET_RE = /^-\s*(?:\*{1,2}|_{1,2})?(claim|evidence|predicted_consequence|spec_anchor)(?:\*{1,2}|_{1,2})?\s*:\s*(?:\*{1,2}|_{1,2})?\s*(.*)$/i;

function matchAffirmation(line) {
  for (const entry of CLEAN_REFUTATIONS) {
    if (line === entry.sentence) return { entry, remainder: "" };
    if (line.startsWith(entry.sentence) && /[ \t]/.test(line[entry.sentence.length])) {
      return { entry, remainder: line.slice(entry.sentence.length).trim() };
    }
  }
  return null;
}

// FAFF-1238: the guard scans (preamble and trailing) test a line with its leading spaces and tabs
// removed, so an indented severity or `## Refutation —` heading cannot slip past the column-0 regexes.
// Strips `[ \t]` only (not `trimStart()`): Markdown indentation is spaces and tabs, and a non-breaking
// space is not an indent. The regexes themselves stay column-0 for `isDecorativeHeader`.
function isGuardHeading(line) {
  const t = line.replace(/^[ \t]+/, "");
  return SEVERITY_LIKE_HEADING_RE.test(t) || REFUTATION_NAMESPACE_RE.test(t);
}

function isDecorativeHeader(line) {
  if (!ATX_HEADING_RE.test(line)) return false;
  if (SEVERITY_LIKE_HEADING_RE.test(line)) return false;
  if (REFUTATION_NAMESPACE_RE.test(line)) return false;
  return true;
}

// FAFF-1053: a reasoning backend can stream its visible deliberation into the content channel before
// emitting the canonical affirmation, so the whole-body, exact-line-count premise above (every arm
// gated on `lines.length === 1/2/3`) fails any body with a preamble and falls through to `malformed`,
// discarding a correct no-findings verdict on POSITION rather than content. Fixed by matching a
// SEGMENT of the body instead of the whole body: the line(s) directly above the affirmation decide
// the form via the same per-entry/decorative logic the whole-body arms used, tried most-specific-first
// (`headed+signal` → `headed` → `header-wrapped`/`bare`) so no no-preamble body relabels. A heading
// directly above the affirmation that is neither this entry's own heading nor a decorative header (a
// wrong-lens `## Refutation —` namespace hit or a severity-worded heading) stays rejected exactly as
// the whole-body `headed` arm did — never silently falls through to `bare`.
//
// The affirmation is the last line that is, or starts with, an affirmation sentence followed by
// whitespace; guard-clean prose may follow it on the same line or on later lines. Three guards keep
// clean meaning clean: a preamble guard (a severity or `## Refutation —` heading on any line before the
// matched form, except the entry's own heading), a same-line guard (the unanchored `MID_LINE_*_RE`
// forms, rejecting a severity heading or `## Refutation —` token anywhere in the remainder), and a
// trailing guard (the same heading test over every later line, own lens included). The preamble and
// trailing guards ignore leading spaces and tabs (FAFF-1238); that is deliberately stricter than the
// column-0 parsers, because rejection is fail-safe (the body is classed garbled and the chain advances).
//
// FAFF-1223: a triple/anchor bullet (`- claim:`, `- evidence:`, ...) anywhere outside the affirmation
// line, or in its same-line remainder, also rejects. A severity-less finding followed by a clean
// sign-off is a contradiction, and normalising it to clean would drop the finding before the parser
// ever sees it.
export function normaliseCleanRefutation(content) {
  const original = String(content == null ? "" : content);
  const lines = original.replace(/\r\n?/g, "\n").trim().split("\n").filter((line) => line.trim() !== "");
  if (lines.length === 0) {
    return { content: original, normalised: false, lens: null, form: null };
  }

  // Scan from the end so the last affirmation wins when sentences are stacked.
  let affirmationIdx = -1;
  let entry = null;
  let remainder = "";
  for (let i = lines.length - 1; i >= 0; i--) {
    const match = matchAffirmation(lines[i]);
    if (match) {
      affirmationIdx = i;
      entry = match.entry;
      remainder = match.remainder;
      break;
    }
  }
  if (!entry) {
    return { content: original, normalised: false, lens: null, form: null };
  }

  // Trailing-segment guard (the bidirectional twin of the preamble guard below): a genuine finding
  // (`### <severity>:`, level-agnostic via SEVERITY_LIKE_HEADING_RE) or a wrong-lens/dangling
  // `## Refutation —` heading (REFUTATION_NAMESPACE_RE), indented or not, AFTER the affirmation must
  // never be swallowed by rewriting the body to clean. Fails toward rejection.
  if (remainder && (MID_LINE_SEVERITY_RE.test(remainder) || MID_LINE_NAMESPACE_RE.test(remainder))) {
    return { content: original, normalised: false, lens: null, form: null };
  }
  for (let i = affirmationIdx + 1; i < lines.length; i++) {
    if (isGuardHeading(lines[i])) {
      return { content: original, normalised: false, lens: null, form: null };
    }
  }

  // FAFF-1223: a triple/anchor bullet beside the affirmation (same-line remainder, or any other line).
  if (remainder && FINDING_BULLET_RE.test(remainder)) {
    return { content: original, normalised: false, lens: null, form: null };
  }
  for (let i = 0; i < lines.length; i++) {
    if (i !== affirmationIdx && FINDING_BULLET_RE.test(lines[i])) {
      return { content: original, normalised: false, lens: null, form: null };
    }
  }

  const above1 = affirmationIdx - 1 >= 0 ? lines[affirmationIdx - 1] : null;
  const above2 = affirmationIdx - 2 >= 0 ? lines[affirmationIdx - 2] : null;

  let form;
  let start; // index of the tail segment's first line — everything before it is preamble
  if (entry.signal != null && above1 === entry.signal && above2 === entry.heading) {
    form = "headed+signal";
    start = affirmationIdx - 2;
  } else if (above1 === entry.heading) {
    form = "headed";
    start = affirmationIdx - 1;
  } else if (above1 != null && ATX_HEADING_RE.test(above1)) {
    // A heading sits directly above the affirmation but is NOT this lens's own heading: either a
    // decorative wrapper (accept as header-wrapped) or a namespace/severity heading (a wrong-lens
    // pairing like FAFF-746's `## Refutation — architectural` + `No QA objection.` — reject, never
    // fall through to bare, with or without preceding preamble).
    if (isDecorativeHeader(above1)) {
      form = "header-wrapped";
      start = affirmationIdx - 1;
    } else {
      return { content: original, normalised: false, lens: null, form: null };
    }
  } else {
    form = "bare";
    start = affirmationIdx;
  }

  // Preamble guard (clean means clean): a severity-worded heading (SEVERITY_LIKE_HEADING_RE) or any
  // `## Refutation —` heading (REFUTATION_NAMESPACE_RE) anywhere before the matched tail segment,
  // indented or not, must never be discarded by a trailing clean affirmation. The one exemption is this
  // entry's own heading, matched exactly after a full trim.
  for (let i = 0; i < start; i++) {
    if (lines[i].trim() === entry.heading) continue;
    if (isGuardHeading(lines[i])) {
      return { content: original, normalised: false, lens: null, form: null };
    }
  }

  return { content: CANONICAL_NO_FINDINGS, normalised: true, lens: entry.lens, form };
}

// PURE (FAFF-361): the canonical, harness-authored findings header — provenance is harness data,
// never demanded from the fallible model (FAFF-194 design decision: normalise/prepend rather than
// park on a missing one). Extended by FAFF-361 to also carry the winner's chain position and host
// provenance (chain[<index>], host: <hostSource>) — the mechanical answer to "which configured
// backend actually served this?", the exact provenance a same-day reconstruction incident needed.
// provider defaults to "openai" (FAFF-872; mirrors the `tag` fallback in runReviewChain and the
// providerFamily default — there is no longer a native ollama family to default to) and hostSource
// defaults to "config" (back-compat for a caller that hasn't set it) when either is falsy.
export function attributionHeader(winner, index) {
  const w = winner || {};
  const provider = w.provider || "openai";
  const hostSource = w.hostSource || "config";
  return `## Adversarial findings — ${provider}/${w.model} (chain[${index}], host: ${hostSource})`;
}

const HEADER_LINE_RE = /^##[ \t]*Adversarial findings/i;

// Locate an existing header line's index, searching ONLY the preamble (before the first `### ` finding
// heading, exclusive) — never a finding body. Returns -1 when absent. Shared by ensureHeader (below) and
// main()'s "was a header already present" check, so both use the identical scoped definition of "present".
export function findHeaderLineIdx(lines) {
  const firstHeadingIdx = lines.findIndex((l) => HEADING_LINE_RE.test(l));
  const scopeEnd = firstHeadingIdx === -1 ? lines.length : firstHeadingIdx;
  for (let i = 0; i < scopeEnd; i++) if (HEADER_LINE_RE.test(lines[i])) return i;
  return -1;
}

// PURE: does `content` already carry a header line (searched preamble-only, never a finding body)?
export function hasHeader(content) {
  return findHeaderLineIdx(String(content == null ? "" : content).split("\n")) !== -1;
}

// PURE: replace an existing (possibly model-echoed, possibly wrong) header line with the canonical one, or
// prepend it when absent. A no-op (byte-identical) when the existing header already matches canonical.
// The search is scoped to the PREAMBLE (before the first `### ` finding heading) only — a finding BODY
// that legitimately quotes a `## Adversarial findings — …` line (e.g. citing a prior review for
// comparison) must never be rewritten; only the document's own provenance header may be.
export function ensureHeader(content, winner, index) {
  const header = attributionHeader(winner, index);
  const text = String(content == null ? "" : content);
  const lines = text.split("\n");
  const headerIdx = findHeaderLineIdx(lines);
  if (headerIdx !== -1) { lines[headerIdx] = header; return lines.join("\n"); }
  return `${header}\n\n${text}`;
}

// PURE: recall-tuned WITHIN the syntax/parse claim class only (v1 scope) — a finding asserting code
// "won't parse" / "is invalid syntax" / "fails to parse", etc. Crash/test-failure claims are OUT OF SCOPE
// (a green suite doesn't refute an uncovered-path claim); this regex intentionally never matches those.
// FAFF-1055: the last two alternatives are word-boundary-anchored — unanchored, "not (valid|…)" matched
// inside ordinary review prose like "does not validate" / "is not validated" / "cannot validate" (the
// leading \b additionally rejects "can·not valid·ate"), and "invalid (javascript|js|syntax)" matched as a
// prefix of "invalid json" / "invalid jsx". The other alternatives (syntax error, SyntaxError, won't/will
// not/fails to parse) were audited and don't prefix ordinary English, so they stay unanchored.
const SYNTAX_CLAIM_RE = /syntax error|SyntaxError|won'?t parse|will not parse|fails? to parse|\binvalid (javascript|js|syntax)\b|\bnot (valid|parseable|parsable)\b/i;

export function findSyntaxClaims(sectionText) {
  return SYNTAX_CLAIM_RE.test(String(sectionText == null ? "" : sectionText));
}

const JS_FAMILY_RE = /\.(m|c)?js$/i;
function isJsFamily(p) { return JS_FAMILY_RE.test(String(p == null ? "" : p)); }

// A char that continues a path/filename token — used to reject a match that is really a PREFIX of a
// longer named path (e.g. contextPaths containing both "src/foo.js" and "src/foo.js.bak": a mention of
// only the latter must not also count as naming the former).
const PATH_TOKEN_CHAR_RE = /[A-Za-z0-9_./-]/;

// PURE: is `path` named in `text` at a genuine path boundary (not merely a textual prefix of a longer
// path that's the one actually mentioned)? Used by claimTargets (below), the sole definition of "named"
// a finding's targets are resolved against (FAFF-1055 removed refuteFindings' own separate
// "named ANY context path at all" check — a section naming no JS-family path is untouched regardless of
// whether it names a non-JS one, so claimTargets' JS-family filter is the only gate that matters now).
function pathMentionedIn(text, path) {
  const idx = text.indexOf(path);
  if (idx === -1) return false;
  const before = idx > 0 ? text[idx - 1] : "";
  const after = idx + path.length < text.length ? text[idx + path.length] : "";
  return !PATH_TOKEN_CHAR_RE.test(before) && !PATH_TOKEN_CHAR_RE.test(after);
}

// PURE: which context paths does this finding's text name, filtered to JS-family (.js/.mjs/.cjs) — the
// only family `node --check` can settle. A path is "named" by substring match against the section text
// (heading + body), matching how the reviewer's own context files are fenced (assembleUserMessage) —
// BOUNDARY-CHECKED so a shorter path is never counted as named merely because it's a textual prefix of a
// longer one that happens to be mentioned instead.
export function claimTargets(sectionText, contextPaths) {
  const text = String(sectionText == null ? "" : sectionText);
  return (contextPaths || []).filter((p) => isJsFamily(p) && pathMentionedIn(text, p));
}

// The injectable check runner (the only new I/O) — real spawnSync("node", ["--check", path]); ok iff
// exit 0. Injectable exactly as getFn/streamFn are, so CI spawns nothing unless a test opts in.
export function realCheck(path) {
  const r = spawnSync("node", ["--check", path], { encoding: "utf8" });
  const ok = !r.error && r.status === 0;
  const output = String((r.stderr || r.stdout || (r.error && r.error.message) || "")).trim();
  return { ok, output };
}

// PURE-ISH (checkFn is the one injected side-effect): downgrade-only refutation pass over machine-checkable
// syntax claims. Precision over recall — a finding is downgraded ONLY when every file the claim can be tied
// to positively passes the check; any inability to tie the claim to a checkable file, or any check
// failure, leaves it untouched (a wrongly-downgraded true finding is the expensive error; a surviving false
// finding merely costs the implementor the status-quo disproof cycle). Never drops a finding — downgrades
// severity to `observation`, prefixes the title `[auto-refuted]`, and appends an evidence line, so the
// audit trail (what the reviewer got wrong) survives.
//
// Target resolution (contextPaths is the FULL context list, unfiltered — mirrors what the reviewer was
// actually shown): targets are exactly the JS-family context paths claimTargets() finds NAMED in the
// section text. FAFF-1055: a section naming NO context path is left UNTOUCHED — there is deliberately no
// fallback to sweeping every JS-family context path. A claim that cannot name a file is precisely the one
// least likely to be a real, mechanically-checkable syntax fault, and on a healthy repo an all-files sweep
// passes almost by construction, so the old fallback near-certainly demoted any syntax-shaped prose that
// named no file — including ordinary non-syntax review prose the (now-anchored) detector still slips past.
//
// Reconstruction: edits are applied by SPLICING the original `content.split("\n")` array in place (heading
// line rewritten, one evidence line inserted) rather than re-joining pre-computed section strings — the
// latter silently collapses blank-line separators between sections whenever at least one sibling section
// is refuted, corrupting untouched findings' spacing (caught in review). Splicing touches only the exact
// lines of a refuted section, so every untouched section's original bytes — including its surrounding
// blank-line separators — survive verbatim. Sections are edited LAST-to-FIRST so an earlier section's
// line-index bounds (computed once, up front) stay valid across the whole pass.
export function refuteFindings(content, contextPaths, { checkFn = realCheck } = {}) {
  const text = String(content == null ? "" : content);
  const paths = contextPaths || [];
  const { sections } = splitFindings(content);
  const refutations = [];
  const outLines = text.split("\n");

  for (let idx = sections.length - 1; idx >= 0; idx--) {
    const s = sections[idx];
    if (s.severity == null) continue;
    if (!findSyntaxClaims(s.raw)) continue;

    const targets = claimTargets(s.raw, paths);
    if (targets.length === 0) continue;   // named-path gate — no file named, no generic all-JS sweep

    const results = targets.map((t) => checkFn(t));
    if (!results.every((r) => r && r.ok)) continue;   // any check failure — the reviewer may be right

    refutations.push({ title: s.title, files: targets, from: s.severity });
    const files = targets.join(", ");
    const newTitle = `[auto-refuted] ${s.title}`;
    const evidence = `> auto-refuted: node --check passed on ${files} — syntax claim mechanically disproved (was ${s.severity})`;

    // Insert the evidence line right after the section's LAST non-blank line (searching backward from
    // s.end, exclusive, down to s.start+1) — this lands it after real content and leaves any ORIGINAL
    // trailing blank-line separator before the next heading (or EOF) exactly where it was.
    let insertAt = s.start + 1;   // default: no body lines at all — right after the (rewritten) heading
    for (let li = s.end - 1; li > s.start; li--) {
      if (outLines[li].trim() !== "") { insertAt = li + 1; break; }
    }
    outLines[s.start] = `### observation: ${newTitle}`;
    outLines.splice(insertAt, 0, evidence);
  }

  if (refutations.length === 0) return { content, refutations: [] };
  return { content: outLines.join("\n"), refutations: refutations.reverse() };
}

// --- Fixture-data severity cap ---

// The severities the cap rewrites to `minor`. Equal to the autonomous-escalation set in SKILL.md
// (ESCALATE_SEVERITIES): widening that set means widening this one, or a fixture finding escalates.
export const FIXTURE_CAP_SEVERITIES = Object.freeze(new Set(["critical"]));

// Local mirror of bin/lib/review-fixture-paths.js isFixturePath — this file has no faff CommonJS
// imports. test/review-fixture-paths.test.mjs pins the two to the same table.
export function isFixturePath(path, prefixes) {
  const p = String(path).replace(/^(a\/|b\/|\.\/)/, "");
  return (prefixes || []).some((prefix) => p.startsWith(prefix) || p.includes(`/${prefix}`));
}

function normaliseFixturePrefix(entry) {
  const trimmed = String(entry).trim().replace(/^(\.\/|\/)+/, "");
  if (trimmed === "") return null;
  return trimmed.endsWith("/") ? trimmed : `${trimmed}/`;
}

const IDENTIFIER_RE = /[A-Za-z_][A-Za-z0-9_]{3,}/g;

function identifierTokens(text) {
  return new Set(String(text).replace(/\\[nrt"\\]/g, " ").match(IDENTIFIER_RE) || []);
}

function diffHeaderPath(raw) {
  const p = raw.trim().split("\t")[0];
  return p === "/dev/null" ? null : (p.replace(/^[ab]\//, "") || null);
}

function gitHeaderPaths(rest) {
  const half = (rest.length - 5) / 2;
  if (Number.isInteger(half) && rest.slice(0, 2) === "a/" && rest.slice(2 + half, 5 + half) === " b/" && rest.slice(2, 2 + half) === rest.slice(5 + half)) {
    return [rest.slice(2, 2 + half)];
  }
  const m = rest.match(/^a\/(\S+) b\/(\S+)$/);
  return m ? [m[1], m[2]] : [];
}

// PURE: every file path a unified diff names (diff --git, --- and +++ headers; a deleted or renamed
// file still counts) and the identifier tokens on each file's added lines. Hunk bodies are walked by
// their declared line counts, as parseDiffTouched does, so a body line that reads "+++ x" is data.
export function parseDiffFiles(diff) {
  const paths = new Set();
  const addedTokens = new Map();
  const addedKeys = new Map();
  const lines = String(diff == null ? "" : diff).split("\n").map((l) => l.replace(/\r$/, ""));
  let current = null;
  let oldRemain = 0;
  let newRemain = 0;
  const notePath = (p) => { if (p) paths.add(p); };
  for (const line of lines) {
    if (oldRemain > 0 || newRemain > 0) {
      const marker = line.charAt(0);
      if (marker === "+") {
        if (current) {
          if (!addedTokens.has(current)) addedTokens.set(current, new Set());
          for (const t of identifierTokens(line.slice(1))) addedTokens.get(current).add(t);
          if (!addedKeys.has(current)) addedKeys.set(current, new Set());
          for (const m of line.matchAll(/"([A-Za-z_][A-Za-z0-9_]*)"\s*:/g)) addedKeys.get(current).add(m[1]);
        }
        if (newRemain > 0) newRemain -= 1;
      } else if (marker === "-") {
        if (oldRemain > 0) oldRemain -= 1;
      } else if (marker !== "\\") {
        if (oldRemain > 0) oldRemain -= 1;
        if (newRemain > 0) newRemain -= 1;
      }
      continue;
    }
    if (line.startsWith("diff --git ")) {
      gitHeaderPaths(line.slice("diff --git ".length)).forEach(notePath);
    } else if (line.startsWith("--- ")) {
      notePath(diffHeaderPath(line.slice(4)));
    } else if (line.startsWith("+++ ")) {
      current = diffHeaderPath(line.slice(4));
      notePath(current);
    } else {
      const m = line.match(/^@@\s+-\d+(?:,(\d+))?\s+\+\d+(?:,(\d+))?\s+@@/);
      if (m) {
        oldRemain = m[1] === undefined ? 1 : Number(m[1]);
        newRemain = m[2] === undefined ? 1 : Number(m[2]);
      }
    }
  }
  return { paths, addedTokens, addedKeys };
}

// Like pathMentionedIn, but checks every occurrence and tolerates a sentence-ending "." after the path
// ("...see eval/cases/a.json."), which pathMentionedIn would read as part of a longer filename.
function pathNamedIn(text, path) {
  for (let idx = text.indexOf(path); idx !== -1; idx = text.indexOf(path, idx + 1)) {
    const before = idx > 0 ? text[idx - 1] : "";
    const after = text[idx + path.length] ?? "";
    const afterNext = text[idx + path.length + 1] ?? "";
    const endsCleanly = !PATH_TOKEN_CHAR_RE.test(after) || (after === "." && !PATH_TOKEN_CHAR_RE.test(afterNext));
    if (!PATH_TOKEN_CHAR_RE.test(before) && endsCleanly) return true;
  }
  return false;
}

function samePath(a, b) {
  return a === b || a.endsWith(`/${b}`) || b.endsWith(`/${a}`);
}

// Generic words and fixture keys that say nothing about where a defect lives.
const GENERIC_TOKENS = new Set(["diff", "code", "spec", "fixture", "case", "comment", "json", "test", "input", "output", "string", "value", "name", "file", "path", "kind", "oracle", "note", "expected", "actual", "data"]);

// An identifier specific enough to attribute a defect: camelCase, snake_case or digit-bearing, never a
// plain word (plain words recur in any fixture's prose).
function isSpecificToken(t) {
  return !GENERIC_TOKENS.has(t.toLowerCase()) && /[a-z][A-Z]|_|[0-9]/.test(t.replace(/^_+/, ""));
}

function originTokens(raw, title) {
  const tokens = new Set([...identifierTokens(title)].filter((t) => /[a-z][A-Z]/.test(t)));
  for (const m of raw.matchAll(/`([^`\n]+)`/g)) {
    for (const t of identifierTokens(m[1])) tokens.add(t);
  }
  return new Set([...tokens].filter(isSpecificToken));
}

const PATH_LIKE_RE = /[A-Za-z0-9_.-]+(?:\/[A-Za-z0-9_.-]+)+|[A-Za-z0-9_-]+(?:\.[A-Za-z0-9_-]+)*\.(?:mjs|cjs|js|ts|json|md|ya?ml|sh|py)\b/g;

// A path-like token in the finding that is not a fixture path and is real code: part of the PR, or on
// disk under repoRoot. Paths that exist nowhere (quoted inside a fixture's embedded diff) do not count;
// an unreadable filesystem counts as real, so the finding keeps its severity.
function namesRealCode(raw, prPaths, prefixes, repoRoot) {
  for (const m of raw.matchAll(PATH_LIKE_RE)) {
    const p = m[0].replace(/^\.\//, "");
    if (isFixturePath(p, prefixes) || isFixturePath(`${p}/`, prefixes)) continue;
    const matched = prPaths.filter((q) => samePath(q, p));
    if (matched.length > 0) {
      if (matched.some((q) => !isFixturePath(q, prefixes))) return true;
      continue;
    }
    try {
      if (existsSync(pathResolve(repoRoot, p))) return true;
    } catch {
      return true;
    }
  }
  return false;
}

// PURE: cap a Phase-2 finding of a FIXTURE_CAP_SEVERITIES severity to `minor` when it can be tied to
// fixture files and to nothing else. Precision over recall: any doubt leaves the finding as it was.
// Never drops a finding. Edits splice the original lines last-to-first (as refuteFindings does) so
// untouched sections keep their exact bytes.
//
// Attribution: a finding that names any real-code path (in the PR or on disk) is never capped; one that
// names PR paths is capped only if every named path is a fixture path; one that names none is capped
// only when the whole PR is fixture files. Either way a specific identifier of the defect (backtick
// code spans, or a camelCase title word) must be on an added non-key line of a candidate fixture file
// and on no added line of a non-fixture file, so a defect in unchanged loader code that merely names a
// fixture keeps its severity.
export function capFixtureFindings(content, diff, contextPaths, prefixes, repoRoot = process.cwd()) {
  if (!prefixes || prefixes.length === 0) return { content, caps: [] };
  const text = String(content == null ? "" : content);
  const { sections } = splitFindings(text);
  const { paths: diffPaths, addedTokens, addedKeys } = parseDiffFiles(diff);
  const prPaths = [...new Set([...diffPaths, ...(contextPaths || [])])];
  const allFixturePr = prPaths.length > 0 && prPaths.every((p) => isFixturePath(p, prefixes));
  const realTokens = new Set();
  for (const [file, tokens] of addedTokens) {
    if (!isFixturePath(file, prefixes)) for (const t of tokens) realTokens.add(t);
  }
  const candidateTokens = (candidates) => {
    const out = new Set();
    for (const [file, tokens] of addedTokens) {
      if (!candidates.some((c) => samePath(c, file))) continue;
      const keys = addedKeys.get(file);
      for (const t of tokens) if (!keys || !keys.has(t)) out.add(t);
    }
    return out;
  };

  const caps = [];
  const outLines = text.split("\n");
  for (let idx = sections.length - 1; idx >= 0; idx--) {
    const s = sections[idx];
    if (!FIXTURE_CAP_SEVERITIES.has(s.severity)) continue;
    if (namesRealCode(s.raw, prPaths, prefixes, repoRoot)) continue;
    const named = prPaths.filter((p) => pathNamedIn(s.raw, p));
    let candidates;
    if (named.length > 0) {
      if (!named.every((p) => isFixturePath(p, prefixes))) continue;
      candidates = named;
    } else if (allFixturePr) {
      candidates = prPaths;
    } else {
      continue;
    }
    const onFixtureLines = candidateTokens(candidates);
    const hasOrigin = [...originTokens(s.raw, s.title)].some((t) => onFixtureLines.has(t) && !realTokens.has(t));
    if (!hasOrigin) continue;

    caps.push({ title: s.title, from: s.severity, files: candidates });
    const evidence = `> fixture-data: located only in fixture path(s) ${candidates.join(", ")}; capped from ${s.severity} (test data, not shipped code)`;
    let insertAt = s.start + 1;
    for (let li = s.end - 1; li > s.start; li--) {
      if (outLines[li].trim() !== "") { insertAt = li + 1; break; }
    }
    outLines[s.start] = `### minor: [fixture-data] ${s.title}`;
    outLines.splice(insertAt, 0, evidence);
  }

  if (caps.length === 0) return { content, caps: [] };
  return { content: outLines.join("\n"), caps: caps.reverse() };
}

// --- OpenAI-compatible (/v1) pure functions ---

// FAFF-873: PURE — clamp faff's five-tier effort vocabulary (low|medium|high|xhigh|max)
// onto the three-level wire target the OpenAI reasoning_effort field accepts
// (low|medium|high). Above-ceiling levels clamp to high (never fragment the closed
// lane-uniform vocabulary per-backend). This is a LOCAL MIRROR of config.js's
// `reasoningEffortForTransport` — this file is a standalone .mjs with no faff
// CommonJS imports (see the resolveTokenSource mirror note above, runReviewChain),
// so the switch is duplicated here rather than imported. Keep the two in sync by hand.
function clampEffortToWire(effort) {
  switch (effort) {
    case "low": return "low";
    case "medium": return "medium";
    case "high": return "high";
    case "xhigh": return "high";   // clamp to wire ceiling
    case "max": return "high";     // clamp to wire ceiling
    default: return "high";        // defensive; the config-vocabulary check upstream gates real input
  }
}

// FAFF-914: the allowlist of top-level payload keys a per-backend `reasoning_extra`
// passthrough may set. Reasoning models diverge on the wire shape they read for the
// SAME intent — qwen3 honours top-level `reasoning_effort`; a Cohere/north model reads
// `thinking:{type}`; an OpenRouter/deepseek model reads `reasoning:{enabled|effort}` —
// so no single faff-modelled field (reasoning_off / reasoning_effort) reaches them all.
// `reasoning_extra` is the escape hatch: the operator declares whatever shape THEIR
// model honours and faff merges it verbatim, without hard-coding each provider's API.
// The set is reasoning-control ONLY — never faff-managed transport keys (model /
// messages / stream / max_tokens / temperature), which a merge would corrupt.
//
// FAFF-918: cross-model reasoning gotchas measured on the two spark vLLM builds
// (same vLLM 0.26.1rc1.dev1133). Read before reaching for a reasoning lever:
//   - `thinking_token_budget` (top-level int) hard-caps reasoning tokens so content
//     always emits. It is the ONE lever that works on BOTH qwen3 and cohere_command4
//     (north), and it fixes the empty-content bug (reasoning eating the whole
//     max_tokens, content:null, finish_reason:"length"). It is set per-backend via
//     reasoning_extra, never a shared default.
//   - `reasoning_effort` levels other than "none" are NOT graded on these builds
//     (protocol.py: enable_thinking = reasoning_effort != "none"); "none" turns
//     reasoning off on both.
//   - `chat_template_kwargs.enable_thinking` is model-specific: honoured on qwen3,
//     silently IGNORED on cohere_command4 (its parser has no enable_thinking path).
//   - usage.reasoning_tokens reads 0 on cohere_command4 even while reasoning runs;
//     detect the empty-out via finish_reason=="length" && content==null, not it.
//
// FAFF-986: `custom_params` is the nested-wrapper analogue of `thinking_token_budget`.
// Some Qwen vLLM builds read the budget at `custom_params.thinking_budget` rather than
// the top-level key, so faff must be able to emit `custom_params:{thinking_budget:N}`.
// It is a plain top-level set (faff sets no `custom_params` of its own, so unlike
// `chat_template_kwargs` there is no default on the body to deep-merge with).
export const REASONING_EXTRA_KEYS = ["reasoning", "thinking", "reasoning_effort", "chat_template_kwargs", "thinking_token_budget", "custom_params"];

// PURE: merge an allowlisted `reasoning_extra` object onto an OpenAI payload body, in
// place, returning it. Fail-closed: a key outside REASONING_EXTRA_KEYS throws, so a
// typo or an unmodelled field surfaces at the call boundary rather than silently
// egressing into the request. `chat_template_kwargs` DEEP-merges one level so an
// explicit extra composes with a `reasoning_off` default already on the body (which
// sets thinking/enable_thinking there); every other key is a top-level set. The caller
// applies it AFTER the reasoning_off/reasoning_effort branch, so an explicit extra wins
// per key — the operator's deliberate override for a model faff doesn't model natively.
export function mergeReasoningExtra(body, extra) {
  if (extra == null) return body;
  if (typeof extra !== "object" || Array.isArray(extra)) throw new Error("reasoning_extra must be an object");
  for (const [k, v] of Object.entries(extra)) {
    if (!REASONING_EXTRA_KEYS.includes(k)) {
      throw new Error(`reasoning_extra: unsupported key ${JSON.stringify(k)} (allowed: ${REASONING_EXTRA_KEYS.join(", ")})`);
    }
    if (k === "chat_template_kwargs" && body.chat_template_kwargs && v && typeof v === "object") {
      body.chat_template_kwargs = { ...body.chat_template_kwargs, ...v };
    } else {
      body[k] = v;
    }
  }
  return body;
}

// PURE: the /v1/chat/completions payload. reasoningOff adds
// chat_template_kwargs:{thinking:false, enable_thinking:false} — disables a reasoning
// model's hidden think phase (needed by reasoning models that else stream empty content;
// FAFF-872: the sole reasoning-off lever now — the native ollama family's hardcoded
// think:false is gone). `enable_thinking` is the key Qwen3/vLLM/SGLang/HF/MLX chat
// templates actually read to gate the think phase (FAFF-898); `thinking` is retained
// alongside it for compatibility with any server that reads the older key — unrecognised
// kwargs are ignored, so sending both is free. It is OPT-IN: vanilla OpenAI rejects the
// unknown field, so it is sent only when the provider/model needs it — unlike the deleted
// native path, an UNSET reasoningOff here emits no chat_template_kwargs at all (thinking
// is left to the model's own default, not forced off; see the migration note in
// .faffrc.example.yaml for a folded backend that relied on the old always-off default).
// maxTokens caps output (OpenAI's max_tokens). stream:true keeps a long response's
// connection alive.
// FAFF-873: reasoningEffort emits the wire reasoning_effort field, clamped through
// clampEffortToWire — but ONLY when reasoningOff is false (reasoning_off wins on the
// wire, mirroring engine.js's buildEngineRequest `if/else if` precedent). Unset
// reasoningEffort (the default null) changes nothing — byte-identical to today.
// FAFF-914: reasoningExtra (a per-backend `reasoning_extra` object) is merged LAST via
// mergeReasoningExtra — the per-model escape hatch for a wire shape faff doesn't model
// natively (e.g. deepseek's `reasoning:{enabled:false}`, north's `thinking:{type}`).
// Unset (the default null) changes nothing — byte-identical to today.
export function buildOpenAiPayload({ model, system, user, maxTokens = DEFAULT_NUM_PREDICT, reasoningOff = false, reasoningEffort = null, reasoningExtra = null, temperature = 0.2 }) {
  if (!model) throw new Error("buildOpenAiPayload requires a model");
  const body = {
    model,
    stream: true,
    messages: [
      { role: "system", content: system },
      { role: "user", content: user },
    ],
    temperature,
    max_tokens: maxTokens,
  };
  if (reasoningOff) body.chat_template_kwargs = { thinking: false, enable_thinking: false };
  else if (reasoningEffort) body.reasoning_effort = clampEffortToWire(reasoningEffort);
  mergeReasoningExtra(body, reasoningExtra);
  return body;
}

// PURE: is the configured model in the host's /v1/models set? Reads the {data:[{id}]} shape.
// Mirror of engine.js modelServedOpenAi (kept in sync by hand; a CI drift test guards it). Honours
// a LiteLLM-style namespace wildcard ("openrouter/*") — the gateway's own assertion that it serves
// the whole namespace. Closed grammar: only a trailing "/*" entry matching "<prefix>/<non-empty
// rest>"; no general globbing, bare "*" never matches. Exact membership wins first. Trades preflight
// precision for the namespace (a typo'd id passes preflight, fails at the POST) — acceptable: the
// probe changes error quality, not outcome.
export function modelServedOpenAi(modelsJson, model) {
  const obj = typeof modelsJson === "string" ? JSON.parse(modelsJson) : modelsJson;
  const ids = (obj?.data ?? []).map((m) => m.id ?? m.name).filter(Boolean);
  const served = ids.includes(model) || ids.some((n) => n.endsWith("/*") && model.startsWith(n.slice(0, -1)) && model.length > n.length - 1);
  return { served, names: ids };
}

// FAFF-1228: the per-call completion record's helpers. A finish_reason is an untrusted provider string
// that reaches a file preamble and a stderr line, so it is reduced to a short token first; a usage block
// is the one provider object whose KEYS reach a log line, so it is built prototype-safe and capped.
export const USAGE_MAX_KEYS = 16;
const USAGE_SKIP_KEYS = new Set(["__proto__", "constructor", "prototype"]);

// PURE: non-string or empty -> null; else every char outside [A-Za-z0-9_.:-] becomes "_", capped at 64.
// Idempotent, so render sites can re-apply it to a Completion built by a future producer.
export function sanitizeFinishReason(v) {
  if (typeof v !== "string" || v === "") return null;
  return v.replace(/[^A-Za-z0-9_.:-]/g, "_").slice(0, 64);
}

// Copy own entries of `from` into `into` (a null-prototype object) skipping the pollution keys, stopping at the cap.
function copyUsageKeys(into, from) {
  for (const k of Object.keys(from)) {
    if (USAGE_SKIP_KEYS.has(k)) continue;
    if (!(k in into) && Object.keys(into).length >= USAGE_MAX_KEYS) continue;
    into[k] = from[k];
  }
}

// Null-prototype scratch -> plain {} (same skip list); no keys -> null.
function finishUsage(scratch) {
  const keys = Object.keys(scratch);
  if (keys.length === 0) return null;
  const out = {};
  for (const k of keys) {
    if (USAGE_SKIP_KEYS.has(k)) continue;
    Object.defineProperty(out, k, { value: scratch[k], enumerable: true, writable: true, configurable: true });
  }
  return out;
}

// PURE: numeric token counts only, keeping the provider's own field names (no renaming).
export function pickUsage(u) {
  if (!u || typeof u !== "object" || Array.isArray(u)) return null;
  const scratch = Object.create(null);
  // reasoning_tokens first, so a provider with many *_tokens fields cannot crowd it out of the cap.
  const rt = u.completion_tokens_details && typeof u.completion_tokens_details === "object"
    ? u.completion_tokens_details.reasoning_tokens : undefined;
  if (typeof rt === "number" && Number.isFinite(rt)) scratch.reasoning_tokens = rt;
  for (const k of Object.keys(u)) {
    if (Object.keys(scratch).length >= USAGE_MAX_KEYS) break;
    if (USAGE_SKIP_KEYS.has(k) || k in scratch) continue;
    if (k.endsWith("_tokens") && typeof u[k] === "number" && Number.isFinite(u[k])) scratch[k] = u[k];
  }
  return finishUsage(scratch);
}

// PURE: merge two usage maps (b wins), prototype-safe and capped; never a bare spread of provider objects.
export function mergeUsage(a, b) {
  if (b == null) return a;
  if (a == null) return b;
  const scratch = Object.create(null);
  copyUsageKeys(scratch, a);
  copyUsageKeys(scratch, b);
  return finishUsage(scratch);
}

// A length rendered into a log line: a non-negative integer, else 0, so a future producer cannot split a line.
function safeLen(n) { return Number.isInteger(n) && n >= 0 ? n : 0; }

// PURE: the stderr suffix for an OK result's completion record; "" when there is none.
export function formatCompletionLog(completion) {
  if (!completion || typeof completion !== "object") return "";
  const fr = sanitizeFinishReason(completion.finish_reason) ?? "none";
  return ` finish_reason=${fr} done=${completion.done === true} reasoning_len=${safeLen(completion.reasoning_len)} content_len=${safeLen(completion.content_len)}`;
}

// A reasoning delta's text length: some vLLM builds mirror the same text under both field names, so take
// the larger of the two (never the sum). reasoning_details is ignored; `reasoning` carries the same text.
function reasoningPieceLen(obj) {
  const a = typeof obj?.reasoning === "string" ? obj.reasoning.length : 0;
  const b = typeof obj?.reasoning_content === "string" ? obj.reasoning_content.length : 0;
  return Math.max(a, b);
}

// PURE: fold an SSE stream (data: {json}\n\n … data: [DONE]) into the assistant text. Reads
// choices[0].delta.content (streamed) and reports finish_reason==="length" truncation. Tolerant
// fallback: if the body carries no SSE `data:` frames (a provider that ignored stream:true and
// returned one JSON), parse it whole and read choices[0].message.content. FAFF-1228: also returns a
// `completion` record (sanitised finish reason, done, content/reasoning lengths, usage); reasoning is
// counted, never kept.
export function accumulateSse(text) {
  let content = "";
  let truncated = false;
  let done = false;
  let sawData = false;
  let finish = null;
  let reasoningLen = 0;
  let usage = null;
  for (const line of String(text).split("\n")) {
    const t = line.trim();
    if (!t.startsWith("data:")) continue;
    sawData = true;
    const payload = t.slice(5).trim();
    if (payload === "[DONE]") { done = true; continue; }
    let j;
    try { j = JSON.parse(payload); } catch { continue; }
    // Last non-null wins. The request sends no stream_options, so usage appears only from a provider that
    // reports it unasked (OpenRouter does; plain vLLM does not): `usage: none` means unreported, not zero.
    if (j?.usage) { const u = pickUsage(j.usage); if (u != null) usage = u; }
    const choice = j?.choices?.[0];   // absent on a usage-only chunk
    const piece = choice?.delta?.content ?? choice?.message?.content;
    if (typeof piece === "string") content += piece;
    reasoningLen += Math.max(reasoningPieceLen(choice?.delta), reasoningPieceLen(choice?.message));   // one frame, one count
    if (choice?.finish_reason) { finish = sanitizeFinishReason(choice.finish_reason); done = true; if (choice.finish_reason === "length") truncated = true; }
  }
  if (!sawData) {
    // non-streamed fallback: a single completion object
    try {
      const j = JSON.parse(String(text));
      const choice = j?.choices?.[0];
      if (typeof choice?.message?.content === "string") content = choice.message.content;
      usage = pickUsage(j?.usage);
      reasoningLen = reasoningPieceLen(choice?.message);
      finish = sanitizeFinishReason(choice?.finish_reason);
      if (choice?.finish_reason) { done = true; if (choice.finish_reason === "length") truncated = true; }
    } catch { /* leave content empty — caller treats empty as needs-human */ }
  }
  return { content, truncated, done, completion: { finish_reason: finish, done, content_len: content.length, reasoning_len: reasoningLen, usage } };
}

// --- Anthropic (native /v1/messages) pure functions (FAFF-210) ---

// The anthropic-version header value the Messages API requires. Named constant with a temporal anchor:
// stable + documented, but re-verify against the Anthropic API docs if the header is ever rejected.
export const ANTHROPIC_VERSION = "2023-06-01";

// PURE: the /v1/messages payload. Distinct from the OpenAI shape: `system` is a TOP-LEVEL string (not a
// messages[0] entry), `max_tokens` is REQUIRED by the API (no default on the wire), and NO `temperature`
// is sent — current Claude reviewer models reject non-default sampling params under extended thinking with
// a 400 (→ EXIT.OTHER), and the review needs no specific temperature. maxTokens is the analogue of
// openai's max_tokens.
export function buildAnthropicPayload({ model, system, user, maxTokens = DEFAULT_NUM_PREDICT }) {
  if (!model) throw new Error("buildAnthropicPayload requires a model");
  return {
    model,
    max_tokens: maxTokens,
    system,
    messages: [{ role: "user", content: user }],
    stream: true,
  };
}

// PURE: fold Anthropic's named-event SSE into the assistant text. The stream is `event: <name>\n data:
// {json}\n\n` frames; we dispatch on each data payload's own `type` (the `event:` lines are redundant and
// ignored, exactly as accumulateSse ignores non-`data:` lines). Reads only text_delta (a thinking_delta is
// the model's hidden reasoning — dropped, we want only the answer). stop_reason==="max_tokens" on the late
// message_delta reports truncation. Tolerant fallback: if the body carries no `data:` frames (a backend
// that ignored stream:true and returned one Messages object), parse it whole and concatenate its
// content[] text blocks. Same {content, truncated, done, completion} contract as accumulateSse (FAFF-1228:
// thinking_delta text is still dropped from content; only its length is counted).
export function accumulateAnthropic(text) {
  let content = "";
  let truncated = false;
  let done = false;
  let sawData = false;
  let finish = null;
  let reasoningLen = 0;
  let usage = null;
  for (const line of String(text).split("\n")) {
    const t = line.trim();
    if (!t.startsWith("data:")) continue;
    sawData = true;
    const payload = t.slice(5).trim();
    let j;
    try { j = JSON.parse(payload); } catch { continue; }
    if (j?.type === "content_block_delta" && j?.delta?.type === "text_delta" && typeof j.delta.text === "string") {
      content += j.delta.text;
    } else if (j?.type === "content_block_delta" && j?.delta?.type === "thinking_delta" && typeof j.delta.thinking === "string") {
      reasoningLen += j.delta.thinking.length;   // FAFF-1228: counted, never kept
    } else if (j?.type === "message_start") {
      if (j?.message?.usage) usage = mergeUsage(usage, pickUsage(j.message.usage));
    } else if (j?.type === "message_delta") {
      done = true;
      if (j?.delta?.stop_reason) finish = sanitizeFinishReason(j.delta.stop_reason);
      if (j?.usage) usage = mergeUsage(usage, pickUsage(j.usage));   // delta values override start
      if (j?.delta?.stop_reason === "max_tokens") truncated = true;
    } else if (j?.type === "message_stop") {
      done = true;
    }
  }
  if (!sawData) {
    // non-streamed fallback: a single Messages response { content: [{type:"text", text}], stop_reason }
    try {
      const j = JSON.parse(String(text));
      for (const block of j?.content ?? []) {
        if (block?.type === "text" && typeof block.text === "string") content += block.text;
        if (block?.type === "thinking" && typeof block.thinking === "string") reasoningLen += block.thinking.length;
      }
      finish = sanitizeFinishReason(j?.stop_reason);
      usage = pickUsage(j?.usage);
      if (j?.stop_reason) { done = true; if (j.stop_reason === "max_tokens") truncated = true; }
    } catch { /* leave content empty — caller treats empty as needs-human */ }
  }
  return { content, truncated, done, completion: { finish_reason: finish, done, content_len: content.length, reasoning_len: reasoningLen, usage } };
}

// PURE: an HTTP 401/403 from a cloud provider means broken credentials, not infra — needs-human, no retry.
// FAFF-210: Google's OpenAI-compat layer (the gemini family) returns HTTP 400 API_KEY_INVALID for a
// malformed key, NOT 401/403 — so a 400 whose body carries an explicit invalid-key marker is also auth.
// The marker gate keeps this narrow: a generic 400 (bad request shape) has no marker and stays non-auth,
// so no other openai-family provider is affected. Depends on realGet/realStream carrying the body into
// the error message (both do). Direction is fail-safe: this only ever routes MORE to needs-human (exit 7),
// never fewer — it can never turn a real auth fault into a silent pass+skip (the no-silent-weakening invariant).
export function isAuthError(err) {
  const m = String(err && err.message);
  return /HTTP 40[13]/.test(m) || (/HTTP 400/.test(m) && /API_KEY_INVALID|api key not valid/i.test(m));
}

// PURE (FAFF-227; FAFF-942 removed 429): is this a *transient* transport fault that should be retried on
// the SAME endpoint? Mirrors isAuthError. TRUE for a genuinely transient condition — HTTP 5xx, a dropped
// socket (ECONNRESET/ETIMEDOUT/EPIPE or "socket hang up"), or a stream/preflight timeout, all of which the
// same request may clear after a backoff. FALSE for everything else, including HTTP 429: a rate-limited
// endpoint is not cleared by hitting it again — a same-endpoint retry only burns the deadline budget, so a
// 429 must ADVANCE the fallback chain to a different, un-throttled backend instead (see isRateLimited and
// the `rate-limited` status). FALSE for the other 4xx too (auth/usage/model-not-served/anything unknown):
// default-terminal, so the predicate never over-retries a real fault. Do NOT broaden to /HTTP 4\d\d/.
// realGet/realStream reject 5xx as `HTTP <status>: …` and surface socket faults with err.code, so both the
// message and (when present) the code are inspected.
export function isTransientTransport(err) {
  if (!err) return false;
  const msg = String(err.message || "");
  const code = String(err.code || "");
  return /HTTP 5\d\d/.test(msg)                       // 5xx server fault from a reject
    || ["ECONNRESET", "ETIMEDOUT", "EPIPE"].includes(code)
    || /socket hang up/.test(msg)
    || /timed out/.test(msg);                          // realStream / preflight timeout text
}

// PURE (FAFF-942): is this an HTTP 429 rate-limit? A throttled endpoint is up but refusing this request;
// re-hitting it does not clear the limit. Kept OUT of isTransientTransport (no same-endpoint retry) and
// classified as the `rate-limited` status so it advances the fallback chain to a different backend, and so
// a purely-rate-limited exhausted chain surfaces EXIT.RATE_LIMITED — distinct from the genuine-outage
// UNREACHABLE/DEADLINE the dispatch-level retry re-runs.
export function isRateLimited(err) {
  return /HTTP 429/.test(String(err && err.message));
}

// FAFF-885: a first-byte (time-to-first-token) breach. Distinct from a transient stream timeout: it is
// keyed by the `firstByteBreach` MARKER PROPERTY (never message text), and its message deliberately
// EXCLUDES "timed out" so it can never be misread by isTransientTransport's /timed out/ arm.
export class FirstByteBreachError extends Error {
  constructor(message) { super(message); this.name = "FirstByteBreachError"; this.firstByteBreach = true; }
}

// PURE (FAFF-885): is this error a first-byte breach? Keys on the marker property, never the message —
// checked BEFORE isTransientTransport in streamWithTransportRetry so a breach fast-fails (no retry).
export function isFirstByteBreach(err) { return Boolean(err && err.firstByteBreach === true); }

// FAFF-885: wrap the injected streamFn in a first-byte deadline. When firstByteMs is not a number the
// wrapper is a PASS-THROUGH (no timer): byte-for-byte the pre-FAFF-885 four-argument call when no outer
// signal is given, and a fifth argument { signal } alone when one is (FAFF-1239: the chain's element
// signal, so a slice abort still reaches the transport with no first-byte window). Otherwise it
// arms a real timer and hands streamFn an { onFirstByte, signal } fifth argument: the first response byte
// disarms the timer (the stream then proceeds under the existing inactivity timeoutMs, unchanged); if the
// timer fires first it aborts the signal (tearing the real socket down) and rejects a FirstByteBreachError.
// opts is ALWAYS passed at the FIFTH positional slot — every caller (streamOnceOpenAi/streamOnceAnthropic)
// passes an explicit headers object so opts never collides with it. The timer is unref'd so it never
// keeps the process alive. FAFF-1239: an outer signal is linked by hand (addEventListener, not
// AbortSignal.any, which Node 20.0 to 20.2 lacks) into the first-byte controller, and unlinked on settle.
export function streamWithFirstByte(streamFn, url, body, timeoutMs, headers, firstByteMs, signal) {
  // Pass-through unless a POSITIVE finite window is set (mirrors resolveFirstByteMs's <=0-disables
  // guard, and rejects a NaN a direct caller might pass — typeof NaN === "number" would else arm
  // setTimeout(NaN), an immediate breach).
  if (!Number.isFinite(firstByteMs) || firstByteMs <= 0) {
    return signal === undefined ? streamFn(url, body, timeoutMs, headers) : streamFn(url, body, timeoutMs, headers, { signal });
  }
  let firstByteSeen = false;
  let timer;
  const controller = new AbortController();
  let onOuter;
  if (signal) {
    if (signal.aborted) controller.abort(signal.reason);
    else {
      onOuter = () => controller.abort(signal.reason);
      signal.addEventListener("abort", onOuter, { once: true });
    }
  }
  const settle = () => {
    if (timer) { clearTimeout(timer); timer = undefined; }
    if (onOuter) { signal.removeEventListener("abort", onOuter); onOuter = undefined; }
  };
  const onFirstByte = () => { firstByteSeen = true; if (timer) { clearTimeout(timer); timer = undefined; } };
  const breach = new Promise((_resolve, reject) => {
    timer = setTimeout(() => {
      if (!firstByteSeen) { controller.abort(new Error("first-byte breach")); reject(new FirstByteBreachError(`no first byte within ${firstByteMs}ms`)); }
    }, firstByteMs);
    if (timer && typeof timer.unref === "function") timer.unref();
  });
  const streamP = streamFn(url, body, timeoutMs, headers, { onFirstByte, signal: controller.signal });
  // The losing branch of the race can settle after the winner: swallow a post-breach streamFn rejection
  // (an aborted socket) so it never surfaces as an unhandledRejection, and always clear the timer.
  streamP.then(settle, settle);
  return Promise.race([streamP, breach]);
}

// Bounded transport-retry policy (FAFF-227): named constants, not magic numbers. attempts counts the
// first try too (3 ⇒ 2 retries). Backoff before retry k (1-indexed) is base_ms * 2^(k-1), each *sleep*
// capped by the time remaining against the caller's --timeout deadline so a backoff never overruns budget.
// TIMEOUT BOUND (FAFF-228 — correction): --timeout bounds each individual stream attempt and the
// inter-retry sleeps, NOT the total wall-clock. Each streamOnce gets the full timeoutMs; the truncation
// retry adds a second streamOnce; this loop runs up to `attempts` (3) times — so worst-case total
// wall-clock is ~6× timeoutMs (3 attempts × 2 streamOnce) under stream + truncation + transport-retry
// composition. There is no overall deadline across attempts (a true cap is a deferred behavioural change).
export const TRANSPORT_RETRY = { attempts: 3, baseMs: 1500 };

// FAFF-1239: resolves early (clearing its timer and listener) when the optional signal aborts, so an
// abandoned chain element's backoff ends with the element instead of waking to start another attempt.
function sleep(ms, signal) {
  return new Promise((resolve) => {
    if (signal && signal.aborted) return resolve();
    let onAbort;
    const t = setTimeout(() => { if (signal) signal.removeEventListener("abort", onAbort); resolve(); }, ms);
    if (signal) {
      onAbort = () => { clearTimeout(t); resolve(); };
      signal.addEventListener("abort", onAbort, { once: true });
    }
  });
}

// Wrap a stream call (streamOnce + its truncation retry) in a bounded retry that fires solely on
// isTransientTransport. Terminal faults (auth/4xx/usage) throw straight out — unchanged. On exhaustion,
// or when no budget remains for the next backoff, returns a sentinel so the caller surfaces
// status "transport-failed" (→ main() maps it through unreachableExit, never the unmapped EXIT.OTHER).
// FAFF-1239: an aborted signal ends the loop (never retried, never rethrown), checked before any other class.
async function streamWithTransportRetry(streamCall, { policy = TRANSPORT_RETRY, deadlineMs, signal } = {}) {
  let lastErr;
  for (let attempt = 1; attempt <= policy.attempts; attempt++) {
    if (signal && signal.aborted) { lastErr = lastErr ?? signal.reason; break; }
    try {
      return { ok: true, out: await streamCall() };
    } catch (e) {
      if (signal && signal.aborted) { lastErr = e; break; }   // FAFF-1239: an abort is neither retried nor rethrown
      if (isFirstByteBreach(e)) { lastErr = e; break; }  // FAFF-885: fast-fail — no retry, surface transport-failed
      if (!isTransientTransport(e)) throw e;            // terminal → out immediately (auth handled by caller's catch)
      lastErr = e;
      if (attempt === policy.attempts) break;           // exhausted
      let delay = policy.baseMs * 2 ** (attempt - 1);
      if (typeof deadlineMs === "number") delay = Math.min(delay, deadlineMs - Date.now());
      if (delay <= 0) break;                            // no budget left to retry
      await sleep(delay, signal);
    }
  }
  return { ok: false, error: lastErr };
}

// --- transport (real impls; injectable in runReview for tests) ---

// FAFF-1239: destroy `r` when `signal` aborts, and drop the listener once the request has settled so a
// later abort (the chain's element-settled one) cannot touch a request that already completed.
function destroyOnAbort(r, signal) {
  if (!signal) return () => {};
  const reasonText = signal.reason?.message ?? String(signal.reason ?? "aborted");
  const abortReq = () => r.destroy(new Error(`request aborted (${reasonText})`));
  if (signal.aborted) { abortReq(); return () => {}; }
  signal.addEventListener("abort", abortReq, { once: true });
  let linked = true; // idempotent: several settle events (end, close, error) may each unlink
  return () => { if (linked) { linked = false; signal.removeEventListener("abort", abortReq); } };
}

function realGet(url, timeoutMs = 5000, headers = {}, opts = {}) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const lib = u.protocol === "https:" ? https : http;
    let unlink = () => {};
    const r = lib.request(u, { method: "GET", headers }, (res) => {
      let data = "";
      res.setEncoding("utf8");
      res.on("close", () => unlink()); // every response settle path, including an aborted body
      res.on("data", (c) => (data += c));
      res.on("end", () => (unlink(), res.statusCode >= 200 && res.statusCode < 300
        ? resolve(data)
        // FAFF-210: include the body (as realStream already does) so isAuthError can see a gemini
        // 400 API_KEY_INVALID at the preflight GET — without it that bad-key 400 would misroute to
        // unreachable/pass+skip and silently disable the gate.
        : reject(new Error(`HTTP ${res.statusCode}: ${data.slice(0, 200)}`))));
    });
    r.on("error", (e) => { unlink(); reject(e); });
    r.setTimeout(timeoutMs, () => r.destroy(new Error(`preflight timed out after ${timeoutMs}ms`)));
    unlink = destroyOnAbort(r, opts.signal);
    r.end();
  });
}

// POST the payload and consume the streamed response, concatenating chunks as they arrive (the act of
// reading keeps the connection alive on a long generation). Returns the raw NDJSON text.
function realStream(url, body, timeoutMs = 580000, extraHeaders = {}, opts = {}) {
  return new Promise((resolve, reject) => {
    let firstByte = true;                               // FAFF-885: fire opts.onFirstByte once, on the first body byte
    const u = new URL(url);
    const lib = u.protocol === "https:" ? https : http;
    const headers = { "content-type": "application/json", "content-length": Buffer.byteLength(body), ...extraHeaders };
    let unlink = () => {};
    const r = lib.request(u, { method: "POST", headers }, (res) => {
      let data = "";
      res.setEncoding("utf8");
      res.on("close", () => unlink()); // every response settle path, including an aborted body
      res.on("data", (c) => {
        // FAFF-885: the FIRST body byte disarms the first-byte window. A buffering server that flushes
        // nothing until done never reaches here, so its window breaches and the chain fails over fast.
        if (firstByte) { firstByte = false; if (typeof opts.onFirstByte === "function") opts.onFirstByte(); }
        data += c;
      });
      res.on("end", () => (unlink(), res.statusCode >= 200 && res.statusCode < 300
        ? resolve(data)
        : reject(new Error(`HTTP ${res.statusCode}: ${data.slice(0, 200)}`))));
    });
    r.on("error", (e) => { unlink(); reject(e); });
    r.setTimeout(timeoutMs, () => r.destroy(new Error(`stream timed out after ${timeoutMs}ms`)));
    // Two abort sources share this signal: the FAFF-885 first-byte breach, and (FAFF-1239) the chain
    // cancelling an abandoned element. Either way tear the socket down promptly rather than leaving it to
    // linger on the inactivity timeout above; the listener is removed once the request settles.
    unlink = destroyOnAbort(r, opts.signal);
    r.write(body);
    r.end();
  });
}

// OpenAI-compatible preflight: GET /v1/models with Bearer auth. unreachable (infra) and auth-failed
// (401/403 creds) are distinct from not-served (config fault).
export async function preflightOpenAi({ host, model, apiKey, getFn = realGet, timeoutMs = 5000, signal }) {
  const headers = apiKey ? { authorization: `Bearer ${apiKey}` } : {};
  let body;
  try {
    // FAFF-1239: the 4th argument is passed only when a signal exists, so direct callers see the old arity.
    body = signal ? await getFn(joinUrl(host, "/models"), timeoutMs, headers, { signal }) : await getFn(joinUrl(host, "/models"), timeoutMs, headers);
  }
  catch (e) {
    if (isAuthError(e)) return { authFailed: true, error: e.message };
    if (isRateLimited(e)) return { rateLimited: true, error: e.message };  // FAFF-942: advance the chain, don't retry the throttled host
    return { unreachable: true, error: e.message };
  }
  const { served, names } = modelServedOpenAi(body, model);
  return { unreachable: false, served, names };
}

async function streamOnceOpenAi({ host, model, system, user, numPredict, reasoningOff, reasoningEffort, reasoningExtra, apiKey, streamFn, timeoutMs, firstByteMs, signal }) {
  const headers = apiKey ? { authorization: `Bearer ${apiKey}` } : {};
  const body = JSON.stringify(buildOpenAiPayload({ model, system, user, maxTokens: numPredict, reasoningOff, reasoningEffort, reasoningExtra }));
  const raw = await streamWithFirstByte(streamFn, joinUrl(host, "/chat/completions"), body, timeoutMs, headers, firstByteMs, signal);  // FAFF-885, FAFF-1239
  return accumulateSse(raw);
}

// OpenAI-compatible orchestration: preflight → stream → one 2× truncation retry, with Bearer auth and
// an auth-failed branch (the same shape the deleted native ollama orchestration used, minus auth). The
// stream (+ truncation retry) is wrapped in the FAFF-227 bounded transport retry: a transient mid-stream
// fault retries; an auth fault is terminal (isTransientTransport is FALSE for 401/403, so the wrapper
// rethrows it into the auth catch); an exhausted transport fault surfaces status "transport-failed" → a
// documented exit, never EXIT.OTHER.
async function runReviewOpenAi({
  host, model, system, user, numPredict = DEFAULT_NUM_PREDICT, reasoningOff = false, reasoningEffort = null, reasoningExtra = null, apiKey,
  getFn = realGet, streamFn = realStream, timeoutMs, hardDeadlineMs, firstByteMs, signal,
}) {
  const pf = await preflightOpenAi({ host, model, apiKey, getFn, signal });
  if (pf.authFailed) return { status: "auth-failed", note: pf.error };
  if (pf.rateLimited) return { status: "rate-limited", note: pf.error };  // FAFF-942
  if (pf.unreachable) return { status: "unreachable", note: pf.error };
  if (!pf.served) return { status: "model-not-served", names: pf.names };

  // FAFF-329: re-clamp every attempt to the remaining total budget when hardDeadlineMs is set, so a single backend's retry composition can never overrun the total deadline. Unset ⇒ the per-attempt timeoutMs unchanged (byte-for-byte today; mirrored in runReviewAnthropic below).
  const perAttempt = () => (typeof hardDeadlineMs === "number"
    ? Math.max(1, Math.min(typeof timeoutMs === "number" ? timeoutMs : hardDeadlineMs - Date.now(), hardDeadlineMs - Date.now()))
    : timeoutMs);
  try {
    const streamCall = async () => {
      let out = await streamOnceOpenAi({ host, model, system, user, numPredict, reasoningOff, reasoningEffort, reasoningExtra, apiKey, streamFn, timeoutMs: perAttempt(), firstByteMs, signal });
      let retried = false;   // FAFF-1228: surfaced on the completion record
      if (out.truncated) {
        out = await streamOnceOpenAi({ host, model, system, user, numPredict: numPredict * 2, reasoningOff, reasoningEffort, reasoningExtra, apiKey, streamFn, timeoutMs: perAttempt(), firstByteMs, signal });
        retried = true;
      }
      return { ...out, completion: { ...out.completion, length_retried: retried } };
    };
    const deadlineMs = typeof hardDeadlineMs === "number" ? hardDeadlineMs
      : (typeof timeoutMs === "number" ? Date.now() + timeoutMs : undefined);
    const r = await streamWithTransportRetry(streamCall, { deadlineMs, signal });
    if (!r.ok) return { status: "transport-failed", note: r.error && r.error.message };
    return { status: "ok", content: r.out.content, truncated: r.out.truncated, completion: r.out.completion };
  } catch (e) {
    if (isAuthError(e)) return { status: "auth-failed", note: e.message };
    if (isRateLimited(e)) return { status: "rate-limited", note: e.message };  // FAFF-942: no same-endpoint retry — advance the chain
    throw e;
  }
}

async function streamOnceAnthropic({ host, model, system, user, numPredict, apiKey, streamFn, timeoutMs, firstByteMs, signal }) {
  const headers = { "anthropic-version": ANTHROPIC_VERSION };
  if (apiKey) headers["x-api-key"] = apiKey;   // absent key ⇒ the API 401s → auth-failed (mirrors openai's Bearer)
  const body = JSON.stringify(buildAnthropicPayload({ model, system, user, maxTokens: numPredict }));
  const raw = await streamWithFirstByte(streamFn, joinUrl(host, "/v1/messages"), body, timeoutMs, headers, firstByteMs, signal);  // FAFF-885, FAFF-1239
  return accumulateAnthropic(raw);
}

// Anthropic native orchestration (FAFF-210): mirrors the openai path (stream → one 2× truncation retry,
// wrapped in the same FAFF-227 bounded transport retry) with two differences. (1) NO preflight — Anthropic
// exposes no model-list endpoint used here, so a bad model id can't be caught up front; it surfaces as a
// 404/not_found on the first stream call and is classified in the catch → model-not-served (exit 4), the
// same needs-human class the other families' preflight not-served yields. (2) The catch also maps that 404.
// Auth (401/403) is terminal via isAuthError (isTransientTransport is FALSE for it, so the wrapper rethrows
// into this catch); an exhausted transient fault surfaces transport-failed → a documented exit, never EXIT.OTHER.
async function runReviewAnthropic({
  host, model, system, user, numPredict = DEFAULT_NUM_PREDICT, apiKey,
  getFn = realGet, streamFn = realStream, timeoutMs, hardDeadlineMs, firstByteMs, signal,
}) {
  // FAFF-329: re-clamp every attempt to the remaining total budget (see runReviewOpenAi above for the full rationale).
  const perAttempt = () => (typeof hardDeadlineMs === "number"
    ? Math.max(1, Math.min(typeof timeoutMs === "number" ? timeoutMs : hardDeadlineMs - Date.now(), hardDeadlineMs - Date.now()))
    : timeoutMs);
  try {
    const streamCall = async () => {
      let out = await streamOnceAnthropic({ host, model, system, user, numPredict, apiKey, streamFn, timeoutMs: perAttempt(), firstByteMs, signal });
      let retried = false;   // FAFF-1228: surfaced on the completion record
      if (out.truncated) {
        out = await streamOnceAnthropic({ host, model, system, user, numPredict: numPredict * 2, apiKey, streamFn, timeoutMs: perAttempt(), firstByteMs, signal });
        retried = true;
      }
      return { ...out, completion: { ...out.completion, length_retried: retried } };
    };
    const deadlineMs = typeof hardDeadlineMs === "number" ? hardDeadlineMs
      : (typeof timeoutMs === "number" ? Date.now() + timeoutMs : undefined);
    const r = await streamWithTransportRetry(streamCall, { deadlineMs, signal });
    if (!r.ok) return { status: "transport-failed", note: r.error && r.error.message };
    return { status: "ok", content: r.out.content, truncated: r.out.truncated, completion: r.out.completion };
  } catch (e) {
    if (isAuthError(e)) return { status: "auth-failed", note: e.message };
    if (isRateLimited(e)) return { status: "rate-limited", note: e.message };  // FAFF-942: no same-endpoint retry — advance the chain
    const m = String(e && e.message);
    if (/HTTP 404/.test(m) || /not_found/i.test(m)) return { status: "model-not-served", note: e.message };
    throw e;
  }
}

// Dispatcher: routes on the configured provider's transport family. Default (no provider) is now
// "openai" (FAFF-872 — there is no longer a native ollama family to default to); ollama itself is an
// OpenAI-compatible alias, so it also dispatches here, never to a native path.
export async function runReview(opts = {}) {
  const fam = providerFamily(opts.provider);
  if (fam === "openai") return runReviewOpenAi(opts);
  if (fam === "anthropic") return runReviewAnthropic(opts);
  return { status: "unsupported-provider", note: `provider '${opts.provider}' has no transport in review-call.mjs (use an OpenAI-compatible base URL, or anthropic)` };
}

// --- CLI ---

export function parseArgs(argv) {
  // hostSource defaults to "config" so existing callers (which never pass --host-source) keep the
  // exit-5 pass+skip behaviour unchanged. "default" signals the host is only the localhost fallback.
  const a = { context: [], fixturePaths: [], hostSource: "config" };
  for (let i = 0; i < argv.length; i++) {
    const k = argv[i];
    if (k === "--host") a.host = argv[++i];
    else if (k === "--model") a.model = argv[++i];
    else if (k === "--system") a.system = argv[++i];
    else if (k === "--diff") a.diff = argv[++i];
    else if (k === "--context") a.context.push(argv[++i]);
    else if (k === "--fixture-path") { const prefix = normaliseFixturePrefix(argv[++i] ?? ""); if (prefix) a.fixturePaths.push(prefix); }   // repeatable; enables the fixture-data severity cap (findings mode only)
    else if (k === "--max-tokens") a.numPredict = Number(argv[++i]);
    else if (k === "--timeout") a.timeoutMs = Number(argv[++i]) * 1000;
    else if (k === "--deadline") a.totalDeadlineMs = Number(argv[++i]) * 1000;   // FAFF-329: TOTAL wall-clock ceiling across ALL attempts + fallback backends (distinct from --timeout, which bounds ONE stream attempt)
    else if (k === "--host-source") a.hostSource = argv[++i];
    else if (k === "--provider") a.provider = argv[++i];
    else if (k === "--api-key-env") a.apiKeyEnv = argv[++i];
    else if (k === "--reasoning-off") a.reasoningOff = true;
    else if (k === "--reasoning-effort") a.reasoningEffort = argv[++i];   // FAFF-873: low|medium|high|xhigh|max — clamped to the wire ceiling in buildOpenAiPayload
    else if (k === "--reasoning-extra") {   // FAFF-914: JSON object merged verbatim onto the OpenAI body (per-model reasoning-control passthrough) — e.g. '{"reasoning":{"enabled":false}}'
      const raw = argv[++i];
      try { a.reasoningExtra = JSON.parse(raw); }
      catch (e) { throw new Error(`--reasoning-extra: not valid JSON: ${e.message}`); }
    }
    else if (k === "--backends-json") a.backendsJson = argv[++i];   // FAFF-232: ordered fallback chain
    // FAFF-1039: single-backend window (the chain form carries its own per element). A declared window
    // OVERRIDES --context-trim-bytes 0: the window-targeted search always trims, because a payload that
    // cannot fit the window is worse than a trimmed one, so disabling the byte-gated trim turns off the
    // unconditional pass only, never the window-driven one.
    else if (k === "--context-window") a.contextWindow = argv[++i];
    else if (k === "--lights-out") a.mandatory = true;   // FAFF-398: mark this review MANDATORY (L4) — a no-opinion chain exhaustion fails closed → needs-human
    else if (k === "--run-dir") a.runDir = argv[++i];   // FAFF-401: the run whose run-ledger.json derives mandatory-ness (level:"L4"); FAFF_RUN_DIR is the ambient fallback
    else if (k === "--max-payload-bytes") a.maxPayloadBytes = Number(argv[++i]);   // FAFF-445: oversized-diff preflight threshold override (test-only escape hatch; default DEFAULT_MAX_PAYLOAD_BYTES applies when absent)
    else if (k === "--context-trim-bytes") a.contextTrimBytes = Number(argv[++i]);   // FAFF-915: relevance-trim threshold override; 0 disables the trim (default DEFAULT_CONTEXT_TRIM_BYTES applies when absent)
    else if (k === "--diff-kind") a.diffKind = argv[++i];   // FAFF-1051: unified|prose — declares what --diff IS; validated in main() (default "unified" applies when absent)
    else if (k === "--no-trim") a.noTrim = true;   // FAFF-1058: disable BOTH trim passes (pass 1 → disabled short-circuit, skip the FAFF-1039 window pass). Absent ⇒ behaviour byte-for-byte unchanged.
    else if (k === "--first-byte-timeout") a.firstByteMs = Number(argv[++i]) * 1000;   // FAFF-885: per-attempt first-byte (TTFT) window override; 0 disables (pass-through)
    else if (k === "--expect") {   // FAFF-940: `--expect contract` opts into contract-output mode (skip the findings-shape gate; the consumer validates the block)
      const v = argv[++i];
      // Fail loud on any other value (mirrors --reasoning-extra / --backends-json): a silent coerce
      // to the default path would turn a one-character typo in the flag the judge dispatch is told to
      // pass into a silent park, indistinguishable from a dead judge backend.
      if (v !== "contract") throw new Error(`--expect: only "contract" is supported, got ${JSON.stringify(v)}`);
      a.expectContract = true;
    }
    else if (k === "--no-findings-shape") a.expectContract = true;   // FAFF-940: bare alias for --expect contract
    else if (k === "--raw-dir") a.rawDir = argv[++i];   // FAFF-928: retain each backend's raw response body under this dir (per lens × backend × round); absent ⇒ no capture (byte-for-byte today)
    else if (k === "--lens") a.lens = argv[++i];        // FAFF-928: lens name for the raw-body artifact filename + preamble
    else if (k === "--round") a.round = argv[++i];      // FAFF-928: spec-review round for the raw-body artifact filename + preamble
  }
  return a;
}

// PURE-ISH (FAFF-401): derive "is this review MANDATORY?" mechanically from the run ledger, so no LLM step
// sits between the resolved L4 level and the flag. Mirrors bin/faff's appetite resolver ("ledger brace":
// FAFF_RUN_DIR → run-ledger.json → level === "L4") — the same machine-written state, read a second time by
// deterministic code. Fail-safe direction: ANY resolution miss (absent runDir, missing/unreadable/garbled
// ledger, or a non-L4 level) returns false ⇒ advisory, byte-for-byte today's behaviour. It only ever ADDS
// mandatory-ness on positive L4 evidence; it never blocks an L1–L3 flow, and it never throws.
//
// Deliberately NO liveness/heartbeat check (unlike the appetite resolver's runIsHeld brace): here the derived
// direction REDUCES agency (mandatory ⇒ fail-closed ⇒ needs-human park), so a stale L4 ledger can only cause a
// visible false park, never a false merge — the staleness confound inverts, and replicating heartbeat math into
// a second file would add drift risk for no directional safety (spec §6).
export function ledgerMandatory(runDir) {
  if (!runDir) return false;
  let ledger;
  try { ledger = JSON.parse(readFileSync(pathJoin(runDir, "run-ledger.json"), "utf8")); }
  catch { return false; }   // missing file, unreadable, or garbled JSON — advisory
  return !!(ledger && ledger.level === "L4");
}

// PURE (FAFF-414): map a throw that escaped a family's orchestration function (runReviewOpenAi/
// Anthropic — a bad request shape, an oversized payload/413, or any other non-transient fault those
// functions don't already convert into a status) to a stable per-backend status string. Mirrors
// isAuthError so an escaped 401/403 still routes distinctly (defense-in-depth: each family already
// classifies its OWN auth faults internally and returns a status rather than throwing, so this branch is
// a backstop, not the primary path). Everything else is a generic non-transient REQUEST fault — a
// config/request problem, not an availability one — so it must never be confused with "unreachable" (a
// pass+skip class); it needs its own needs-human-class exit (mapResultExit below).
export function mapThrowStatus(err) {
  return isAuthError(err) ? "auth-failed" : "request-failed";
}

// PURE (FAFF-232): map a runReview() result + host provenance to the documented exit class for ONE backend.
// Extracted from main()'s old inline if-ladder so the single-backend path and runReviewChain map identically.
export function mapResultExit(result, hostSource) {
  switch (result && result.status) {
    case "ok": return EXIT.OK;
    case "unsupported-provider": return EXIT.USAGE;
    case "model-not-served": return EXIT.NOT_SERVED;
    case "auth-failed": return EXIT.AUTH;
    // FAFF-414: a non-transient throw that escaped a run function (see safeCall/mapThrowStatus) — reuse
    // USAGE(2), already a needs-human class (CHAIN_NEEDS_HUMAN below), rather than minting a new exit code.
    case "request-failed": return EXIT.USAGE;
    // FAFF-942: a rate-limited (HTTP 429) backend — an availability class distinct from unreachable, so an
    // all-429 exhausted chain is separable from a genuine-outage one (see chainTerminalExit) and is not
    // re-run by the dispatch-level retry (see judgeDispatchDisposition).
    case "rate-limited": return EXIT.RATE_LIMITED;
    case "unreachable":
    case "transport-failed": return unreachableExit({ hostSource });
    default: return EXIT.OTHER;
  }
}

// PURE (FAFF-232/FAFF-465): the terminal exit of an EXHAUSTED chain (no backend produced findings). A
// structural-inability class — USAGE(2)/NOT_SERVED(4)/DEFAULT_HOST_UNREACHABLE(6)/AUTH(7)/
// NO_FINDINGS_CONTENT(11, FAFF-465 — an empty body or a closed-grammar provider refusal), all of which
// the skill maps to needs-human — DOMINATES the availability/degradation class UNREACHABLE(5 → pass+skip;
// MALFORMED/10's substantive-garble is an availability symptom too and is NOT a member — a garble-only
// exhausted chain collapses to UNREACHABLE/5, never a needs-human terminal exit on its own). So a chain of
// purely configured-host availability/degradation failures still pass+skips exactly as a lone configured
// backend does today, but a structural fault ANYWHERE in a fully-failed chain surfaces needs-human (never
// masked by "all down" — the FAFF-213/228/194 no-silent-weakening invariant, now keyed on a STABLE
// response property rather than the incidental run-to-run failure-class mix). Returns the FIRST
// needs-human class in chain order; else UNREACHABLE(5). Empty list → 5 (no faults to surface).
export const CHAIN_NEEDS_HUMAN = new Set([EXIT.USAGE, EXIT.NOT_SERVED, EXIT.DEFAULT_HOST_UNREACHABLE, EXIT.AUTH, EXIT.NO_FINDINGS_CONTENT]);
export function chainTerminalExit(failureClasses = []) {
  for (const c of failureClasses) if (CHAIN_NEEDS_HUMAN.has(c)) return c;
  // FAFF-942: a PURELY rate-limited exhausted chain (every non-needs-human fault was a 429) collapses to
  // RATE_LIMITED — a distinct availability class the dispatch-level retry does not re-run (re-hitting a
  // throttled chain does not clear the limit). A chain that mixes in ANY genuine availability fault
  // (unreachable/deadline/transport-failed/garble) stays UNREACHABLE, so a real transient blip still earns
  // its bounded dispatch retry. Empty list → UNREACHABLE unchanged (no faults to surface).
  const nonHuman = failureClasses.filter((c) => !CHAIN_NEEDS_HUMAN.has(c));
  if (nonHuman.length > 0 && nonHuman.every((c) => c === EXIT.RATE_LIMITED)) return EXIT.RATE_LIMITED;
  return EXIT.UNREACHABLE;
}

// PURE (FAFF-398): a MANDATORY review (an L4 lights-out run, where dialCoherence already REQUIRES the
// adversarial occupant) whose chain exhausted with only a "no-opinion" class — UNREACHABLE(5, all
// configured hosts down) or DEADLINE(8, budget hit before any findings) — must FAIL CLOSED: no second
// opinion was obtained and no human is watching, so map to MANDATORY_OUTAGE(9), which the skill reads as
// unavailable (FAFF-405 — park the PR). Structural-inability classes (2/4/6/7/11 — 11 added FAFF-465)
// already map to needs-human and pass through UNCHANGED — the remap must not upgrade or MASK a specific
// cause; NO_FINDINGS_CONTENT(11) is human-actionable, not a fail-closed outage, even at L4. Advisory reviews (mandatory=false,
// L1–L3) are byte-for-byte unchanged. Applied ONCE at main()'s single caller boundary on runReviewChain's
// terminal exit, so every exhaustion path (all three deadline returns + the chain-exhausted return) is
// covered by construction — runReviewChain itself never learns "mandatory" (stays level-agnostic).
export function mandatoryRemap(exit, mandatory) {
  if (!mandatory) return exit;
  // FAFF-942: an all-429 chain (RATE_LIMITED) is a no-opinion outage for a mandatory review exactly as
  // UNREACHABLE/DEADLINE are — no second opinion was obtained — so it fails closed to MANDATORY_OUTAGE too.
  if (exit === EXIT.UNREACHABLE || exit === EXIT.DEADLINE || exit === EXIT.RATE_LIMITED) return EXIT.MANDATORY_OUTAGE;
  return exit;
}

// PURE (FAFF-941): the spec-review JUDGE dispatch's in-turn disposition for a review-call terminal
// exit — one of "ruling" (an OK result to validate), "retry" (a transient no-opinion outage: the
// faff-prep dispatch re-dispatches up to the bounded limit before parking), or "park" (a config
// fault, a garbled ruling, or an empty result — a human call a retry never rescues). The retry class
// is UNREACHABLE(5 — all configured judge hosts down) and DEADLINE(8 — the judge budget hit before any
// ruling): the swing-capable, infra-configured outage the spec-review outage disposition already rides out
// one altitude up, so a single blip in a would-be-park pass no longer escalates it to needs-human.
// RATE_LIMITED(12 — an all-429 chain, FAFF-942) is deliberately NOT in the retry set: re-dispatching a
// throttled chain does not clear the limit, so it PARKS directly (the next drain, not an in-turn re-run,
// is the recovery path). Every needs-human/config-fault class (CHAIN_NEEDS_HUMAN = 2/4/6/7/11), OTHER(1),
// and a garbled ruling (MALFORMED/10) PARK directly — a broken backend or a garbled verdict is not a
// transient blip. MANDATORY_OUTAGE(9) never arises (the judge is never a --lights-out mandatory review)
// and is classified park for completeness. Total over the whole EXIT taxonomy — the faff-prep dispatch
// reads this, never an ad-hoc per-exit branch.
export const JUDGE_RETRY_OUTAGE_EXITS = new Set([EXIT.UNREACHABLE, EXIT.DEADLINE]);
export function judgeDispatchDisposition(exit) {
  if (exit === EXIT.OK) return "ruling";
  if (JUDGE_RETRY_OUTAGE_EXITS.has(exit)) return "retry";
  return "park";
}

// PURE (FAFF-617): advisory, non-gating config check surfaced once before the chain runs. The per-backend
// slice (runReviewChain) makes a bad timeout/deadline combination NON-FATAL — fail-over still happens — but
// a per-backend `timeout` set so high that no single backend can finish its full retry composition inside
// its slice still silently TRUNCATES that backend's retries, a real misconfiguration the operator should
// SEE. Returns a (possibly empty) list of human-readable warning strings; never throws, never gates, never
// changes an exit code (main() writes them to stderr, that is all). `multiplier` is the ~6× worst-case
// wall-clock factor (TRANSPORT_RETRY.attempts=3 × 2 streamOnce) between one `--timeout` and one backend's
// worst-case wall-clock — if that composition changes, this default should track it.
export function budgetWarnings(chain = [], totalDeadlineMs, multiplier = 6) {
  if (typeof totalDeadlineMs !== "number") return [];   // unbounded ⇒ no per-backend budget to compare against
  const n = Array.isArray(chain) ? chain.length : 0;
  if (n === 0) return [];
  const perBackendBudget = totalDeadlineMs / n;
  const out = [];
  for (const b of chain) {
    const t = b && b.timeoutMs;
    if (typeof t !== "number") continue;                // a backend with no explicit timeout can't be judged
    if (t * multiplier >= perBackendBudget) {
      const tag = `${(b && b.provider) || "openai"}/${(b && b.model) || "?"}`;
      out.push(
        `budget: backend ${tag}: timeout ${Math.round(t / 1000)}s × ~${multiplier} worst-case ` +
        `(~${Math.round((t * multiplier) / 1000)}s) >= per-backend budget ${Math.round(perBackendBudget / 1000)}s ` +
        `(deadline ${Math.round(totalDeadlineMs / 1000)}s / ${n} backends) — retries/truncation may be cut short; ` +
        `lower this backend's timeout or raise --deadline`,
      );
    }
  }
  return out;
}

// FAFF-361: maps a per-backend runReview() result `status` to the short cause token the reshaped
// `[chain] <tag> <reason> → advancing` note names. Falls back to the raw status string for anything
// unlisted (e.g. "unsupported-provider") so an unrecognised status still logs something greppable
// rather than silently dropping the reason.
const CHAIN_ADVANCE_REASON = {
  unreachable: "unreachable",
  "transport-failed": "transport-failed",
  "model-not-served": "not-served",
  "auth-failed": "auth",
};

// Non-rejecting wrapper around a per-backend callReview() invocation (FAFF-414). The per-family
// orchestration functions (runReviewOpenAi/Anthropic) are BYTE-UNCHANGED — they still throw
// straight out on a non-transient, non-auth error (a bad request shape, an oversized payload/413, etc.);
// the catch lives ONLY here, at the chain boundary, OUTSIDE streamWithTransportRetry (which already owns
// the transient-retry catch). A throw that escapes a run function is exactly as informative as any other
// per-backend fault the chain already advances past (unreachable / auth-failed / model-not-served /
// transport-failed) — so it must never abort the WHOLE review at the unmapped EXIT.OTHER; it resolves to
// a status-shaped result the loop below treats identically to a returned status.
async function safeCall(callFn) {
  try {
    return await callFn();
  } catch (err) {
    // Adversarial review (FAFF-414): every throw site in THIS file only ever throws `new Error(...)`, so
    // `err.message` always exists in practice — but a non-Error throw (`throw "x"` / `throw null`) must
    // still surface SOMETHING in the log, not a lost/empty note (the needs-human signal is only actionable
    // if the human can see what actually failed). `err instanceof Error` covers every real case; the
    // String() fallback is a defensive backstop for a value that isn't.
    const note = err instanceof Error ? err.message : String(err);
    return { status: mapThrowStatus(err), note };
  }
}

// FAFF-232: run an ORDERED chain of backends, returning the first that produces findings. A backend that
// does not (any non-OK class) is recorded and the chain ADVANCES — the value is a real second opinion from
// SOMEONE, so a per-backend fault never sinks the chain if a healthy fallback exists. Only when every
// backend has failed is one terminal exit computed (chainTerminalExit). A 1-element chain reproduces the
// single-backend path exactly (one runReviewFn call, same exit), so back-compat is structural, not bolted on.
//
// chain element: { provider, model, host, hostSource, apiKey?, apiKeyEnv?, apiKeyMissing?, reasoningOff?, timeoutMs? }
// shared:        { system, user, numPredict, runReviewFn?, getFn?, streamFn?, log? }
// returns:       { exit, content?, truncated?, winner?, winnerIndex?, failureClasses, primarySkipped? }
//
// FAFF-361: every per-skipped-backend log line below is reshaped to the greppable
// `[chain] <provider>/<model> <reason> → advancing (exit <n>)` form ONLY when the chain is actually
// ADVANCING (verb === "advancing", i.e. a fallback remains) — a clean stdout must never hide which
// elements failed. The terminal ("exhausted", last backend, no fallback left) log line is deliberately
// UNCHANGED — reshaping it is out of scope (the design spec §2: "Restructuring the existing
// exhausted/success stderr log lines").
// FAFF-928 — retained raw adversarial-review response bodies (per lens × backend × round).
// The chain discards every backend's raw bytes the moment it classifies them, so a misclassification
// can never be inspected after the fact and there is no corpus to calibrate the classifier against.
// These helpers persist each backend's raw body (or a metadata stub for a no-body failure) to a
// bounded, self-describing artifact, keyed on the SAME provenance fields FAFF-361's attribution header
// carries. Capture is a pure add-on gated entirely on shared.rawDir, so an absent flag is byte-for-today.

// The injectable write path (mirrors getFn/streamFn/checkFn): real mkdir -p + writeFile, so CI writes
// nothing to disk unless a test injects its own writeFn. FAFF-1056: `opts` is passed through to
// writeFileSync so a caller can request an atomic `wx` exclusive-create (throws EEXIST rather than
// overwrite an existing file); an absent `opts` is byte-for-today.
export function realWrite(filePath, content, opts) {
  mkdirSync(pathDirname(filePath), { recursive: true });
  writeFileSync(filePath, content, opts);
}

// PURE: filename-safe a path segment (provider/model/lens can carry "/" and other unsafe chars).
function sanitizeSegment(s) {
  return String(s == null ? "" : s).replace(/[^A-Za-z0-9._-]/g, "-") || "unknown";
}

// PURE (FAFF-928): the per-backend outcome token that names the artifact — derived from the runReview
// RESULT alone, so it is computed at the single capture site AHEAD of the classification branch (and so
// composes with FAFF-927, which re-partitions that branch, in either merge order). For an OK result it
// reuses the SAME primitives the classification branch keys off (validateFindingsShape /
// normaliseCleanRefutation on the raw content), so the token matches the outcome the loop would record.
// A null `result` (a pre-dispatch config/deadline stub) is handled by the callers, never here.
export function classifyCapturedResult(result, hostSource, expectContract) {
  const status = result && result.status;
  if (status === "ok") {
    const content = (result && result.content) || "";
    if (expectContract) {
      return content.trim() ? { token: "contract", exit: EXIT.OK } : { token: "empty", exit: EXIT.NO_FINDINGS_CONTENT };
    }
    if (!content.trim()) return { token: "empty", exit: EXIT.NO_FINDINGS_CONTENT };
    const shape = validateFindingsShape(content);
    if (shape.ok) return { token: "findings", exit: EXIT.OK };
    const normalisation = normaliseCleanRefutation(content);
    if (normalisation.normalised) return { token: "clean", exit: EXIT.OK };
    if (shape.kind === "empty") return { token: "empty", exit: EXIT.NO_FINDINGS_CONTENT };
    if (shape.kind === "refusal") return { token: "refusal", exit: EXIT.NO_FINDINGS_CONTENT };
    return { token: "malformed", exit: EXIT.MALFORMED };
  }
  const exit = mapResultExit(result, hostSource);
  const byStatus = {
    unreachable: "unreachable", "transport-failed": "transport-failed", "auth-failed": "auth",
    "rate-limited": "rate-limited", "model-not-served": "not-served", "request-failed": "request-failed",
    "unsupported-provider": "unsupported-provider",
  };
  return { token: byStatus[status] || status || "failed", exit };
}

// PURE (FAFF-1228): the completion-record preamble lines for an OK result; [] for a stub, a non-ok result
// or any result without a completion, so those keep today's preamble byte-for-byte. The finish reason is
// re-sanitised here (a no-op on clean input) so a future producer cannot put a newline in a preamble line.
function completionPreambleLines(result) {
  const c = result && result.completion;
  if (!c || typeof c !== "object") return [];
  const safe = sanitizeFinishReason(c.finish_reason);
  const fr = safe != null ? safe : (c.done ? "none" : "none (stream ended without a finish)");
  const lines = [
    `# finish_reason: ${fr}`,
    `# done: ${c.done === true}`,
    `# content_len: ${safeLen(c.content_len)}`,
    `# reasoning_len: ${safeLen(c.reasoning_len)}`,
    `# usage: ${c.usage ? JSON.stringify(c.usage) : "none"}`,
  ];
  if (typeof c.length_retried === "boolean") lines.push(`# length_retried: ${c.length_retried}`);
  return lines;
}

// The one side-effecting capture call. No-op unless shared.rawDir is set — so an absent --raw-dir writes
// NOTHING and never touches writeFn (the byte-for-byte-today invariant). Writes one file per lens ×
// backend × round: a self-describing metadata preamble then the raw body, byte-capped at
// RAW_BODY_MAX_BYTES with an explicit truncation marker. `result` may be null for a no-body stub.
export function captureRawResponseBody(shared, { chainIndex, backend, result, token, exit }) {
  if (!shared || !shared.rawDir) return;
  const writeFn = shared.writeFn || realWrite;
  const b = backend || {};
  const lens = shared.lens || "lens";
  const round = shared.round == null ? "0" : String(shared.round);
  const provider = b.provider || "openai";
  const model = b.model || "unknown";
  const hostSource = b.hostSource || "config";
  const content = (result && result.content) || "";
  const byteLength = Buffer.byteLength(content, "utf8");
  const sha256 = createHash("sha256").update(content, "utf8").digest("hex");
  let body = content;
  let truncated = false;
  if (byteLength > RAW_BODY_MAX_BYTES) {
    body = Buffer.from(content, "utf8").subarray(0, RAW_BODY_MAX_BYTES).toString("utf8")
      + `\n…[truncated ${byteLength - RAW_BODY_MAX_BYTES} bytes]`;
    truncated = true;
  }
  const base = `round-${sanitizeSegment(round)}.${sanitizeSegment(lens)}.${chainIndex}-${sanitizeSegment(provider)}-${sanitizeSegment(model)}.${sanitizeSegment(token)}`;
  const preamble = [
    "# faff-raw-adversarial-body (FAFF-928)",
    `# lens: ${lens}`,
    `# round: ${round}`,
    `# provider: ${provider}`,
    `# model: ${model}`,
    `# chain_index: ${chainIndex}`,
    `# host_source: ${hostSource}`,
    `# classification: ${token}`,
    `# exit: ${exit}`,
    `# truncated: ${truncated}`,
    `# byte_length: ${byteLength}`,
    `# sha256: ${sha256}`,
    ...completionPreambleLines(result),
    "# ---",
    "",
  ].join("\n");
  // FAFF-1056: refuse to overwrite a retained body. The in-turn retry (disposition_unavailable)
  // re-dispatches the same lens with the SAME round/lens/backend/token, so attempt 2 would otherwise
  // clobber attempt 1 — the very fault body that diagnosed the FAFF-1056 incident. Claim the filename
  // with an atomic `wx` exclusive-create (the OS create is the race-arbiter, so two concurrent
  // same-round writers each land on a distinct file); on EEXIST bump a monotonic `.retry-<k>` suffix.
  // The FIRST (fault) body is never lost. This is a within-round (phase-1) guarantee; a hold-resume
  // (phase 2) re-enters on a later drain with an ADVANCED round number, so its `round-<n+1>.…`
  // filename never collides with the `round-<n>.…` fault body — cross-drain preservation is the
  // round-keyed naming that already holds, not a `.retry-<k>` guarantee.
  const log = shared.log || ((m) => process.stderr.write(m + "\n"));
  const RETRY_CAP = 1000;   // defensive: a mis-injected writeFn that always throws EEXIST must not spin forever
  for (let k = 0; k <= RETRY_CAP; k++) {
    const target = k === 0 ? `${base}.txt` : `${base}.retry-${k}.txt`;
    try {
      writeFn(pathJoin(shared.rawDir, target), preamble + body, { flag: "wx" });
      return;
    } catch (e) {
      if (e && e.code === "EEXIST") continue;   // that name is held — bump the suffix and retry
      log(`[raw-capture] FAFF-928: failed to write ${target}: ${e && e.message}`);
      return;
    }
  }
  log(`[raw-capture] FAFF-1056: gave up after ${RETRY_CAP} retry-suffix collisions for ${base}.txt`);
}

export async function runReviewChain(chain = [], shared = {}) {
  const runReviewFn = shared.runReviewFn || runReview;
  const log = shared.log || ((m) => process.stderr.write(m + "\n"));
  const now = shared.nowFn || (() => Date.now());   // FAFF-329: injectable clock for deterministic deadline tests
  const totalDeadlineMs = shared.totalDeadlineMs;   // FAFF-329: total wall-clock budget across ALL backends (undefined ⇒ no bound, byte-for-byte today)
  const start = now();
  const n = chain.length;
  const failureClasses = [];
  // FAFF-1039: why chain[0] was skipped, whatever the cause (over-window guard, 400, auth, empty,
  // deadline). Recorded so a served-by-fallback result can name the reason the primary was not used.
  let firstSkipReason = null;
  for (let i = 0; i < n; i++) {
    // FAFF-329 deadline gate — checked at the TOP of the loop so no NEW backend starts past the budget.
    // On a hit: a needs-human-class fault seen on an earlier backend DOMINATES (no-silent-weakening); else
    // DEADLINE(8) → pass+skip. This is the prevention half — it caps the ~6×timeout×backends blowup.
    if (typeof totalDeadlineMs === "number" && now() - start >= totalDeadlineMs) {
      const nh = failureClasses.find((c) => CHAIN_NEEDS_HUMAN.has(c));
      const exit = nh != null ? nh : EXIT.DEADLINE;
      log(`deadline: Phase-2 total wall-clock budget ${Math.round(totalDeadlineMs / 1000)}s exceeded after ${i} backend(s) (exit ${exit})`);
      return { exit, deadlineExceeded: true, failureClasses, primarySkipped: primarySkipRecord(chain, -1, firstSkipReason) };   // FAFF-1039: surfacing is "always on" — every exhaustion path carries it
    }
    const b = chain[i] || {};
    const tag = `${b.provider || "openai"}/${b.model || "?"}`;
    const verb = i === n - 1 ? "exhausted" : "advancing";
    // A backend missing model or host is a per-element config fault (USAGE) — advance, never abort the chain.
    // provider is optional (omitted ⇒ openai, via runReview/providerFamily — FAFF-872), preserving the
    // legacy single-backend path where callers never passed --provider.
    if (!b.model || !b.host) {
      failureClasses.push(EXIT.USAGE);
      if (i === 0) firstSkipReason = "invalid (missing model/host)";   // FAFF-1039
      if (shared.rawDir) captureRawResponseBody(shared, { chainIndex: i, backend: b, result: null, token: "invalid", exit: EXIT.USAGE });   // FAFF-928: no-body stub — the record of this round stays complete
      log(verb === "advancing"
        ? `[chain] ${tag} invalid (missing model/host) → advancing (exit ${EXIT.USAGE})`
        : `${verb}: backend ${i + 1}/${n} invalid (missing model/host) (exit ${EXIT.USAGE})`);
      continue;
    }
    // A declared-but-unset api key env is that backend's auth fault — no point calling, advance.
    if (b.apiKeyMissing) {
      failureClasses.push(EXIT.AUTH);
      if (i === 0) firstSkipReason = `unset-key (env '${b.apiKeyEnv}')`;   // FAFF-1039
      if (shared.rawDir) captureRawResponseBody(shared, { chainIndex: i, backend: b, result: null, token: "auth", exit: EXIT.AUTH });   // FAFF-928: no-body stub (the FAFF-927 unset-key first-backend case)
      log(verb === "advancing"
        ? `[chain] ${tag} unset-key (env '${b.apiKeyEnv}') → advancing (exit ${EXIT.AUTH})`
        : `${verb}: ${tag} api key env '${b.apiKeyEnv}' unset (exit ${EXIT.AUTH})`);
      continue;
    }
    // FAFF-1039: per-backend context-window guard. Advance DELIBERATELY, before any network call,
    // rather than dispatching into a provider 400 we can already predict. Only ever decides a skip: it
    // never re-trims and never alters the shared prefix, so the FAFF-903 cross-lens byte-identity is
    // untouched. The estimate includes THIS lens's brief (a per-lens skip decision is allowed to differ;
    // a per-lens PREFIX is not). A backend declaring no window is never guard-skipped.
    if (b.contextWindow) {
      const est = estimateTokens(shared.system) + estimateTokens(shared.user);
      if (!fitsWindow(est, b.contextWindow)) {
        const usable = Math.floor(b.contextWindow * DEFAULT_WINDOW_SAFETY);
        const reason = `over-window (est ${est} tok > ${usable} usable window)`;
        failureClasses.push(EXIT.USAGE);
        if (i === 0) firstSkipReason = reason;
        if (shared.rawDir) captureRawResponseBody(shared, { chainIndex: i, backend: b, result: null, token: "over-window", exit: EXIT.USAGE });   // FAFF-928: the round's record stays complete
        log(verb === "advancing"
          ? `[chain] ${tag} ${reason} → advancing (exit ${EXIT.USAGE})`
          : `${verb}: ${tag} ${reason} (exit ${EXIT.USAGE})`);
        continue;
      }
    }
    // FAFF-617: PER-BACKEND SLICE. The whole chain shares one total budget (totalDeadlineMs), but each
    // backend is granted only an EQUAL SHARE of what REMAINS — divided by how many backends are still to
    // try (this one plus the untried ones, n - i) — so a hung/slow backend is abandoned (cancelled, FAFF-1239) at its slice and
    // the healthy fallbacks still fit inside the deadline (the fail-over the chain exists for). The
    // division is recomputed each iteration, so it is WORK-CONSERVING: a fast-failing backend hands its
    // unspent budget back to be re-divided among the survivors. Edge cases fall out of the formula with no
    // special case: n=1, and the last backend (i = n-1), both have backendsLeft=1 ⇒ slice == remaining
    // (byte-for-byte the pre-slice single-backend / final-attempt path); no totalDeadlineMs ⇒ no slice is
    // computed and backendDeadline stays undefined (unbounded, byte-for-byte today).
    let backendDeadline;   // absolute per-backend deadline (undefined ⇒ unbounded)
    let sliceMs;
    if (typeof totalDeadlineMs === "number") {
      const remaining = totalDeadlineMs - (now() - start);
      sliceMs = Math.floor(remaining / (n - i));
      // Slice underflow — no meaningful window left. Route EXACTLY as the top-of-loop total-budget gate
      // (return; a needs-human-class fault seen earlier dominates, else DEADLINE) — never dispatch a
      // zero-window backend that would instantly time out.
      if (remaining <= 0 || sliceMs <= 0) {
        const nh = failureClasses.find((c) => CHAIN_NEEDS_HUMAN.has(c));
        return { exit: nh != null ? nh : EXIT.DEADLINE, deadlineExceeded: true, failureClasses, primarySkipped: primarySkipRecord(chain, -1, firstSkipReason) };   // FAFF-1039
      }
      backendDeadline = now() + sliceMs;
    }
    // The backend is handed backendDeadline as its hardDeadlineMs; the per-family perAttempt clamp then
    // bounds every attempt to min(timeoutMs, backendDeadline - now) FOR FREE — so an over-large configured
    // timeout is clamped to the slice with no rewrite of the configured value (see the anti-pattern note).
    // FAFF-1239: one controller per dispatched element; aborted on a slice win and again once it settles.
    const ac = new AbortController();
    const callReview = () => runReviewFn({
      host: b.host, model: b.model, provider: b.provider,
      system: shared.system, user: shared.user, numPredict: shared.numPredict,
      reasoningOff: b.reasoningOff, reasoningEffort: b.reasoningEffort, reasoningExtra: b.reasoningExtra, apiKey: b.apiKey, timeoutMs: b.timeoutMs,
      hardDeadlineMs: backendDeadline,   // FAFF-617: the per-backend SLICE, not the shared start+total deadline
      firstByteMs: b.firstByteMs,        // FAFF-885: per-attempt first-byte window (per-backend; undefined ⇒ pass-through)
      getFn: shared.getFn, streamFn: shared.streamFn,
      signal: ac.signal,
    });
    let result;
    if (typeof totalDeadlineMs === "number") {
      // Race the backend against ITS SLICE (not the full remaining budget). On a slice win the in-flight
      // backend is ABANDONED, meaning cancelled (FAFF-1239): the element's signal is aborted, which destroys
      // its in-flight request or preflight and ends any retry backoff, so it cannot hold the process open
      // (a trickling socket resets its inactivity timeout and used to outlive the chain). The sentinel timer
      // stays unref'd.
      const SENTINEL = { __deadline: true };
      let timer;
      const deadlineP = new Promise((res) => { timer = setTimeout(() => res(SENTINEL), sliceMs); if (timer && timer.unref) timer.unref(); });
      try {
        result = await Promise.race([safeCall(callReview), deadlineP]);
        clearTimeout(timer);
        if (result === SENTINEL) ac.abort(new Error("chain slice exhausted"));   // BEFORE logging or advancing
      } finally {
        if (!ac.signal.aborted) ac.abort(new Error("chain element settled"));
      }
      if (result === SENTINEL) {
        // FAFF-617: this backend used its whole SLICE — NOT the whole deadline. Record a DEADLINE-class
        // failure and ADVANCE while untried backends remain (the behavioural inversion from FAFF-329, where
        // the mid-call race WAS the whole-deadline race and firing it terminated the chain). Terminate at
        // EXIT.DEADLINE only on the LAST backend (chain exhausted); every earlier slice expiry advances, so
        // a hung primary loses its slice, not the fallbacks' windows. A needs-human-class fault seen on an
        // earlier backend still dominates the terminal exit (no-silent-weakening). Chain termination at
        // EXIT.DEADLINE thus still occurs ONLY via the top-of-loop total-budget gate or this last-backend
        // exhaustion — never mid-chain.
        failureClasses.push(EXIT.DEADLINE);
        if (i === 0) firstSkipReason = `slice ${Math.round(sliceMs / 1000)}s exhausted`;   // FAFF-1039
        if (shared.rawDir) captureRawResponseBody(shared, { chainIndex: i, backend: b, result: null, token: "deadline", exit: EXIT.DEADLINE });   // FAFF-928: dispatched-then-abandoned backend — no-body stub
        log(verb === "advancing"
          ? `[chain] ${tag} slice ${Math.round(sliceMs / 1000)}s exhausted → advancing (exit ${EXIT.DEADLINE})`
          : `deadline: Phase-2 backend ${tag} exhausted its ${Math.round(sliceMs / 1000)}s slice, chain exhausted (exit ${EXIT.DEADLINE})`);
        if (i < n - 1) continue;
        const nh = failureClasses.find((c) => CHAIN_NEEDS_HUMAN.has(c));
        return { exit: nh != null ? nh : EXIT.DEADLINE, deadlineExceeded: true, failureClasses, primarySkipped: primarySkipRecord(chain, -1, firstSkipReason) };   // FAFF-1039
      }
    } else {
      try { result = await safeCall(callReview); }
      finally { ac.abort(new Error("chain element settled")); }
    }
    const exit = mapResultExit(result, b.hostSource);
    // FAFF-928: retain this backend's raw body BEFORE/independently of the classification branch below,
    // so retention never depends on which class it lands in (and composes with FAFF-927 re-partitioning
    // that branch). Gated on rawDir so an absent flag is byte-for-byte today.
    if (shared.rawDir) {
      const cap = classifyCapturedResult(result, b.hostSource, shared.expectContract);
      captureRawResponseBody(shared, { chainIndex: i, backend: b, result, token: cap.token, exit: cap.exit });
    }
    if (exit === EXIT.OK) {
      // FAFF-194/FAFF-465: per-backend shape validation — a non-findings-shaped OK result advances to the
      // next backend rather than short-circuiting the whole chain, so a healthy fallback still gets a
      // chance (mirrors every other per-backend fault class). The `kind` FAFF-465 added maps to one of two
      // exit classes: empty/refusal (a structural inability) → NO_FINDINGS_CONTENT(11); garbled (a
      // reachable-but-degraded symptom) → MALFORMED(10) — the split the terminal CHAIN_NEEDS_HUMAN
      // membership above keys on. The "malformed" log label is retained for the garbled kind only (the
      // pre-existing greppable wording); empty/refusal log their own kind.
      // FAFF-806: `shape` (hence `kind`) is derived from the RAW `originalContent`, never from
      // `normalisation.content` — this is what makes the `kind` discriminator a pure function of the
      // backend's returned bytes, independent of whether normalisation succeeded (the FAFF-465 invariant).
      // The non-findings `continue` below is gated on `!shape.ok && !normalisation.normalised` so a
      // successfully-normalised clean refutation (raw bytes fail shape, but normalisation accepts it) still
      // takes the accepted path with the canonical token — preserving FAFF-746 acceptance.
      const originalContent = result.content || "";
      // FAFF-940: contract-output mode. A consumer that expects a contract block (e.g. the spec-review
      // judge's `faff-contract:spec-judge-verdict`, which is JSON, not `### <severity>:`-shaped) opts out
      // of the findings-shape/clean-refutation gate and validates the block itself downstream. The
      // fallback-chain semantics are otherwise unchanged: a non-empty OK result is accepted verbatim, but
      // an empty/whitespace result still ADVANCES (a dead backend never short-circuits the chain). The
      // default (refuter) path below is untouched — `shared.expectContract` is falsy unless set.
      if (shared.expectContract) {
        if (!originalContent.trim()) {
          failureClasses.push(EXIT.NO_FINDINGS_CONTENT);
          if (i === 0) firstSkipReason = "empty (contract mode: empty content)";   // FAFF-1039
          const completionLog = formatCompletionLog(result.completion);   // FAFF-1228: appended, so every existing prefix and (exit N) stays intact
          log(verb === "advancing"
            ? `[chain] ${tag} empty (contract mode: empty content) → advancing (exit ${EXIT.NO_FINDINGS_CONTENT})${completionLog}`
            : `${verb}: ${tag} produced empty output (contract mode) (exit ${EXIT.NO_FINDINGS_CONTENT})${completionLog}`);
          continue;
        }
        if (i > 0) log(`backend ${i + 1}/${n} ${tag} produced contract output (after ${i} skipped)`);
        return { exit: EXIT.OK, content: originalContent, truncated: !!result.truncated, winner: b, winnerIndex: i, failureClasses, primarySkipped: primarySkipRecord(chain, i, firstSkipReason) };
      }
      const shape = validateFindingsShape(originalContent);
      const normalisation = normaliseCleanRefutation(originalContent);
      if (!shape.ok && !normalisation.normalised) {
        const cls = (shape.kind === "empty" || shape.kind === "refusal") ? EXIT.NO_FINDINGS_CONTENT : EXIT.MALFORMED;
        const label = shape.kind === "garbled" ? "malformed" : shape.kind;
        failureClasses.push(cls);
        if (i === 0) firstSkipReason = `${label} (${shape.reason})`;   // FAFF-1039
        const completionLog = formatCompletionLog(result.completion);   // FAFF-1228
        log(verb === "advancing"
          ? `[chain] ${tag} ${label} (${shape.reason}) → advancing (exit ${cls})${completionLog}`
          : `${verb}: ${tag} produced non-findings output (${shape.reason}) (exit ${cls})${completionLog}`);
        continue;
      }
      if (normalisation.normalised) {
        const responseSha256 = createHash("sha256").update(originalContent, "utf8").digest("hex");
        log(`normalized: clean refutation backend=${tag} lens=${normalisation.lens} form=${normalisation.form} response_sha256=${responseSha256}`);
      }
      if (i > 0) log(`backend ${i + 1}/${n} ${tag} produced findings (after ${i} skipped)`);
      return { exit: EXIT.OK, content: normalisation.content, truncated: !!result.truncated, winner: b, winnerIndex: i, failureClasses, primarySkipped: primarySkipRecord(chain, i, firstSkipReason) };
    }
    failureClasses.push(exit);
    const detail = (result && result.note) || (result && result.names ? `available: ${result.names.join(", ")}` : "");
    if (i === 0) firstSkipReason = `${(result && CHAIN_ADVANCE_REASON[result.status]) || (result && result.status) || "failed"}${detail ? ` (${detail})` : ""}`;   // FAFF-1039
    log(verb === "advancing"
      ? `[chain] ${tag} ${(result && CHAIN_ADVANCE_REASON[result.status]) || (result && result.status) || "failed"}${detail ? ` (${detail})` : ""} → advancing (exit ${exit})`
      : `${verb}: ${tag} failed (${result && result.status}${detail ? ": " + detail : ""}) (exit ${exit})`);
  }
  return { exit: chainTerminalExit(failureClasses), failureClasses, primarySkipped: primarySkipRecord(chain, -1, firstSkipReason) };
}

// PURE (FAFF-1039): the primary-skip record for a result, or null when chain[0] served. `servedIndex`
// is -1 for an exhausted chain (nothing served, but the primary was still skipped for a reason worth
// surfacing in the needs-human diagnostic).
export function primarySkipRecord(chain, servedIndex, reason) {
  if (servedIndex === 0 || !reason) return null;
  const p = (chain && chain[0]) || {};
  return { primary: `${p.provider || "openai"}/${p.model || "?"}`, servedIndex, reason };
}

// `runReviewFn` is injectable so the CLI exit-mapping (notably the FAFF-227 transport-failed → 5/6 path)
// is unit-testable with a stubbed orchestration result; it defaults to the real runReview for the CLI.
// `checkFn` (FAFF-194) is injectable exactly the same way for the refutation pass's node --check calls,
// so CI spawns nothing unless a test opts in; it defaults to the real realCheck for the CLI.
// FAFF-885: resolve the per-attempt first-byte (TTFT) window (ms) at the CLI boundary. Precedence:
// per-backend first_byte_timeout (seconds) > the --first-byte-timeout flag > DEFAULT_FIRST_BYTE_MS
// (DEFAULT-ON). A resolved value <= 0 disables the window (pass-through) — the explicit opt-out. Applied
// only here, so a direct runReview*/runReviewChain call with no firstByteMs stays byte-for-byte today.
function resolveFirstByteMs(perBackendSeconds, flagMs) {
  let ms;
  if (perBackendSeconds != null) ms = Number(perBackendSeconds) * 1000;
  else if (typeof flagMs === "number") ms = flagMs;
  else ms = DEFAULT_FIRST_BYTE_MS;
  return (Number.isFinite(ms) && ms > 0) ? ms : undefined;
}

export async function main(argv, { runReviewFn = runReview, checkFn = realCheck } = {}) {
  const a = parseArgs(argv);
  if (!a.system || !a.diff) {
    process.stderr.write("usage: review-call.mjs (--host H --model M | --backends-json FILE) --system FILE --diff FILE [--context FILE]... [--fixture-path PREFIX]... [--max-tokens N] [--timeout S] [--deadline S] [--host-source config|default] [--provider P] [--api-key-env VAR] [--reasoning-off] [--reasoning-effort E] [--reasoning-extra JSON] [--max-payload-bytes N] [--context-window N] [--expect contract] [--diff-kind unified|prose] [--no-trim] [--raw-dir DIR --lens NAME --round N]\n");
    return EXIT.USAGE;
  }
  // FAFF-1051: the declared diff kind. An unrecognised value is a usage fault (EXIT.USAGE, 2) — the
  // pattern every other argument fault in this function uses — never a throw (which would land on exit 1,
  // a hole the spec-review occupant's per-lens outcome table has no row for) and never a silent coerce to
  // the default (which would hand a prose caller today's 96% loss with no signal).
  const diffKind = a.diffKind === undefined ? "unified" : a.diffKind;
  if (diffKind !== "unified" && diffKind !== "prose") {
    process.stderr.write(`usage: --diff-kind must be "unified" or "prose", got ${JSON.stringify(a.diffKind)}\n`);
    return EXIT.USAGE;
  }

  // Build the ordered chain (FAFF-232). --backends-json is the COMPLETE chain (a JSON array of backend
  // objects, the skill assembles it from primary scalars + the fallbacks JSON-string); when absent the
  // legacy single-backend flags form a 1-element chain that reproduces the old path byte-for-byte.
  // --backends-json wins when both are present.
  let chain;
  if (a.backendsJson) {
    let raw;
    try { raw = JSON.parse(readFileSync(a.backendsJson, "utf8")); }
    catch (e) { process.stderr.write(`--backends-json: cannot read/parse ${a.backendsJson}: ${e.message}\n`); return EXIT.USAGE; }
    if (!Array.isArray(raw) || raw.length === 0) {
      process.stderr.write("--backends-json must be a non-empty JSON array of backends\n");
      return EXIT.USAGE;
    }
    chain = raw.map((b) => ({
      provider: b.provider, model: b.model, host: b.host,
      hostSource: "config",   // host_source is DERIVED, not authored: every listed backend is explicitly
                              // configured, so it is always "config" (→ unreachable maps to 5/pass+skip,
                              // never 6). The unconfigured-localhost-default (6) only arises in the legacy
                              // single-backend path below, never inside an explicit chain.
      apiKeyEnv: b.api_key_env || b.apiKeyEnv,
      auth: b.auth,                                   // FAFF-481: carried so a subscription-seat resolves its handle
      seatTokenEnv: b.seat_token_env || b.seatTokenEnv,
      reasoningOff: b.reasoning_off ?? b.reasoningOff ?? false,
      reasoningEffort: b.reasoning_effort ?? b.reasoningEffort,   // FAFF-873: snake_case (config) tolerated alongside camelCase, matching reasoning_off
      reasoningExtra: b.reasoning_extra ?? b.reasoningExtra ?? null,   // FAFF-914: per-model reasoning-control passthrough (snake_case config / camelCase tolerated)
      timeoutMs: (b.timeout != null) ? Number(b.timeout) * 1000 : a.timeoutMs,
      firstByteMs: resolveFirstByteMs(b.first_byte_timeout ?? b.firstByteTimeout, a.firstByteMs),   // FAFF-885
      // FAFF-1039: the operator-declared token window, normalised HERE because this mapper is the one
      // point every chain-assembly form converges on (only the two `refs:` forms pass through
      // backends.js's normalizeBackend; the native array and legacy forms do not). null ⇒ unbounded.
      contextWindow: normaliseContextWindow(b.context_window ?? b.contextWindow),
    }));
  } else {
    if (!a.host || !a.model) {
      process.stderr.write("usage: review-call.mjs --host H --model M ... (or --backends-json FILE)\n");
      return EXIT.USAGE;
    }
    chain = [{
      provider: a.provider, model: a.model, host: a.host, hostSource: a.hostSource,
      apiKeyEnv: a.apiKeyEnv, reasoningOff: a.reasoningOff, reasoningEffort: a.reasoningEffort, reasoningExtra: a.reasoningExtra, timeoutMs: a.timeoutMs,
      firstByteMs: resolveFirstByteMs(undefined, a.firstByteMs),   // FAFF-885
      contextWindow: normaliseContextWindow(a.contextWindow),        // FAFF-1039: --context-window, else unbounded
    }];
  }

  // Resolve each backend's token from its NAMED env var (never the key on the command line / in config).
  // An unset env for a declared handle is flagged per-backend (a class-7 fault that ADVANCES) rather than a
  // whole-run abort — so a misconfigured primary falls through to a healthy fallback.
  //
  // FAFF-481: which env var holds the token follows backends.js `resolveTokenSource` (mirrored here — this
  // is a standalone .mjs with no faff CommonJS imports): auth: api-key → api_key_env; auth: subscription-seat
  // → seat_token_env (the headless seat handle — a spawned review subprocess has no ambient session, so a
  // handle-LESS seat resolves no token and fails auth-failed, correctly). The resolved token is sent as
  // Bearer (openai) or x-api-key (the FAFF-210 anthropic adaptor) downstream — one field, either header shape.
  // A legacy chain entry with no `auth` field falls back to api_key_env — byte-for-byte today.
  for (const b of chain) {
    const tokenEnv = (b.auth === "subscription-seat") ? b.seatTokenEnv
      : (b.auth === "api-key") ? b.apiKeyEnv
      : (b.apiKeyEnv || null);   // legacy / unspecified auth → api_key_env, unchanged
    if (tokenEnv) {
      b.apiKey = process.env[tokenEnv];
      if (!b.apiKey) b.apiKeyMissing = true;
    }
  }

  const system = readFileSync(a.system, "utf8");
  const diff = readFileSync(a.diff, "utf8");
  const contextFilesRaw = a.context.map((p) => ({ path: p, text: readFileSync(p, "utf8") }));
  if (!system.trim() || !diff.trim()) {
    process.stderr.write("review inputs must contain a non-empty system prompt and diff\n");
    return EXIT.USAGE;
  }
  // FAFF-915: trim the context bundle to the diff-relevant regions before assembly. A no-op below the
  // byte threshold (byte-identical to today) and when --context-trim-bytes is 0. Only the winning
  // backend's content is affected via the assembled user message; the trim is pure and identical across
  // lenses, so the shared-prefix cache (FAFF-903) still holds.
  // FAFF-1051: `diffKind` (resolved above) selects the kind; "prose" is a pass-through (FAFF-1058).
  // FAFF-1058: --no-trim drives pass 1 to its disabled short-circuit (thresholdBytes 0) AND skips the
  // FAFF-1039 window pass below, so both passes are no-ops.
  const noTrim = a.noTrim === true;
  const { contextFiles, report: trimReport } = trimContextFiles({
    contextFiles: contextFilesRaw,
    diff,
    thresholdBytes: noTrim ? 0 : (a.contextTrimBytes === undefined ? DEFAULT_CONTEXT_TRIM_BYTES : a.contextTrimBytes),
    diffKind,
  });
  switch (trimReport.reason) {
    case "trimmed":
      process.stderr.write(`[note] FAFF-915 context trim: ${trimReport.bytesBefore} → ${trimReport.bytesAfter} context bytes (diff-relevant regions kept)\n`);
      // FAFF-1051 advisory: a zero-hunk parse under the unified default means the reduction above was
      // head truncation dressed as relevance — the exact failure this ticket names. Observation only,
      // never a gate: text inspection can honestly say the parse yielded no hunks, not what the caller
      // meant to pass.
      if (trimReport.hunks === 0) {
        process.stderr.write(`[note] FAFF-1051 the --diff parsed as 0 unified-diff hunks, so the reduction above is head truncation, not relevance; if this input is not a unified diff, pass --diff-kind prose\n`);
      }
      break;
    default:
      break;   // "disabled" / "under-threshold" / "prose-passthrough": no note, unchanged
  }
  // FAFF-1066: confirm --no-trim explicitly. Gated on the `noTrim` flag itself, never on
  // `trimReport.reason` — reason "disabled" also arises from --context-trim-bytes 0 alone, which
  // leaves the FAFF-1039 window pass below still running (a declared context-window overrides a
  // bare zero byte-gate), so keying off "disabled" would both fire on the wrong condition and
  // misreport "both passes off". `noTrim` is the only signal that is true exactly when both trim
  // passes (this one and the FAFF-1039 window pass below) are disabled for this call.
  if (noTrim) {
    process.stderr.write(`[note] FAFF-1058 --no-trim: context trimming disabled for this call (both passes off)\n`);
  }
  let user = assembleUserMessage({ contextFiles, diff });

  // FAFF-1039: window-targeted trim of the SHARED PREFIX, once, pre-chain, targeting the PRIMARY
  // backend's usable window. Sizing to the strongest reviewer is the availability that matters; the
  // weaker backends are honoured by the per-backend guard in runReviewChain, which only ever decides
  // skips and never re-trims, so the prefix stays one set of bytes for the whole chain. The target
  // reserves a FIXED brief allowance rather than the actual per-lens brief, so the trimmed prefix is a
  // pure function of (context, diff, primary window) and byte-identical across the four spec-review
  // lenses — the FAFF-903 shared-prefix cache survives. Inert when the primary declares no window.
  // FAFF-1058: skipped entirely for the prose kind (a spec never trims) and when --no-trim is set. The
  // `diffKind !== "prose"` clause alone excludes prose; `noTrim` is the operator opt-out. Either way the
  // per-backend guard still handles an over-window payload as an honest skip.
  const primaryWindow = chain.length ? chain[0].contextWindow : null;
  if (primaryWindow && !noTrim && diffKind !== "prose") {
    const usable = Math.floor(primaryWindow * DEFAULT_WINDOW_SAFETY);
    const estWithReserve = estimateTokens(user) + DEFAULT_BRIEF_RESERVE_TOKENS;
    if (estWithReserve > usable) {
      const target = trimTargetBytes(primaryWindow, diff);
      const targetClamped = trimTargetClamped(primaryWindow, diff);
      const tightened = tightenToTarget({ contextFiles: contextFilesRaw, diff, targetBytes: target });
      // Adopt the tightened prefix ONLY when it is genuinely smaller. This clamp is LOAD-BEARING, not
      // belt-and-braces, and min-tracking alone does not subsume it: the default trim above is gated on
      // a 48KB byte threshold and is an identity no-op below it, so `user` may be the RAW assembly,
      // while the ladder always trims (thresholdBytes: 1). On a file whose lines are shorter than an
      // elision marker, every rung then pays more in markers than it saves, so even the smallest rung
      // exceeds the untrimmed original. Without this clamp the payload grows and the note below
      // misreports it as smaller. Handing the chain a LARGER payload would push fallbacks over their
      // own windows, the exact inverse of the point; keeping the original is always safe, since the
      // per-backend guard and the primary-skip surfacing still handle the residual overflow.
      const beforeBytes = Buffer.byteLength(user, "utf8");
      const adopted = tightened.bytes < beforeBytes;
      if (adopted) user = tightened.prefix;
      const estAfter = estimateTokens(user);
      const rungDesc = `trim-window ${tightened.window}`;
      process.stderr.write(
        `[note] FAFF-1039 window-targeted trim: est ${estWithReserve} tok (incl. ${DEFAULT_BRIEF_RESERVE_TOKENS} brief reserve) exceeded usable ${usable} `
        + `(primary window ${primaryWindow}); `
        + (adopted
          ? `tightened to ${rungDesc}, now est ${estAfter + DEFAULT_BRIEF_RESERVE_TOKENS} tok (${tightened.contextBytes} B vs ${target} B target`
            + `${targetClamped ? ", clamped to floor" : ""})`
            // Keyed off the REAL window check, never `tightened.fitted`. `fitted` means "hit the byte
            // target", and once a large diff drives the budget below MIN_TRIM_TARGET_BYTES the target
            // clamps to that floor, so hitting it no longer implies fitting the window. Reporting a fit
            // there would repeat the very dishonesty this note exists to prevent.
            + `${stillOverWindow(estAfter, DEFAULT_BRIEF_RESERVE_TOKENS, usable) ? " — STILL OVER the usable window, but smaller" : ""}`
          : `no rung shrank it (best ${tightened.bytes} B vs ${beforeBytes} B already assembled) — KEEPING the untightened prefix`)
        + `\n`);
    }
  }

  // FAFF-445: oversized-diff preflight — size-check the assembled payload BEFORE any chain element is
  // dispatched (before mandatory-ness is even resolved, before runReviewChain is called). An oversized
  // payload is flagged and refused, never silently trimmed — the exact material a preflight would drop is
  // what the reviewer needs to do its job. Reuses EXIT.USAGE (2), the same needs-human-class terminal
  // FAFF-414 established for a caught non-transient throw (see the FAFF-445 spec, Decision 2) — no new
  // exit code, no new SKILL.md table row beyond broadening the existing exit-2 description.
  const sizeCheck = checkPayloadSize({ system, user, maxBytes: a.maxPayloadBytes });
  if (sizeCheck.oversized) {
    process.stderr.write(`oversized-diff preflight: assembled payload ${sizeCheck.bytes} bytes exceeds the ${sizeCheck.maxBytes} byte threshold — flagged before dispatch, no backend called (exit ${EXIT.USAGE})\n`);
    return EXIT.USAGE;
  }

  // FAFF-401: derive mandatory-ness mechanically from the run ledger BEFORE the mandatoryRemap chokepoint,
  // so no model step sits between the resolved L4 level and the flag. The explicit --lights-out flag still
  // FORCES mandatory (OR, never AND — a caller that resolved L4-ness itself is trusted); the explicit
  // --run-dir wins over the ambient FAFF_RUN_DIR env on conflict (mirrors the appetite resolver).
  a.mandatory = a.mandatory || ledgerMandatory(a.runDir ?? process.env.FAFF_RUN_DIR);

  // FAFF-617: advisory budget warning — surfaced once to stderr before dispatch, never gating. The
  // per-backend slice (runReviewChain) makes a bad timeout/deadline combination non-fatal (fail-over still
  // happens), but a timeout so high no backend can finish its retry composition inside its slice still
  // silently truncates that backend's retries. This is where the assembled chain (with each element's
  // timeoutMs) and a.totalDeadlineMs both exist, so it is where the check belongs. It never changes an
  // exit code and never blocks dispatch.
  for (const w of budgetWarnings(chain, a.totalDeadlineMs)) process.stderr.write(w + "\n");

  // FAFF-903: reorder the wire payload so the shared context/diff block is the cacheable prefix and
  // the per-lens brief trails it. One swap, here at the caller seam: the shared block (the
  // assembleUserMessage output) goes to the builders' `system` argument (their prefix slot: messages[0]
  // for OpenAI-compatible, top-level `system` for Anthropic) and the lens brief (--system) to their
  // `user` argument. No builder edit and no streaming-path change: both families place the shared block
  // in their prefix position for free. The `system`/`user` locals above keep their CLI-flag meaning
  // (`system` = --system = the lens brief); the two aliases below make the swapped roles explicit.
  const sharedBlock = user;   // assembleUserMessage output — byte-identical across the four spec-review lenses
  const lensBrief = system;   // the --system refuter brief — the only per-lens-differing part
  const res = await runReviewChain(chain, { system: sharedBlock, user: lensBrief, numPredict: a.numPredict, runReviewFn, totalDeadlineMs: a.totalDeadlineMs, expectContract: a.expectContract, rawDir: a.rawDir, lens: a.lens, round: a.round });

  // FAFF-1039 (fix-direction 4, always on): whenever the backend that served was NOT the primary, say
  // so loudly. A silent downgrade to a weaker reviewer was previously visible only as one stderr line
  // on an otherwise-green pass. The machine sentinel goes on its own stderr line for fan-out.mjs; the
  // human notice rides stdout with the findings, where the operator actually reads the review.
  if (res.primarySkipped) {
    process.stderr.write(PRIMARY_SKIP_SIGNAL + "\n");
    process.stderr.write(`[note] FAFF-1039 primary reviewer ${res.primarySkipped.primary} was skipped — ${res.primarySkipped.reason}\n`);
  }
  if (res.exit === EXIT.OK) {
    if (res.truncated) {
      // Human note (audit trail; wording is NOT a contract — reword freely).
      process.stderr.write("[note] response truncated at token budget even after retry; findings may be partial\n");
      // FAFF-990: the MACHINE contract — a dedicated, exported constant on its own stderr line. The
      // shared fan-out layer resolves it into a `LensResult.truncated` boolean (line-anchored equality,
      // never a substring of the human note), so a spec-review-only downstream can distinguish a
      // truncation transient from a config fault WITHOUT re-deriving res.truncated or substring-matching
      // prose. Additive stderr only — no control-flow, exit-code, stdout, or chain-behaviour change, so
      // the code-review consumer and the transport's golden tests are unaffected.
      process.stderr.write(TRUNCATION_SIGNAL + "\n");
    }
    // FAFF-940: contract-output mode emits the winning backend's block verbatim. The findings-only
    // refutation pass and the `## Adversarial findings` header prepend below both assume findings-shaped
    // content, so they would corrupt a contract block (e.g. a JSON verdict) — skip them entirely.
    if (a.expectContract) {
      // The primary-skip stderr sentinel + note above already fired; stdout stays the verbatim
      // contract block (splicing a human notice in would corrupt the JSON the consumer parses).
      process.stdout.write((res.content || "").trim() + "\n");
      return EXIT.OK;
    }
    // FAFF-194: refutation pass (machine-checkable syntax claims, downgrade-only) then header
    // normalisation (harness-authored provenance), in that order — both run on the winning content only.
    const { content: refuted, refutations } = refuteFindings(res.content || "", a.context, { checkFn });
    for (const r of refutations) {
      process.stderr.write(`refuted: "${r.title}" — node --check clean on ${r.files.join(", ")}; ${r.from} → observation\n`);
    }
    const { content: capped, caps } = capFixtureFindings(refuted, diff, a.context, a.fixturePaths);
    for (const c of caps) {
      process.stderr.write(`capped: "${c.title}" (fixture data in ${c.files.join(", ")}); ${c.from} → minor\n`);
    }
    const hadHeader = hasHeader(capped);
    let finalContent = ensureHeader(capped, res.winner, res.winnerIndex);
    if (!hadHeader) process.stderr.write("normalized: findings header missing — prepended canonical provenance\n");
    // FAFF-1039: the human notice, immediately after the harness-authored attribution header, so the
    // operator reading the findings is told the strongest configured reviewer did not produce them.
    if (res.primarySkipped) {
      const lines = String(finalContent).split("\n");
      const hdr = findHeaderLineIdx(lines);   // the module's own preamble-scoped locator — never a third copy of the literal
      const notice = `NOTE: primary reviewer ${res.primarySkipped.primary} was skipped; served by chain[${res.primarySkipped.servedIndex}] — ${res.primarySkipped.reason}.`;
      if (hdr === -1) lines.unshift(notice, "");
      else lines.splice(hdr + 1, 0, "", notice);
      finalContent = lines.join("\n");
    }
    process.stdout.write((finalContent || "").trim() + "\n");
    return EXIT.OK;
  }
  // FAFF-398: single-chokepoint mandatory remap. On a MANDATORY review (L4 --lights-out), an exhausted chain
  // that yielded NO opinion (UNREACHABLE/5 or DEADLINE/8) fails CLOSED → MANDATORY_OUTAGE(9 → needs-human).
  // Applied ONCE here on runReviewChain's terminal exit, so every exhaustion path (the three deadline returns
  // + the chain-exhausted return) is covered by construction; config-fault classes (2/4/6/7) pass through.
  const finalExit = mandatoryRemap(res.exit, a.mandatory);
  if (finalExit === EXIT.MANDATORY_OUTAGE) {
    process.stderr.write(`adversarial review: MANDATORY second opinion unavailable — chain exhausted, no opinion obtained (mandatory-chain-outage); exit ${EXIT.MANDATORY_OUTAGE} → needs-human\n`);
  } else if (finalExit === EXIT.DEADLINE) {
    // FAFF-329: a deadline-skip is surfaced loudly (never silent) — its own line so the run log + /faff-wtf see it.
    process.stderr.write(`adversarial review: phase2 skipped-deadline (total wall-clock budget hit before findings); exit ${EXIT.DEADLINE} → pass+skip\n`);
  } else if (chain.length > 1) {
    const provenance = res.exit === EXIT.UNREACHABLE ? "pass+skip"
      : res.exit === EXIT.DEFAULT_HOST_UNREACHABLE ? "needs-human (default host)" : "needs-human";
    process.stderr.write(`adversarial chain exhausted (${chain.length} backends, none produced findings); terminal exit ${res.exit} → ${provenance}\n`);
  }
  return finalExit;
}

// FAFF-1239: CLI-only exit backstop. main's return value decides the exit code, but the process only ends
// when the event loop drains; if some handle leaks, an unref'd timer forces the exit after a short grace,
// naming the leak on stderr, so a served review is not turned into a deadline skip by review-spawn's hard
// kill. It never fires on the healthy path (the unref'd timer does not keep the loop alive).
export const EXIT_BACKSTOP_GRACE_MS = 2000;
export function armExitBackstop(code, {
  graceMs = EXIT_BACKSTOP_GRACE_MS,
  write = (s) => process.stderr.write(s),
  exit = (c) => process.exit(c),
  flush = (cb) => process.stdout.write("", cb),
  activeResources = () => (process.getActiveResourcesInfo ? process.getActiveResourcesInfo() : []),
} = {}) {
  const t = setTimeout(() => {
    let kinds;
    try { kinds = activeResources().join(", "); } catch { kinds = ""; }
    write(`review-call: process still alive ${graceMs}ms after main returned exit ${code}; leaked handle(s): ${kinds || "unknown"}; forcing exit ${code} (FAFF-1239)\n`);
    flush(() => exit(code));
  }, graceMs);
  t.unref();
  return t;
}

// The CLI entry's settle handlers, extracted so a test can drive both paths.
export function runCli(mainPromise, { proc = process, arm = armExitBackstop } = {}) {
  return mainPromise
    .then((code) => { proc.exitCode = code; arm(code); })
    .catch((e) => { proc.stderr.write(`review-call: ${e.message}\n`); proc.exitCode = EXIT.OTHER; arm(EXIT.OTHER); });
}

if (process.argv[1] && process.argv[1].endsWith("review-call.mjs")) {
  runCli(main(process.argv.slice(2)));
}
