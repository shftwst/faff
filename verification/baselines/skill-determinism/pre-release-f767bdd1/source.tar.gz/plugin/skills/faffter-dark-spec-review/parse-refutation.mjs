#!/usr/bin/env node
// FAFF-938 — deterministic parser for the spec-review refuter objection triple.
//
// Each spec-review lens's refuter runs as an independent `review-call.mjs` pass and returns
// markdown prose: a `### [severity]` block per objection, carrying `- claim:` / `- evidence:` /
// `- predicted_consequence:` / `- spec_anchor:` bullets (FAFF-935/FAFF-943). Nothing previously
// converted that prose into the `objections[]` JSON `aggregate.mjs` rolls up — the occupant's own
// prose told an LLM to hand-build the JSON, and a lens that omitted or malformed a triple field on
// a GATING objection was silently dropped at three downstream points. This module closes that seam:
// a deterministic, zero-dependency parser that extracts the triple and fails loud (non-zero exit,
// never a silent drop) when a gating objection is missing a required field.
//
// Input model — the TRANSPORT's post-normalisation exit-0 stdout, never the raw `refute-*.md`
// prompt output: by the time `review-call.mjs` exits 0, it has already (a) normalised every clean
// refutation to the single canonical token `### observation: no findings` (`normaliseCleanRefutation`
// -> `CANONICAL_NO_FINDINGS`), and (b) downgraded any mechanically-disproved gating section to a
// non-gating `[auto-refuted]` observation (`refuteFindings`). Both the grammar below and this
// module's test fixtures are pinned to those post-normalisation wire bytes.
//
// Self-contained by design (see the spec's Design Decision Rationale): this module owns its own
// small section/bullet grammar rather than importing `review-call.mjs`'s `splitFindings` — no
// cross-skill runtime import, no transport touch. A fixture test pinned to the transport's actual
// exit-0 stdout is what keeps the two grammars honest if they ever drift.
//
// Pure functions carry no I/O and are unit-tested directly; the CLI is a thin stdin->stdout wrapper,
// the same shape as the sibling `aggregate.mjs`.

import { readFileSync, realpathSync } from "node:fs";
import { pathToFileURL } from "node:url";

// The transport's canonical clean-refutation token (review-call.mjs's CANONICAL_NO_FINDINGS,
// duplicated here rather than imported — self-contained by design). A clean refutation crosses the
// exit-0 wire as exactly this single non-gating observation section; there is no
// "No <lens> objection." form on the wire, only pre-normalisation.
export const CANONICAL_NO_FINDINGS = "### observation: no findings";

// Section boundary: a `### ` heading (excludes `####`+ — an h4+ inside a finding body is not a new
// finding boundary). Mirrors review-call.mjs's HEADING_LINE_RE.
const HEADING_LINE_RE = /^###\s(?!#)/;
// Severity classification from the heading line. Mirrors review-call.mjs's SEVERITY_HEADING_RE so
// the two grammars agree on what counts as a recognised severity word.
const SEVERITY_HEADING_RE = /^###\s*\[?(critical|major|minor|observation)\]?\s*[:—-]\s*(.*)$/i;
const GATING_SEVERITIES = new Set(["critical", "major", "minor"]);
// FAFF-1223: the fault reason for a severity-less section that carries triple/anchor bullets.
const UNRECOGNISED_FINDING_REASON = "finding section without a recognised severity (### <severity>: ...)";

// A triple/anchor bullet: "- <key>: <value>". Case-insensitive key, same closed vocabulary the
// refuter prompts emit. The key may carry markdown emphasis ("- **claim:**", "- _claim_:").
export const BULLET_RE = /^-\s*(?:\*{1,2}|_{1,2})?(claim|evidence|predicted_consequence|spec_anchor)(?:\*{1,2}|_{1,2})?\s*:\s*(?:\*{1,2}|_{1,2})?\s*(.*)$/i;
// A heading line of any level — stops a bullet-value continuation from swallowing past a section
// boundary. Bodies are already sliced to one section, so this is a defensive guard only.
const ANY_HEADING_RE = /^#{2,}\s(?!#)/;

// PURE: split content on `### ` heading lines into an ordered list of sections. Each section spans
// from its heading to (exclusive) the next `### ` heading or EOF.
function splitSections(content) {
  const lines = String(content == null ? "" : content).split("\n");
  const idxs = [];
  for (let i = 0; i < lines.length; i++) if (HEADING_LINE_RE.test(lines[i])) idxs.push(i);
  const sections = [];
  for (let i = 0; i < idxs.length; i++) {
    const start = idxs[i];
    const end = i + 1 < idxs.length ? idxs[i + 1] : lines.length;
    const heading = lines[start];
    const body = lines.slice(start + 1, end).join("\n");
    const m = heading.match(SEVERITY_HEADING_RE);
    const severity = m ? m[1].toLowerCase() : null;
    const title = m ? m[2].trim() : heading.replace(/^###\s*/, "").trim();
    sections.push({ heading: heading.trim(), severity, title, body });
  }
  return sections;
}

// PURE: extract the triple/anchor bullets from a section body. FAFF-1240 value extent: a
// `spec_anchor` value is its bullet line only (it is a single slug by the prompt grammar). A
// `claim`, `evidence` or `predicted_consequence` value is its bullet line plus following non-blank
// lines (a naturally wrapped value stays whole), ending at the first blank line after content;
// blank lines before any content are skipped, so a bare "- claim:" followed by a blank line and then
// the text still yields that text. A closed field ignores lines until the next recognised bullet or
// any heading line, so a refuter's closing prose is not stored in the last field. A non-bullet,
// non-heading line before any bullet has been seen is discarded (narrative lead-in, not a field).
// A repeated key: last one wins.
function parseBullets(body) {
  const lines = String(body == null ? "" : body).split("\n");
  const fields = {};
  let key = null;
  let buf = [];
  let closed = false;
  const flush = () => {
    if (key) fields[key] = buf.join("\n").trim();
    key = null;
    buf = [];
    closed = false;
  };
  for (const line of lines) {
    const m = line.match(BULLET_RE);
    if (m) {
      flush();
      key = m[1].toLowerCase();
      buf = [m[2]];
      closed = key === "spec_anchor";
      continue;
    }
    if (ANY_HEADING_RE.test(line)) {
      flush();
      continue;
    }
    if (key === null || closed) continue;
    if (/^\s*$/.test(line)) {
      if (buf.join("").trim() !== "") closed = true;
      continue;
    }
    buf.push(line);
  }
  flush();
  return fields;
}

// PURE: the harness-authored header line is `## Adversarial findings — <provider>/<model> (chain[<i>],
// host: <source>)`, unconditionally prepended by the transport (ensureHeader). Read `provider/model`
// verbatim from it — scanning the PREAMBLE only (before the first `### ` finding heading), mirroring
// review-call.mjs's own preamble-scoped header search (findHeaderLineIdx) so a finding body that
// happens to quote a header-shaped line is never mistaken for the document's own provenance line.
const HEADER_RE = /^##\s*Adversarial findings\s*(?:—|-{1,2})\s*(\S+)/i;
function headerModel(content) {
  const lines = String(content == null ? "" : content).split("\n");
  for (const line of lines) {
    if (HEADING_LINE_RE.test(line)) break; // preamble ends at the first finding heading
    const m = line.match(HEADER_RE);
    if (m) return m[1];
  }
  return undefined;
}

// PURE: parseRefutation(content, lens) -> { ok: true, entry: RefutationEntry }
//                                        | { ok: false, fault: ParseFault }
//
// RefutationEntry: { lens, outcome: "refuted"|"clear", objections: [Objection], model?: string }
// Objection:       { severity, claim, evidence, predicted_consequence, spec_anchor? }  (gating)
//                   { severity, claim?, evidence?, predicted_consequence?, spec_anchor? }  (observation)
// ParseFault:       { lens, severity, title, missing_field: "claim"|null, reason? }  (FAFF-990: only `claim` gates;
//                   FAFF-1223: a finding-shaped severity-less section faults with severity "unknown", missing_field null)
export function parseRefutation(content, lens) {
  const text = String(content == null ? "" : content);
  const sections = splitSections(text);
  const model = headerModel(text);

  // FAFF-1056: skip severity-less `### ` sections as non-finding prose (a reasoning model's leaked
  // `### Analysis`/`### My reasoning` deliberation headings, a narrative preamble), mirroring
  // parseBullets' existing discard of a narrative lead-in before the first bullet. The transport's
  // shape-gate (validateFindingsShape) admits any body with >=1 severity-bearing section; the old
  // parser then demanded EVERY `### ` section carry a severity and faulted on the first that did not,
  // so a leaked reasoning heading ahead of a well-formed finding passed the gate but voided the whole
  // lens (mis-attributed config-fault -> needs-human park). Tolerate the prose here: a severity-less
  // section with no triple/anchor bullet is skipped. FAFF-1223: a severity-less section that IS
  // finding-shaped (parseBullets reads at least one key) is a finding the model forgot to head with a
  // severity, so it faults the lens below instead of being dropped; the parser never guesses a severity.
  const recognisedSections = sections.filter((s) => s.severity != null);

  // Fault iff NO recognised-severity section survives. This single truthful guard subsumes the old
  // `sections.length === 0` and `s.severity == null` arms, both of which carried a false
  // "should be unreachable" premise about the shape-gate establishing `all` when it only guarantees
  // `>=1`. The guard is reachable by construction (a body of only severity-less sections) and
  // correctly so: a findings-less body is a genuine fault (no objections to grade), never a silent
  // clean pass — which would reintroduce exactly the silent-drop this module was built to remove.
  if (recognisedSections.length === 0) {
    return {
      ok: false,
      fault: { lens, severity: "unknown", title: "(none)", missing_field: null, reason: "no recognised finding section (### <severity>: ...)" },
    };
  }

  // FAFF-1223: fail closed on a finding-shaped severity-less section. Runs after the zero-recognised
  // guard (which keeps priority on an all-severity-less body) and before the clean fast path, so the
  // canonical clean token cannot mask a finding. The first such section in document order is named.
  const unrecognisedFinding = sections.find((s) => s.severity == null && Object.keys(parseBullets(s.body)).length > 0);
  if (unrecognisedFinding) {
    return {
      ok: false,
      fault: { lens, severity: "unknown", title: unrecognisedFinding.title, missing_field: null, reason: UNRECOGNISED_FINDING_REASON },
    };
  }

  // Clean refutation: the transport's canonical single-observation token as the ONLY recognised
  // section. Re-keyed off recognisedSections (not sections.length) so a leaked severity-less
  // preamble no longer defeats the clean fast-path.
  const gatingCount = recognisedSections.filter((s) => GATING_SEVERITIES.has(s.severity)).length;
  if (gatingCount === 0 && recognisedSections.length === 1 && recognisedSections[0].heading === CANONICAL_NO_FINDINGS) {
    const entry = { lens, outcome: "clear", objections: [] };
    if (model) entry.model = model;
    return { ok: true, entry };
  }

  const objections = [];
  for (const s of recognisedSections) {
    // The `### observation: no findings` sentinel is the clean marker and is NEVER pushed as an
    // objection — that is what makes a clean lens's objections == []. A mixed body carrying it
    // alongside real findings drops it here, matching the clean fast-path's exclusion above.
    if (s.heading === CANONICAL_NO_FINDINGS) continue;
    const fields = parseBullets(s.body);
    const gating = GATING_SEVERITIES.has(s.severity);
    if (gating) {
      // FAFF-990: `claim` is the ONLY identifying field a gating objection must carry. `evidence`
      // and `predicted_consequence` are enrichment — carried when present+non-empty (below), omitted
      // otherwise, NEVER a fault. A backend that truncated mid-objection (spending its token budget
      // before finishing the triple) still served a usable claim; voiding the whole lens over a
      // clipped enrichment field mis-attributed a per-response model transient to config-fault/park.
      // A gating section with no non-empty `claim` is the one residual fault (missing_field:"claim").
      const claim = fields.claim;
      if (typeof claim !== "string" || claim.trim() === "") {
        return { ok: false, fault: { lens, severity: s.severity, title: s.title, missing_field: "claim" } };
      }
    }
    // Carry whatever triple/anchor fields are present as non-empty strings — `claim` is required (and
    // therefore guaranteed present) on a gating section; `evidence`/`predicted_consequence` are
    // enrichment, omitted when absent (never sentinel-filled), best-effort/unchecked on an observation.
    const obj = { severity: s.severity };
    for (const field of ["claim", "evidence", "predicted_consequence"]) {
      if (typeof fields[field] === "string" && fields[field].trim() !== "") obj[field] = fields[field].trim();
    }
    if (typeof fields.spec_anchor === "string" && fields.spec_anchor.trim() !== "") obj.spec_anchor = fields.spec_anchor.trim();
    objections.push(obj);
  }

  const outcome = objections.some((o) => GATING_SEVERITIES.has(o.severity)) ? "refuted" : "clear";
  const entry = { lens, outcome, objections };
  if (model) entry.model = model;
  return { ok: true, entry };
}

// ---- CLI ------------------------------------------------------------------------------------
// `parse-refutation.mjs --lens <lens> [--truncated]` reads one refuter's raw exit-0 stdout on stdin.
//   exit 0      -> the RefutationEntry JSON on stdout (objections may be degraded — claim-only).
//   exit 1      -> a RESIDUAL parse fault (a gating section with no usable `claim`, a body with no
//                  recognised-severity section, or a finding-shaped section without a severity, FAFF-1223) WITHOUT --truncated:
//                  `{lens, outcome:"unavailable", kind:"model-transient", objections:[]}` on stdout, a
//                  human diagnostic on stderr. FAFF-1056: a parser-stage residual fault is NEVER a
//                  config fault — `parseRefutation` only ever sees a body the transport served and the
//                  shape-gate passed, so the config demonstrably worked; the off-grammar content is a
//                  model-quality transient a re-run is likely to clear. `model-transient` is
//                  swing-capable -> the `unavailable` verdict + a resumable hold, never a park.
//   exit 3      -> the same residual fault WITH --truncated (the served response carried a truncation
//                  signal): `{lens, outcome:"unavailable", kind:"infra-configured", objections:[]}` on
//                  stdout. `infra-configured` is swing-capable -> the `unavailable` verdict + a
//                  resumable `faff-awaiting-spec-review` hold (FAFF-900), never a park.
//   exit 2      -> usage (missing --lens, unreadable stdin) — a real fault, empty stdout; the occupant
//                  records `config-fault` for this (a genuine parser plumbing fault).
// FAFF-990/FAFF-1056: the kind decision is deterministic, so the parser NAMES the `kind` on stdout
// (chosen from --truncated) and the occupant records that stdout verbatim — the exit code and the
// stdout `kind` are one decision surfaced twice, both code-emitted and both fixture-testable. The
// occupant performs no exit-to-kind judgement of its own. `config-fault` is retained for its genuine
// sources (a review-call transport/config outage, an unconfigured chain, parser usage exit 2), never a
// parser residual fault.
function faultMessage(f, truncated) {
  const parts = [`lens=${f.lens}`, `severity=${f.severity}`, `title=${JSON.stringify(f.title)}`];
  if (f.missing_field) parts.push(`missing_field=${f.missing_field}`);
  if (f.reason) parts.push(`reason=${f.reason}`);
  parts.push(`truncated=${!!truncated}`);
  return `parse-refutation: parse fault — ${parts.join(" ")}`;
}

function main(argv) {
  const args = argv.slice(2);
  const li = args.indexOf("--lens");
  const lens = li !== -1 ? args[li + 1] : undefined;
  const truncated = args.includes("--truncated");   // FAFF-990: a transport property, applied at the CLI seam
  if (!lens) {
    process.stderr.write("parse-refutation: --lens <lens> is required\n");
    return 2;
  }
  let content;
  try {
    content = readFileSync(0, "utf8");
  } catch (e) {
    process.stderr.write(`parse-refutation: cannot read stdin — ${e.message}\n`);
    return 2;
  }
  const result = parseRefutation(content, lens);
  if (!result.ok) {
    // Residual fault: emit the machine record on STDOUT (the occupant records it verbatim) and the
    // human diagnostic on STDERR (the audit trail). `kind`/exit are the same decision, keyed on
    // --truncated. FAFF-1056: the non-truncated residual fault carries `model-transient` (was
    // `config-fault`) — a served, shape-valid, off-grammar body is a model-quality transient, not a
    // human-fixable config fault, so it routes to the swing `unavailable` verdict (retry/hold), never
    // the `config-fault` floor -> needs-human park.
    const kind = truncated ? "infra-configured" : "model-transient";
    process.stdout.write(JSON.stringify({ lens, outcome: "unavailable", kind, objections: [] }) + "\n");
    process.stderr.write(faultMessage(result.fault, truncated) + "\n");
    return truncated ? 3 : 1;
  }
  process.stdout.write(JSON.stringify(result.entry) + "\n");
  return 0;
}

// Run as CLI only when invoked directly (not when imported by the test). Canonicalise argv[1]
// through realpathSync before comparing so a symlinked install path (FAFF-813) still matches —
// mirrors aggregate.mjs's entrypoint_href exactly.
export function entrypoint_href(argv1) {
  if (!argv1) return null;
  try {
    return pathToFileURL(realpathSync(argv1)).href;
  } catch {
    return pathToFileURL(argv1).href;
  }
}

if (import.meta.url === entrypoint_href(process.argv[1])) {
  process.exitCode = main(process.argv);
}
