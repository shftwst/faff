// FAFF-994 — the durable, interrogatable spec-review judgement trail. Writer (`faff
// judge-trail mint`), reader core (`faff judge-history`), and `faff audit`'s durable
// second source, over a dedicated `refs/faff/judge-trail/<run_id>` custom git ref.

import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, mkdirSync, writeFileSync, readFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { spawnSync } from "node:child_process";
import { createRequire } from "node:module";
import { runCli } from "./helpers/run-cli.mjs";

const require = createRequire(import.meta.url);
const { sha256Text } = require("../plugin/skills/faff/bin/lib/spec-judge-casefile.js");
const jt = require("../plugin/skills/faff/bin/lib/judge-trail.js");

function initRepo(root) {
  spawnSync("git", ["-C", root, "init", "-q"]);
  spawnSync("git", ["-C", root, "config", "user.email", "faff-selftest@example.com"]);
  spawnSync("git", ["-C", root, "config", "user.name", "faff-selftest"]);
}

// Seed <root>/.faff/runs/<run_id>/<issue>/spec-review/{round-1.json,judge/{ledger,ruling-p-01,admit-result}.json}
// plus an on-disk spec file at <root>/.faff/runs/<run_id>/<issue>/spec-draft.md — the full
// judge-invoked fixture shape.
function seedFullFixture(root, runId, issue, { admit = true } = {}) {
  const runDir = join(root, ".faff", "runs", runId);
  const issueDir = join(runDir, issue);
  const specReviewDir = join(issueDir, "spec-review");
  const judgeDir = join(specReviewDir, "judge");
  mkdirSync(judgeDir, { recursive: true });
  writeFileSync(join(issueDir, "spec-draft.md"), "# Spec\n\nhello world\n");
  writeFileSync(join(specReviewDir, "round-1.json"), JSON.stringify({
    verdict: "reject-approach",
    objections: [
      { lens: "infosec", severity: "major", claim: "leak", evidence: "see config.txt", predicted_consequence: "exfiltration", spec_anchor: "the-guard" },
      { lens: "QA", severity: "minor", claim: "untested boundary", evidence: "", predicted_consequence: null, spec_anchor: "the-guard-decision" },
    ],
  }));
  writeFileSync(join(judgeDir, "ledger.json"), JSON.stringify({
    order: ["p-01", "p-02"],
    entries: {
      "p-01": { proposition_id: "p-01", lens: "infosec", severity: "major", blocking: true, contested_source: true, pre_ruling_spec_sha: "deadbeef", pre_ruling_spec_content: "old spec text", resolution: "resolved" },
      "p-02": { proposition_id: "p-02", lens: "QA", severity: "minor", blocking: false, contested_source: false, pre_ruling_spec_sha: "deadbeef", pre_ruling_spec_content: "old spec text", resolution: "resolved" },
    },
    run_id: runId,
    window_start: 1,
  }));
  writeFileSync(join(judgeDir, "ruling-p-01.json"), JSON.stringify({
    proposition_id: "p-01", outcome: "AFFIRM_SPEC", rationale: "the spec already covers this",
    correction: null, synthesis_sources: [], prd_gap_citation: "", lens: "infosec", severity: "major", conformant: true, violations: [],
  }));
  writeFileSync(join(judgeDir, "ruling-p-02.json"), JSON.stringify({
    proposition_id: "p-02", outcome: "AFFIRM_SPEC", rationale: "minor, no correction needed",
    correction: null, synthesis_sources: [], prd_gap_citation: "", lens: "QA", severity: "minor", conformant: true, violations: [],
  }));
  const admitResult = {
    admit, level: "L3", resolved: ["p-01", "p-02"], unresolved: admit ? [] : ["p-01"], parked: [],
    prd_boundary: [], minor_corrections_applied: [], minor_corrections_unapplied: [], floor_veto: admit ? [] : ["blocker"],
  };
  writeFileSync(join(judgeDir, "admit-result.json"), JSON.stringify(admitResult));
  return { runDir, issueDir, specReviewDir, judgeDir, admitResult };
}

test("mint: a run dir with no spec-review material anywhere is a clean no-op, exit 0", () => {
  const root = mkdtempSync(join(tmpdir(), "faff-judge-trail-noop-"));
  try {
    initRepo(root);
    const runId = "run-empty-000000";
    const runDir = join(root, ".faff", "runs", runId);
    mkdirSync(runDir, { recursive: true });
    const r = runCli(["judge-trail", "mint", "--run-dir", runDir, "--root", root, "--json"]);
    assert.equal(r.code, 0, r.stderr);
    const body = JSON.parse(r.stdout);
    assert.equal(body.minted, false);
    assert.match(body.message, /nothing to mint/);
  } finally { rmSync(root, { recursive: true, force: true }); }
});

test("mint -> judge-history (local store): manifest carries schema_version/issue/run_id/built_spec_sha/paths/outcome/lenses/witness_sha; witness verifies; contested_source carried through, not dropped; opens no PR/branch", () => {
  const root = mkdtempSync(join(tmpdir(), "faff-judge-trail-happy-"));
  try {
    initRepo(root);
    const runId = "run-happy-000001";
    const { runDir } = seedFullFixture(root, runId, "FAFF-1", { admit: true });

    const mint = runCli(["judge-trail", "mint", "--run-dir", runDir, "--root", root, "--json"]);
    assert.equal(mint.code, 0, mint.stderr);
    const mintBody = JSON.parse(mint.stdout);
    assert.equal(mintBody.minted, true);
    assert.deepEqual(mintBody.issues, ["FAFF-1"]);
    assert.equal(mintBody.ref, `refs/faff/judge-trail/${runId}`);

    // no branch/PR surface — a custom ref, never refs/heads/*
    const heads = spawnSync("git", ["-C", root, "for-each-ref", "refs/heads/"], { encoding: "utf8" });
    assert.equal((heads.stdout || "").trim(), "", "mint creates no branch — opens no PR");

    const hist = runCli(["judge-history", "--run", runId, "--root", root, "--json"]);
    assert.equal(hist.code, 0, hist.stderr);
    const records = JSON.parse(hist.stdout);
    assert.equal(records.length, 1);
    const rec = records[0];
    assert.equal(rec.issue, "FAFF-1");
    assert.equal(rec.outcome, "admit");
    assert.equal(rec.tamper_suspect, false);
    assert.deepEqual([...rec.lenses].sort(), ["QA", "infosec"]);

    const m = rec.manifest;
    assert.equal(m.schema_version, 3, "FAFF-1132 bumped the trail schema 2 -> 3 (the per-round member is write-capped)");
    assert.equal(m.issue, "FAFF-1");
    assert.equal(m.run_id, runId);
    assert.equal(m.spec_blob, "spec.txt");
    assert.equal(m.objections, "objections.json");
    assert.equal(m.objections_by_round, "objections-by-round.json");
    assert.equal(m.objections_by_round_truncated, false, "a small corpus is untruncated");
    assert.equal(m.objections_by_round_dropped_rounds, 0);
    assert.equal(m.rulings, "rulings.json");
    assert.equal(m.admit_result, "admit-result.json");
    assert.equal(m.built_spec_sha, sha256Text("# Spec\n\nhello world\n"), "built_spec_sha == sha256Text(spec_text), the exact spec.txt bytes just fetched below");
    const manifestCore = { ...m };
    delete manifestCore.witness_sha;
    assert.equal(m.witness_sha, jt.witnessSha(manifestCore), "witness_sha == sha256(canonicalJSON(manifest_core))");

    // Fetch the raw tree via git plumbing (no checkout) and confirm byte-identical verbatim content.
    const sha = spawnSync("git", ["-C", root, "for-each-ref", "refs/faff/judge-trail/", "--format=%(objectname)"], { encoding: "utf8" }).stdout.trim();
    const objectionsRaw = spawnSync("git", ["-C", root, "show", `${sha}:FAFF-1/objections.json`], { encoding: "utf8" }).stdout;
    const objections = JSON.parse(objectionsRaw);
    assert.equal(objections.length, 2);
    assert.equal(objections[0].claim, "leak");
    assert.equal(objections[0].evidence, "see config.txt");
    assert.equal(objections[0].predicted_consequence, "exfiltration");
    assert.equal(objections[0].spec_anchor, "the-guard");
    assert.equal(objections[0].contested_source, true, "down-weighted objection is stored, not dropped");
    assert.equal(objections[1].contested_source, false);

    const admitRaw = spawnSync("git", ["-C", root, "show", `${sha}:FAFF-1/admit-result.json`], { encoding: "utf8" }).stdout;
    assert.equal(JSON.parse(admitRaw).admit, true);

    const rulingsRaw = spawnSync("git", ["-C", root, "show", `${sha}:FAFF-1/rulings.json`], { encoding: "utf8" }).stdout;
    const rulings = JSON.parse(rulingsRaw);
    assert.equal(rulings.length, 2);
    assert.equal(rulings[0].proposition_id, "p-01");
    assert.equal(rulings[0].outcome, "AFFIRM_SPEC");

    const specRaw = spawnSync("git", ["-C", root, "show", `${sha}:FAFF-1/spec.txt`], { encoding: "utf8" }).stdout;
    assert.match(specRaw, /hello world/);
  } finally { rmSync(root, { recursive: true, force: true }); }
});

test("mint survives run-dir cleanup: the ref is readable via judge-history after the run dir the mint was built from is deleted", () => {
  const root = mkdtempSync(join(tmpdir(), "faff-judge-trail-survives-"));
  try {
    initRepo(root);
    const runId = "run-survives-cleanup-000009";
    const { runDir } = seedFullFixture(root, runId, "FAFF-7", { admit: true });
    const mint = JSON.parse(runCli(["judge-trail", "mint", "--run-dir", runDir, "--root", root, "--json"]).stdout);
    assert.equal(mint.minted, true);

    // The run-dir scratch material is swept (the exact lifecycle event the trail exists to
    // survive) — the ref lives under .git, decoupled from the run-dir it was built from.
    rmSync(join(root, ".faff", "runs"), { recursive: true, force: true });

    const hist = runCli(["judge-history", "--run", runId, "--root", root, "--json"]);
    assert.equal(hist.code, 0, hist.stderr);
    const records = JSON.parse(hist.stdout);
    assert.equal(records.length, 1);
    assert.equal(records[0].issue, "FAFF-7");
    assert.equal(records[0].tamper_suspect, false, "the minted content is intact independent of the swept run dir");
  } finally { rmSync(root, { recursive: true, force: true }); }
});

test("mint is write-once: a second mint for the same run_id leaves a single ref (clean logged no-op), never a force-update", () => {
  const root = mkdtempSync(join(tmpdir(), "faff-judge-trail-writeonce-"));
  try {
    initRepo(root);
    const runId = "run-writeonce-000002";
    const { runDir } = seedFullFixture(root, runId, "FAFF-1");
    const first = JSON.parse(runCli(["judge-trail", "mint", "--run-dir", runDir, "--root", root, "--json"]).stdout);
    assert.equal(first.minted, true);
    const shaAfterFirst = spawnSync("git", ["-C", root, "for-each-ref", "refs/faff/judge-trail/", "--format=%(objectname)"], { encoding: "utf8" }).stdout.trim();

    const second = JSON.parse(runCli(["judge-trail", "mint", "--run-dir", runDir, "--root", root, "--json"]).stdout);
    assert.equal(second.minted, false, "a second mint for the same run_id is a clean no-op");
    assert.equal(second.ok, true);
    const shaAfterSecond = spawnSync("git", ["-C", root, "for-each-ref", "refs/faff/judge-trail/", "--format=%(objectname)"], { encoding: "utf8" }).stdout.trim();
    assert.equal(shaAfterSecond, shaAfterFirst, "the ref head is unchanged — never a force-update");

    // exactly one ref for this run_id
    const all = spawnSync("git", ["-C", root, "for-each-ref", "refs/faff/judge-trail/"], { encoding: "utf8" }).stdout.trim().split("\n").filter(Boolean);
    assert.equal(all.length, 1);
  } finally { rmSync(root, { recursive: true, force: true }); }
});

test("judge-history: a witness_sha mismatch is retained and flagged tamper_suspect, never dropped and never exit-nonzero", () => {
  const root = mkdtempSync(join(tmpdir(), "faff-judge-trail-tamper-"));
  try {
    initRepo(root);
    const runId = "run-tamper-000003";
    const { runDir } = seedFullFixture(root, runId, "FAFF-1");
    const mint = JSON.parse(runCli(["judge-trail", "mint", "--run-dir", runDir, "--root", root, "--json"]).stdout);
    assert.equal(mint.minted, true);

    const ref = `refs/faff/judge-trail/${runId}`;
    const origSha = spawnSync("git", ["-C", root, "for-each-ref", ref, "--format=%(objectname)"], { encoding: "utf8" }).stdout.trim();

    // Rebuild the FAFF-1 tree with a mutated manifest.json (a hand-edited outcome, witness_sha
    // left untouched) layered over the original blobs for every other path — simulates a
    // tampered store without needing to reconstruct the whole tree by hand. Nested paths
    // (e.g. "FAFF-1/manifest.json") can't go through `git mktree` (it refuses any entry name
    // containing a slash) — use the same temp-index + update-index --cacheinfo + write-tree
    // idiom judge-trail.js's own mint uses to materialise real subtrees.
    const origManifestRaw = spawnSync("git", ["-C", root, "show", `${origSha}:FAFF-1/manifest.json`], { encoding: "utf8" }).stdout;
    const tamperedManifest = JSON.parse(origManifestRaw);
    tamperedManifest.outcome = "park"; // mutate the core WITHOUT recomputing witness_sha
    const newManifestBlob = spawnSync("git", ["-C", root, "hash-object", "-w", "--stdin"], { input: JSON.stringify(tamperedManifest), encoding: "utf8" }).stdout.trim();

    const lsTree = spawnSync("git", ["-C", root, "ls-tree", "-r", origSha], { encoding: "utf8" }).stdout.trim().split("\n");
    const tmpIndex = join(root, ".git", "tamper-fixture-index");
    const env = { ...process.env, GIT_INDEX_FILE: tmpIndex };
    for (const line of lsTree) {
      const [meta, filePath] = line.split("\t");
      const [mode, , origBlobSha] = meta.split(" ");
      const blobSha = filePath === "FAFF-1/manifest.json" ? newManifestBlob : origBlobSha;
      const upd = spawnSync("git", ["-C", root, "update-index", "--add", "--cacheinfo", `${mode},${blobSha},${filePath}`], { env, encoding: "utf8" });
      assert.equal(upd.status, 0, `update-index failed for ${filePath}: ${upd.stderr}`);
    }
    const newTree = spawnSync("git", ["-C", root, "write-tree"], { env, encoding: "utf8" }).stdout.trim();
    const newCommit = spawnSync("git", ["-C", root, "commit-tree", newTree, "-m", "tampered (test fixture)"], { encoding: "utf8" }).stdout.trim();
    const forceUpdate = spawnSync("git", ["-C", root, "update-ref", ref, newCommit]);
    assert.equal(forceUpdate.status, 0);

    const hist = runCli(["judge-history", "--run", runId, "--root", root, "--json"]);
    assert.equal(hist.code, 0, "a tamper-suspect record is surfaced, not an error exit");
    const records = JSON.parse(hist.stdout);
    assert.equal(records.length, 1, "the record is RETAINED, never dropped");
    assert.equal(records[0].tamper_suspect, true);
  } finally { rmSync(root, { recursive: true, force: true }); }
});

test("judge-history: no judge-trail refs at all -> empty set under --json, exit 0", () => {
  const root = mkdtempSync(join(tmpdir(), "faff-judge-trail-none-"));
  try {
    initRepo(root);
    const r = runCli(["judge-history", "--json", "--root", root]);
    assert.equal(r.code, 0);
    assert.deepEqual(JSON.parse(r.stdout), []);
  } finally { rmSync(root, { recursive: true, force: true }); }
});

test("mint: a run that never invoked the judge (only refuter rounds, no judge/ dir) mints admit_result:null, outcome:'no-judge'", () => {
  const root = mkdtempSync(join(tmpdir(), "faff-judge-trail-nojudge-"));
  try {
    initRepo(root);
    const runId = "run-nojudge-000004";
    const runDir = join(root, ".faff", "runs", runId);
    const specReviewDir = join(runDir, "FAFF-2", "spec-review");
    mkdirSync(specReviewDir, { recursive: true });
    writeFileSync(join(specReviewDir, "round-1.json"), JSON.stringify({
      verdict: "reject-approach",
      objections: [{ lens: "architectural", severity: "blocker", claim: "wrong shape", evidence: "x", predicted_consequence: "y", spec_anchor: "z" }],
    }));

    const mint = JSON.parse(runCli(["judge-trail", "mint", "--run-dir", runDir, "--root", root, "--json"]).stdout);
    assert.equal(mint.minted, true);

    const records = JSON.parse(runCli(["judge-history", "--run", runId, "--root", root, "--json"]).stdout);
    assert.equal(records.length, 1);
    assert.equal(records[0].outcome, "no-judge");
    assert.equal(records[0].manifest.admit_result, null, "admit_result is null when the judge never ran");
  } finally { rmSync(root, { recursive: true, force: true }); }
});

test("judge-history: --lens and --outcome filter; --issue filters to one issue", () => {
  const root = mkdtempSync(join(tmpdir(), "faff-judge-trail-filters-"));
  try {
    initRepo(root);
    const runId = "run-filters-000005";
    seedFullFixture(root, runId, "FAFF-3", { admit: true });
    seedFullFixture(root, runId, "FAFF-4", { admit: false });
    const runDir = join(root, ".faff", "runs", runId);
    const mint = JSON.parse(runCli(["judge-trail", "mint", "--run-dir", runDir, "--root", root, "--json"]).stdout);
    assert.equal(mint.minted, true);
    assert.deepEqual([...mint.issues].sort(), ["FAFF-3", "FAFF-4"]);

    const admitOnly = JSON.parse(runCli(["judge-history", "--run", runId, "--outcome", "admit", "--root", root, "--json"]).stdout);
    assert.deepEqual(admitOnly.map((r) => r.issue), ["FAFF-3"]);

    const parkOnly = JSON.parse(runCli(["judge-history", "--run", runId, "--outcome", "park", "--root", root, "--json"]).stdout);
    assert.deepEqual(parkOnly.map((r) => r.issue), ["FAFF-4"]);

    const infosecLens = JSON.parse(runCli(["judge-history", "--run", runId, "--lens", "infosec", "--root", root, "--json"]).stdout);
    assert.equal(infosecLens.length, 2, "both issues carry an infosec objection");

    const oneIssue = JSON.parse(runCli(["judge-history", "--issue", "FAFF-3", "--root", root, "--json"]).stdout);
    assert.deepEqual(oneIssue.map((r) => r.issue), ["FAFF-3"]);
  } finally { rmSync(root, { recursive: true, force: true }); }
});

test("mint (git-remote store): pushes a write-once orphan commit to origin, no PR/branch; judge-history reads it via ls-remote/fetch/show (no checkout); a second mint against the remote is a clean no-op", () => {
  const scratch = mkdtempSync(join(tmpdir(), "faff-judge-trail-gitremote-"));
  try {
    const bareRemote = join(scratch, "remote.git");
    const workRoot = join(scratch, "work");
    mkdirSync(workRoot, { recursive: true });
    spawnSync("git", ["init", "--bare", "-q", bareRemote]);
    initRepo(workRoot);
    spawnSync("git", ["-C", workRoot, "remote", "add", "origin", bareRemote]);
    writeFileSync(join(workRoot, ".faffrc.yaml"), "bundle_store: git-remote\n");

    const runId = "run-gitremote-000006";
    const { runDir } = seedFullFixture(workRoot, runId, "FAFF-5", { admit: true });

    const mint = runCli(["judge-trail", "mint", "--run-dir", runDir, "--root", workRoot, "--json"], { cwd: workRoot });
    assert.equal(mint.code, 0, mint.stderr);
    const mintBody = JSON.parse(mint.stdout);
    assert.equal(mintBody.minted, true);

    // No branch surface on the remote either.
    const remoteHeads = spawnSync("git", ["ls-remote", bareRemote, "refs/heads/*"], { encoding: "utf8" }).stdout.trim();
    assert.equal(remoteHeads, "", "git-remote mint creates no branch on the remote — no PR/CI surface");
    const remoteRef = spawnSync("git", ["ls-remote", bareRemote, `refs/faff/judge-trail/${runId}`], { encoding: "utf8" }).stdout.trim();
    assert.notEqual(remoteRef, "", "the ref was pushed to the remote");

    // Read back from a FRESH clone-free directory (checkout-free: init + remote add only).
    const freshRoot = join(scratch, "fresh");
    mkdirSync(freshRoot, { recursive: true });
    spawnSync("git", ["-C", freshRoot, "init", "-q"]);
    spawnSync("git", ["-C", freshRoot, "remote", "add", "origin", bareRemote]);
    writeFileSync(join(freshRoot, ".faffrc.yaml"), "bundle_store: git-remote\n");
    const hist = runCli(["judge-history", "--run", runId, "--root", freshRoot, "--json"], { cwd: freshRoot });
    assert.equal(hist.code, 0, hist.stderr);
    const records = JSON.parse(hist.stdout);
    assert.equal(records.length, 1);
    assert.equal(records[0].issue, "FAFF-5");
    assert.equal(records[0].tamper_suspect, false);

    // A second mint (non-force push) against the already-populated remote is a clean no-op.
    const second = runCli(["judge-trail", "mint", "--run-dir", runDir, "--root", workRoot, "--json"], { cwd: workRoot });
    assert.equal(second.code, 0, second.stderr);
    assert.equal(JSON.parse(second.stdout).minted, false);
  } finally { rmSync(scratch, { recursive: true, force: true }); }
});

test("faff audit <run-id>: the durable judge-trail SECOND source is folded in via self-spawn, preserving tamper_suspect; regions check still passes (no governance->factory require edge)", () => {
  const root = mkdtempSync(join(tmpdir(), "faff-judge-trail-audit-"));
  try {
    initRepo(root);
    const runId = "run-audit-000007";
    const { runDir } = seedFullFixture(root, runId, "FAFF-6", { admit: true });
    writeFileSync(join(runDir, "run-ledger.json"), JSON.stringify({ run_id: runId, admitted: ["FAFF-6"], outcomes: { "FAFF-6": "parked" } }));
    writeFileSync(join(runDir, "events.jsonl"), JSON.stringify({ schema: 1, run_id: runId, seq: 0, ts: "2026-09-04T00:00:00Z", phase: "run", type: "run-start" }) + "\n");

    const mint = JSON.parse(runCli(["judge-trail", "mint", "--run-dir", runDir, "--root", root, "--json"]).stdout);
    assert.equal(mint.minted, true);

    const audit = runCli(["audit", runId, "--root", root, "--json"]);
    assert.equal(audit.code, 0, audit.stderr);
    const recon = JSON.parse(audit.stdout);
    assert.ok(recon.durable_judge_trail, "audit reconstruction carries a durable_judge_trail field");
    assert.equal(recon.durable_judge_trail.available, true);
    assert.equal(recon.durable_judge_trail.records.length, 1);
    assert.equal(recon.durable_judge_trail.records[0].issue, "FAFF-6");
    assert.equal(recon.durable_judge_trail.records[0].tamper_suspect, false);

    // The single-run reconstruction still renders normally alongside the second source.
    assert.equal(recon.run_id, runId);
    assert.ok(Array.isArray(recon.issues) && recon.issues.some((i) => i.issue === "FAFF-6"));

    // The region-boundary invariant this build's single highest-risk mistake would break:
    // audit.js (governance) must never require() judge-trail.js (factory) — only a
    // spawnSync self-spawn. `faff regions check` is the mechanical assertion of that.
    const regions = runCli(["regions", "check"]);
    assert.equal(regions.code, 0, `faff regions check must pass (stdout: ${regions.stdout}, stderr: ${regions.stderr})`);
  } finally { rmSync(root, { recursive: true, force: true }); }
});

test("faff audit: when no judge-trail ref exists for the run, the durable second source is absent (never fails audit; single-run reconstruction renders alone)", () => {
  const root = mkdtempSync(join(tmpdir(), "faff-judge-trail-audit-absent-"));
  try {
    initRepo(root);
    const runId = "run-audit-absent-000008";
    const runDir = join(root, ".faff", "runs", runId);
    mkdirSync(runDir, { recursive: true });
    writeFileSync(join(runDir, "run-ledger.json"), JSON.stringify({ run_id: runId, admitted: [], outcomes: {} }));
    writeFileSync(join(runDir, "events.jsonl"), "");

    const audit = runCli(["audit", runId, "--root", root, "--json"]);
    assert.equal(audit.code, 0, audit.stderr);
    const recon = JSON.parse(audit.stdout);
    assert.equal(recon.durable_judge_trail.available, true, "an empty ref enumeration is available:true with zero records, not an error");
    assert.deepEqual(recon.durable_judge_trail.records, []);
  } finally { rmSync(root, { recursive: true, force: true }); }
});

// FAFF-1131 — per-round objection history. Seed N rounds (no judge dir needed; round files
// alone are material for the mint), optionally a window.json, and mint/read.
function seedRounds(root, runId, issue, rounds, windowStart) {
  const runDir = join(root, ".faff", "runs", runId);
  const specReviewDir = join(runDir, issue, "spec-review");
  mkdirSync(specReviewDir, { recursive: true });
  for (const { n, objections } of rounds) {
    writeFileSync(join(specReviewDir, `round-${n}.json`), JSON.stringify({ verdict: "revise", objections }));
  }
  if (windowStart != null) writeFileSync(join(specReviewDir, "window.json"), JSON.stringify({ window_start: windowStart }));
  return { runDir, specReviewDir };
}

test("FAFF-1131: mint retains per-round objections; judge-history --rounds returns each round verbatim, default omits it", () => {
  const root = mkdtempSync(join(tmpdir(), "faff-judge-trail-byround-"));
  try {
    initRepo(root);
    const runId = "run-byround-000101";
    const { runDir } = seedRounds(root, runId, "FAFF-11", [
      { n: 1, objections: [{ lens: "infosec", severity: "major", claim: "r1a" }, { lens: "QA", severity: "minor", claim: "r1b" }] },
      { n: 2, objections: [{ lens: "infosec", severity: "major", claim: "r2a" }] },
      { n: 3, objections: [] },
    ]);
    const mint = JSON.parse(runCli(["judge-trail", "mint", "--run-dir", runDir, "--root", root, "--json"]).stdout);
    assert.equal(mint.minted, true, "a rounds-only run is mintable material");

    // Default read: no per-round field fetched (cost profile unchanged).
    const def = JSON.parse(runCli(["judge-history", "--run", runId, "--root", root, "--json"]).stdout);
    assert.equal(def.length, 1);
    assert.equal(def[0].objections_by_round, undefined, "default read carries no objections_by_round");

    // --rounds: every round, verbatim, ascending.
    const withRounds = JSON.parse(runCli(["judge-history", "--run", runId, "--rounds", "--root", root, "--json"]).stdout);
    const obr = withRounds[0].objections_by_round;
    assert.ok(Array.isArray(obr) && obr.length === 3, "all three rounds retained");
    assert.deepEqual(obr.map((r) => r.round), [1, 2, 3]);
    assert.equal(obr[0].objections.length, 2);
    assert.equal(obr[0].objections[0].claim, "r1a");
    assert.equal(obr[1].objections[0].claim, "r2a");
    assert.equal(obr[2].objections.length, 0, "an empty-objection round is retained as []");
    assert.ok(obr.every((r) => r.window_start === 1), "window_start=1 stamped (no marker)");
  } finally { rmSync(root, { recursive: true, force: true }); }
});

test("FAFF-1131: window_start excludes pre-window rounds from objections-by-round.json", () => {
  const root = mkdtempSync(join(tmpdir(), "faff-judge-trail-window-"));
  try {
    initRepo(root);
    const runId = "run-byround-window-000102";
    const { runDir } = seedRounds(root, runId, "FAFF-13", [
      { n: 1, objections: [{ lens: "infosec", severity: "major", claim: "pre-window" }] },
      { n: 2, objections: [{ lens: "QA", severity: "minor", claim: "r2" }] },
      { n: 3, objections: [{ lens: "QA", severity: "minor", claim: "r3" }] },
    ], 2);
    assert.equal(JSON.parse(runCli(["judge-trail", "mint", "--run-dir", runDir, "--root", root, "--json"]).stdout).minted, true);
    const withRounds = JSON.parse(runCli(["judge-history", "--run", runId, "--rounds", "--root", root, "--json"]).stdout);
    const obr = withRounds[0].objections_by_round;
    assert.deepEqual(obr.map((r) => r.round), [2, 3], "round 1 (below window_start=2) is excluded");
    assert.ok(obr.every((r) => r.window_start === 2));
    assert.ok(!obr.some((r) => r.objections.some((o) => o.claim === "pre-window")), "the pre-window round's objections are absent");
  } finally { rmSync(root, { recursive: true, force: true }); }
});

test("FAFF-1131: judge-history --rounds against a v1 trail (no objections-by-round member) returns objections_by_round:null, exit 0", () => {
  const root = mkdtempSync(join(tmpdir(), "faff-judge-trail-v1-"));
  try {
    initRepo(root);
    const runId = "run-v1-legacy-000103";
    const issue = "FAFF-12";
    // Hand-build a schema_version:1 subtree: manifest.json (witness_sha over the v1 core) +
    // objections.json only — deliberately NO objections-by-round.json member (a pre-slice trail).
    const core = {
      schema_version: 1, issue, run_id: runId, built_spec_sha: sha256Text(""),
      spec_blob: null, objections: "objections.json", rulings: "rulings.json",
      admit_result: null, outcome: "no-judge", lenses: [],
    };
    const manifest = { ...core, witness_sha: jt.witnessSha(core) };
    const idx = join(root, ".git", "faff-v1-index");
    const env = { ...process.env, GIT_INDEX_FILE: idx };
    const stage = (rel, body) => {
      const h = spawnSync("git", ["-C", root, "hash-object", "-w", "--stdin"], { input: body, encoding: "utf8" });
      assert.equal(h.status, 0, h.stderr);
      const u = spawnSync("git", ["-C", root, "update-index", "--add", "--cacheinfo", `100644,${h.stdout.trim()},${issue}/${rel}`], { env, encoding: "utf8" });
      assert.equal(u.status, 0, u.stderr);
    };
    stage("manifest.json", JSON.stringify(manifest, null, 2) + "\n");
    stage("objections.json", JSON.stringify([], null, 2) + "\n");
    stage("rulings.json", JSON.stringify([], null, 2) + "\n");
    const treeSha = spawnSync("git", ["-C", root, "write-tree"], { env, encoding: "utf8" }).stdout.trim();
    const commitSha = spawnSync("git", ["-C", root, "commit-tree", treeSha, "-m", `judge-trail ${runId}`], { encoding: "utf8" }).stdout.trim();
    assert.equal(spawnSync("git", ["-C", root, "update-ref", `refs/faff/judge-trail/${runId}`, commitSha]).status, 0);

    const r = runCli(["judge-history", "--run", runId, "--rounds", "--root", root, "--json"]);
    assert.equal(r.code, 0, r.stderr);
    const records = JSON.parse(r.stdout);
    assert.equal(records.length, 1);
    assert.equal(records[0].tamper_suspect, false, "the v1 manifest still verifies");
    assert.equal(records[0].objections_by_round, null, "an absent per-round member degrades to null, never a throw");
  } finally { rmSync(root, { recursive: true, force: true }); }
});

test("FAFF-1131: a corrupt round is skipped (others retained) and a corrupt window.json degrades to window_start=1; the mint never aborts", () => {
  const root = mkdtempSync(join(tmpdir(), "faff-judge-trail-corrupt-"));
  try {
    initRepo(root);
    const runId = "run-byround-corrupt-000104";
    const { runDir, specReviewDir } = seedRounds(root, runId, "FAFF-14", [
      { n: 1, objections: [{ lens: "QA", severity: "minor", claim: "r1" }] },
      { n: 3, objections: [{ lens: "QA", severity: "minor", claim: "r3" }] },
    ]);
    writeFileSync(join(specReviewDir, "round-2.json"), "null");        // valid JSON, non-object -> skip that round only
    writeFileSync(join(specReviewDir, "window.json"), "{ not json");   // corrupt marker -> readWindowStart throws -> window_start=1
    const mint = JSON.parse(runCli(["judge-trail", "mint", "--run-dir", runDir, "--root", root, "--json"]).stdout);
    assert.equal(mint.minted, true, "the mint completes despite the corrupt round + window marker");
    assert.deepEqual(mint.issues, ["FAFF-14"], "the issue subtree is retained, not dropped by the corrupt round");
    const withRounds = JSON.parse(runCli(["judge-history", "--run", runId, "--rounds", "--root", root, "--json"]).stdout);
    const obr = withRounds[0].objections_by_round;
    assert.deepEqual(obr.map((r) => r.round), [1, 3], "the corrupt round 2 is skipped; rounds 1 and 3 retained");
    assert.ok(obr.every((r) => r.window_start === 1), "the corrupt window.json degraded to window_start=1");
  } finally { rmSync(root, { recursive: true, force: true }); }
});

// ===========================================================================
// FAFF-1132 — the hard write-cap (OBJECTIONS_BLOB_WRITE_CAP) and its two-phase,
// front-dropping truncation on the per-round objection member.

const CAP = jt.OBJECTIONS_BLOB_WRITE_CAP;

// The exact serialization the member is staged as — the same expression both phases share.
const serializeMember = (rounds) => JSON.stringify(rounds, null, 2) + "\n";
const memberBytes = (rounds) => Buffer.byteLength(serializeMember(rounds), "utf8");

// Read the STAGED member back out of the ref as raw bytes (never via a re-serialization), so a
// byte-length assertion measures what was actually written.
function stagedMemberBytes(root, runId, issue) {
  const r = spawnSync("git", ["-C", root, "show", `refs/faff/judge-trail/${runId}:${issue}/objections-by-round.json`], { encoding: "buffer" });
  assert.equal(r.status, 0, String(r.stderr));
  return r.stdout;
}

// One objection of roughly `claimBytes` bytes — the knob that drives a round over the cap.
const bigObjection = (tag, claimBytes) => ({
  lens: "QA", severity: "minor", claim: `${tag}:${"x".repeat(claimBytes)}`,
  evidence: "", predicted_consequence: null, spec_anchor: "the-guard",
});

test("FAFF-1132: OBJECTIONS_BLOB_WRITE_CAP is the measured 256 KiB constant", () => {
  assert.equal(CAP, 262144, "the cap is 262144 bytes (256 KiB) — the justified, measured value");
});

test("FAFF-1132: fitObjectionsByRound front-drops whole rounds, keeps the residue, and meets the cap", () => {
  // Empty input: trivially under cap, nothing dropped.
  assert.deepEqual(jt.fitObjectionsByRound([], CAP), { fitted: [], dropped: 0 });
  assert.deepEqual(jt.fitObjectionsByRound(null, CAP), { fitted: [], dropped: 0 }, "a non-array degrades, never throws");

  // Already under cap: the full array, unchanged, nothing dropped.
  const small = [1, 2, 3].map((n) => ({ round: n, window_start: 1, objections: [{ lens: "QA", claim: `r${n}` }] }));
  const sfit = jt.fitObjectionsByRound(small, CAP);
  assert.deepEqual(sfit, { fitted: small, dropped: 0 });

  // Over cap across several rounds: a SUFFIX is kept, the tail (standing residue) survives,
  // the serialized fitted set meets the cap, and `dropped` counts the front rounds removed.
  const big = [1, 2, 3, 4, 5, 6, 7, 8].map((n) => ({ round: n, window_start: 1, objections: [bigObjection(`r${n}`, 60000)] }));
  assert.ok(memberBytes(big) > CAP, "the fixture corpus genuinely exceeds the cap");
  const bfit = jt.fitObjectionsByRound(big, CAP);
  assert.ok(bfit.dropped > 0, "front rounds were dropped");
  assert.equal(bfit.fitted.length, big.length - bfit.dropped, "dropped + fitted accounts for every round");
  assert.deepEqual(bfit.fitted, big.slice(bfit.dropped), "fitted is a suffix of the input — never a reordering or a tail cut");
  assert.deepEqual(bfit.fitted[bfit.fitted.length - 1], big[big.length - 1], "the standing residue (last entry) is retained");
  assert.ok(bfit.fitted[0].round > big[0].round, "the first retained round is later than the original first");
  assert.ok(memberBytes(bfit.fitted) <= CAP, "the fitted set meets the cap");
  assert.ok(memberBytes(big.slice(bfit.dropped - 1)) > CAP, "the fit is maximal — one more round would breach the cap");

  // Single round alone over cap: the residue is retained WHOLE, nothing dropped, cap exceeded.
  const single = [{ round: 7, window_start: 7, objections: [bigObjection("huge", CAP + 10000)] }];
  assert.ok(memberBytes(single) > CAP, "the single round genuinely exceeds the cap");
  const onefit = jt.fitObjectionsByRound(single, CAP);
  assert.deepEqual(onefit, { fitted: single, dropped: 0 }, "the single residue round is kept whole — never dropped, never sliced");
  assert.ok(memberBytes(onefit.fitted) > CAP, "the blob legitimately exceeds the cap in this one pathological case");
});

test("FAFF-1132: an over-cap multi-round corpus mints truncated — capped bytes, valid array, residue intact, marker in the manifest", () => {
  const root = mkdtempSync(join(tmpdir(), "faff-judge-trail-cap-over-"));
  try {
    initRepo(root);
    const runId = "run-cap-over-000201";
    const issue = "FAFF-1132";
    const seeded = [1, 2, 3, 4, 5, 6, 7, 8].map((n) => ({ n, objections: [bigObjection(`r${n}`, 60000)] }));
    const unfitted = seeded.map(({ n, objections }) => ({ round: n, window_start: 1, objections }));
    assert.ok(memberBytes(unfitted) > CAP, "the seeded corpus exceeds the cap before fitting");
    const { runDir } = seedRounds(root, runId, issue, seeded);

    const mint = JSON.parse(runCli(["judge-trail", "mint", "--run-dir", runDir, "--root", root, "--json"]).stdout);
    assert.equal(mint.ok, true, "a cap breach truncates and proceeds — the mint never errors");
    assert.equal(mint.minted, true);

    // The STAGED bytes meet the cap and parse as a bare JSON array (no torn write).
    const raw = stagedMemberBytes(root, runId, issue);
    assert.ok(raw.length <= CAP, `staged member is ${raw.length} bytes, within the ${CAP}-byte cap`);
    const parsed = JSON.parse(raw.toString("utf8"));
    assert.ok(Array.isArray(parsed), "the staged member is a bare JSON array at every truncation level");

    const rec = JSON.parse(runCli(["judge-history", "--run", runId, "--rounds", "--root", root, "--json"]).stdout)[0];
    assert.equal(rec.tamper_suspect, false, "witness_sha verifies on the v3 manifest carrying the two new fields");
    assert.equal(rec.manifest.schema_version, 3);
    assert.equal(rec.manifest.objections_by_round_truncated, true);
    assert.equal(rec.manifest.objections_by_round_dropped_rounds, seeded.length - parsed.length,
      "dropped_rounds equals the number of front rounds removed");
    assert.ok(rec.manifest.objections_by_round_dropped_rounds > 0);
    assert.equal(parsed[parsed.length - 1].round, 8, "the last retained round is the original highest — the standing residue");
    assert.ok(parsed[0].round > 1, "the first retained round is later than the original first");
    assert.deepEqual(parsed.map((r) => r.round), unfitted.slice(unfitted.length - parsed.length).map((r) => r.round),
      "the retained rounds are a contiguous ascending suffix");

    // Reader compatibility: --rounds still enumerates per-round lines on a truncated trail.
    const human = runCli(["judge-history", "--run", runId, "--rounds", "--root", root]).stdout;
    const roundLines = human.match(/^ {2}round \d+ \(window_start=/gm);
    assert.ok(roundLines, "judge-history --rounds printed at least one per-round line (an Array.isArray regression prints none)");
    assert.equal(roundLines.length, parsed.length,
      "judge-history --rounds prints one line per retained round (no Array.isArray regression)");
  } finally { rmSync(root, { recursive: true, force: true }); }
});

test("FAFF-1132: a single in-window round that alone exceeds the cap is retained whole; mint ok, truncated:false", () => {
  const root = mkdtempSync(join(tmpdir(), "faff-judge-trail-cap-single-"));
  try {
    initRepo(root);
    const runId = "run-cap-single-000202";
    const issue = "FAFF-1132";
    const { runDir } = seedRounds(root, runId, issue, [{ n: 1, objections: [bigObjection("huge", CAP + 10000)] }]);

    const mint = JSON.parse(runCli(["judge-trail", "mint", "--run-dir", runDir, "--root", root, "--json"]).stdout);
    assert.equal(mint.ok, true, "the mint stays best-effort — no throw, no ok:false on an over-cap residue");
    assert.equal(mint.minted, true);

    const raw = stagedMemberBytes(root, runId, issue);
    assert.ok(raw.length > CAP, "the blob legitimately exceeds the cap rather than dropping the residue");
    const parsed = JSON.parse(raw.toString("utf8"));
    assert.ok(Array.isArray(parsed) && parsed.length === 1, "the one round is staged whole as a valid array");
    assert.equal(parsed[0].round, 1);

    const rec = JSON.parse(runCli(["judge-history", "--run", runId, "--rounds", "--root", root, "--json"]).stdout)[0];
    assert.equal(rec.manifest.objections_by_round_truncated, false, "nothing was dropped, so nothing is marked truncated");
    assert.equal(rec.manifest.objections_by_round_dropped_rounds, 0);
    assert.equal(rec.manifest.schema_version, 3);
    assert.equal(rec.tamper_suspect, false);
  } finally { rmSync(root, { recursive: true, force: true }); }
});

test("FAFF-1132: a realistic 5-round x 4-objection corpus is untouched by the cap (the no-change-for-normal-runs regression guard)", () => {
  const root = mkdtempSync(join(tmpdir(), "faff-judge-trail-cap-realistic-"));
  try {
    initRepo(root);
    const runId = "run-cap-realistic-000203";
    const issue = "FAFF-1132";
    // ~640 B per objection: a realistic claim/evidence/consequence triple, 4 per round, 5 rounds.
    const realistic = (r, i) => ({
      lens: ["infosec", "QA", "architectural", "methodology"][i], severity: i === 0 ? "major" : "minor",
      claim: `round ${r} objection ${i}: ${"the spec under-specifies the boundary here. ".repeat(4)}`,
      evidence: `see the module cited in the spec's reference table. ${"line-level citation. ".repeat(4)}`,
      predicted_consequence: `a reader would implement the wrong shape. ${"consequence detail. ".repeat(3)}`,
      spec_anchor: `section-${r}-${i}`,
    });
    const seeded = [1, 2, 3, 4, 5].map((n) => ({ n, objections: [0, 1, 2, 3].map((i) => realistic(n, i)) }));
    const unfitted = seeded.map(({ n, objections }) => ({ round: n, window_start: 1, objections }));
    const unfittedBytes = memberBytes(unfitted);
    assert.ok(unfittedBytes > 10000 && unfittedBytes < 25000,
      `the fixture is a realistic ~15 KB corpus (measured ${unfittedBytes} bytes)`);
    assert.ok(unfittedBytes < CAP, "a realistic corpus sits well inside the cap");

    const { runDir } = seedRounds(root, runId, issue, seeded);
    assert.equal(JSON.parse(runCli(["judge-trail", "mint", "--run-dir", runDir, "--root", root, "--json"]).stdout).minted, true);

    const raw = stagedMemberBytes(root, runId, issue);
    assert.equal(raw.toString("utf8"), serializeMember(unfitted),
      "the staged member is byte-identical to the un-fitted serialization — no behavioural change for a normal run");
    const rec = JSON.parse(runCli(["judge-history", "--run", runId, "--rounds", "--root", root, "--json"]).stdout)[0];
    assert.equal(rec.manifest.objections_by_round_truncated, false);
    assert.equal(rec.manifest.objections_by_round_dropped_rounds, 0);
    assert.equal(rec.objections_by_round.length, 5, "all five rounds are retained");
  } finally { rmSync(root, { recursive: true, force: true }); }
});

test("FAFF-1132: an empty in-window corpus stages \"[]\\n\" with truncated:false, dropped_rounds:0", () => {
  const root = mkdtempSync(join(tmpdir(), "faff-judge-trail-cap-empty-"));
  try {
    initRepo(root);
    const runId = "run-cap-empty-000204";
    const issue = "FAFF-15";
    // A full judge fixture (so the issue is mintable material) whose window_start excludes
    // every round file -> collectObjectionsByRound returns [].
    const { runDir, specReviewDir } = seedFullFixture(root, runId, issue);
    writeFileSync(join(specReviewDir, "window.json"), JSON.stringify({ window_start: 9 }));
    assert.equal(JSON.parse(runCli(["judge-trail", "mint", "--run-dir", runDir, "--root", root, "--json"]).stdout).minted, true);

    assert.equal(stagedMemberBytes(root, runId, issue).toString("utf8"), "[]\n", "an empty corpus stages the empty array verbatim");
    const rec = JSON.parse(runCli(["judge-history", "--run", runId, "--rounds", "--root", root, "--json"]).stdout)[0];
    assert.deepEqual(rec.objections_by_round, []);
    assert.equal(rec.manifest.objections_by_round_truncated, false);
    assert.equal(rec.manifest.objections_by_round_dropped_rounds, 0);
    assert.equal(rec.manifest.schema_version, 3);
    assert.equal(rec.tamper_suspect, false);
  } finally { rmSync(root, { recursive: true, force: true }); }
});
